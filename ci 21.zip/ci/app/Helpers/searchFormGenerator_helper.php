<?php
function generateSearchFields($fields) {
  
    echo '<form action="" id="searchForm" method="POST" class="form-inline">';
    
    foreach ($fields as $field) {
        $name = $field['name'];
        $label = isset($field['label']) ? $field['label'] : ucfirst($name);
        $placeholder = isset($field['placeholder']) ? $field['placeholder'] : $label;
        
        echo '<label for="' . $name . 'search" class="search-label">' . $label . ':</label>';
        echo '<input type="text" name="' . $name . '" id="' . $name . 'search" class="form-control search" placeholder="' . $placeholder . '">';
    }
    echo '<button type="submit" class="btn btn-primary button-90" id="searchBtn" style="margin-right: 10px">Search</button>';
    echo '<button type="reset" class="btn btn-secondary button-80" id="resetSearch">Reset</button>';
    echo '</form>';
}
?>
