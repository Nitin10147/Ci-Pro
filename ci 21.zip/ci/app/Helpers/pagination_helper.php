<?php



function pagination($page_no, $total_data, $page_limit)
{
    try {
        $total_page = ($total_data > 0 && $page_limit > 0) ? ceil($total_data / $page_limit) : 1;
        $previous_page = max(1, $page_no - 1);
        $next_page = min($total_page, $page_no + 1);

        $pagenation = '<div class="paginationDiv">';
        if ($page_no > 1) {
            $pagenation .= '<span class="pagination_link first-page" id="1">First</span>';
            $pagenation .= '<span class="pagination_link previous-page" id="' . $previous_page . '"><<</span>';
        }
        for ($i = 1; $i <= $total_page; $i++) {
            if ($i == $page_no) {
                $pagenation .= "<span class='pagination_link active-pagination' id='$i'>$i</span>";
            } elseif ($i >= ($page_no - 2) && $i <= ($page_no + 2)) {
                $pagenation .= "<span class='pagination_link' id='$i'>$i</span>";
            }
        }
        if ($page_no < $total_page) {
            $pagenation .= '<span class="pagination_link next-page" id="' . $next_page . '">>></span>';
            $pagenation .= '<span class="pagination_link last-page" id="' . $total_page . '">Last</span>';
        }

        $pagenation .= '</div>';

        return [
            'pagination' => $pagenation,
            'total_page' => $total_page,
        ];
    } catch (Exception $e) {
        // Handle exception if necessary
    }
}
?>



