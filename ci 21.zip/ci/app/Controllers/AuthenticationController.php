<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\AuthenticationModel;

class AuthenticationController extends BaseController
{
    public function index(): string
    {
        return view('Login/Login');
      
        // if ($session->has('logged_in')) {
        //     return redirect()->to('/dashboard');
        // }
    }

    public function Authentication()
    {
        $validation = \Config\Services::validation();
        $validation->setRules([
            'email' => 'required|valid_email',
            'password' => 'required|min_length[8]'
        ]);
        if (!$validation->run($_POST)) {
            return redirect()->back()->withInput()->with('errors', $validation->getErrors());
        }
        $data = [
            'email' => $_POST['email'],
            'password' => $_POST['password']
        ];

        $model = new AuthenticationModel();
        $result = $model->loginAuth($data);

        if ($result['status']) {
            $session = session();

            $session->set([
                'username' => $result['data']['first_name'] . ' ' . $result['data']['last_name'],
                'profile_pic' => $result['data']['profile_pic'],
                'user_id' => $result['data']['id'],
                'email' => $result['data']['email'],
                'logged_in' => true
            ]);
            return response()->setJSON($result);
        } else {
            return response()->setJSON($result);
        }
    }

    public function logout()
    {
        $session = session();
        $session->destroy();
    }


    public function checkEmailExist()
    {
        helper('checkUniqe');
        $email = $_POST['email'];
        $isUnique = checkExistence('usermaster', 'email', $email);
        // echo $isUnique;
        if ($isUnique === 0) {
            return response()->setJSON([
                'status' => false,
                'message' => 'Email does not exist'
            ]);
        }else {
            return response()->setJSON([
                'status' => true,
                'message' => 'Email does exist'
            ]);
        }

    }

    public function sendForgotPassswordlink()
    {

        $emailencode = base64_encode($_POST['email']);
        $token = bin2hex(random_bytes(16));

        $email = \Config\Services::email();
      
        $config = [
            'protocol' => 'smtp',
            'SMTPHost' => 'smtp.gmail.com',
            'SMTPUser' => 'berlin10147@gmail.com',
            'SMTPPass' => 'hbol hmkp fjqe btfx',
            'SMTPPort' => 587,
            'SMTPCrypto' => 'tls', 
            'mailType'  => 'html', 
            'charset'   => 'utf-8',
            'wordWrap'  => true
        ];

        
        $email->initialize($config);

       
        $email->setFrom('your-email@example.com', 'Your Name');
        $email->setTo('recipient@example.com');
        $email->setSubject('Test Email');
        $email->setMessage(
            '
             <html>
 <head>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }
        .email-container {
            max-width: 600px;
            margin: 0 auto;
            background-color: #ffffff;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        .email-header {
            background-color:rgb(255, 249, 244);
            color: Black;
            padding: 20px;
            text-align: center;
        }
        .email-body {
            padding: 20px;
            text-align: center;
        }
        .email-body h2 {
            color: #333333;
        }
        .reset-link {
            background-color:rgb(167, 182, 231);
            color: Black;
            padding: 15px 25px;
            text-decoration: none;
            font-size: 16px;
            border-radius: 5px;
            display: inline-block;
        }
        .email-footer {
            background-color: #f4f4f4;
            color: #777777;
            padding: 15px;
            text-align: center;
            font-size: 12px;
        }
    </style>
 </head>
 <body>
    <div class="email-container">
        <div class="email-header">
            <h1>SanSoftwares</h1>
            <h3>Password Reset Request</h3>
        </div>
        <div class="email-body">
            <h2>Hi, ' . $_POST['email'] . '</h2>
            <p>We received a request to reset your password. Click the link below to reset your password:</p>
            <a href="http://localhost/MVCR/views/ResetPassword.php?token=' . $token . '&mm=' . $emailencode . '">Click Here</a>
            <p>This Link is Valid for 10 minutes only.</p>
        </div>
        <br>
        <div class="email-footer">
            <p>&copy; ' . date('Y') . 'SanSoftwares. All rights reserved.</p>
        </div>
    </div>
  </body>

  </html>'
            
        );

       
        if ($email->send()) {
            return response()->setJSON([
                'status' => true,
                'message' => 'Mail Sent Successfully'
            ]);
        } else {
            return response()->setJSON([
                'status' => false,
                'message' => 'Failed to send mail'
            ]);
            // echo $email->printDebugger(['headers']);
        }
    }




}




?>