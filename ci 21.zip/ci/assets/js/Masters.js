$(document).ready(function () {
  $("form").each(function () {
    $(this).submit(function (event) {
      event.preventDefault();

      const form_id = $(this).attr("id");
      const fields = $(this).find("input, textarea");
      const req_type = $(this).data("request") ? "update" : "add";
      // console.log(req_type);
      const base_url = window.location.href;
      //   console.log(base_url);
      //   console.log(req_type);
      let isValid = true;

      fields.each(function () {
        const field = $(this);
        const name_value = field.attr("name");
        const value = field.val();

        if (req_type == 'update' && name_value == 'password' && value === '') {
          $('#password').attr('name', '');
        }

        isValid = validate(name_value, value) && isValid;
      });


      if (isValid) {
        formData = new FormData($(this)[0]);
        formData.append("req_type", req_type);
        $.ajax({
          url: base_url + "/addupdate",
          type: "POST",
          data: formData,
          processData: false,
          contentType: false,
          success: function (response) {
            if (response.status) {
              // alert(response.message);
              Swal.fire({
                title: response.message,
                icon: "success",
                draggable: true
              });
              $("#home-tab").trigger("click");
              reloadTable();
            } else {
              // alert(response.error);
              Swal.fire({
                title: response.message,
                icon: "error",
                draggable: true
              });
            }
          },
          error: function (xhr, status, error) {
            console.error("Error in AJAX request: " + error);
            alert("There was an error submitting the form. Please try again.");
          },
        });
      }
    });
  });


  $(this).find('input, textarea').on('input', function () {

    const name_value = $(this).attr('name');
    let value = $(this).val();

    if (name_value == 'password' && value == '') {
      $('#password').attr('name', '');
    } else {
      $('#password').attr('name', 'password');
    }

    if (name_value == 'first_name' || name_value == 'last_name') {
      value = value.replace(/[^a-zA-Z]/g, '');
    }
    else if (name_value == 'mobile_number') {
      value = value.replace(/[^0-9]/g, '');
    } else if (name_value == 'zip') {
      value = value.replace(/[^0-9]/g, '');
    } else if (name_value == 'price') {
      value = value.replace(/[^0-9]/g, '');
    }

    $(this).val(value);

    validate(name_value, value);
  });

});



function validate(name_value, value) {
  let isValid = true;

  const error = (selector, message) => {
    const element = document.querySelector(selector);
    if (element) {
      element.innerText = message;
    } else {
    }
    isValid = false;
  };

  const clearError = (selector) => {
    const element = document.querySelector(selector);
    if (element) {
      element.innerText = "";
    }
  };

  if (name_value === "first_name") {
    if (!value) {
      error("#fname-error", "*First Name is required.");
    } else if (!/^[a-zA-Z]+$/.test(value)) {
      error("#fname-error", "*First Name should only contain letters.");
    } else if (value.length < 3 || value.length > 20) {
      error(
        "#fname-error",
        "*First Name length must be between 3-20 characters."
      );
    } else {
      clearError("#fname-error");
    }
  }

  if (name_value === "last_name") {
    if (!value) {
      error("#lname-error", "*Last Name is required.");
    } else if (!/^[a-zA-Z]+$/.test(value)) {
      error("#lname-error", "*Last Name should only contain letters.");
    } else if (value.length < 3 || value.length > 20) {
      error(
        "#lname-error",
        "*Last Name length must be between 3-20 characters."
      );
    } else {
      clearError("#lname-error");
    }
  }

  if (name_value === "email") {
    const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,3}$/;
    if (!value) {
      error("#emailError", "*Email is required.");
    } else if (!emailRegex.test(value)) {
      error("#emailError", "*Please enter a valid email address.");
    } else {
      clearError("#emailError");
    }
  }

  if (name_value === "password") {
    const passwordRegex =
      /^(?=.*[a-zA-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;
    if (!value) {
      error("#passwordError", "*Password is required.");
    } else if (!passwordRegex.test(value)) {
      error(
        "#passwordError",
        "*Password must be at least 8 characters, include a number and a special character."
      );
    } else {
      clearError("#passwordError");
    }
  }

  if (name_value === "mobile_number") {
    if (!value) {
      error("#phone-error", "*Phone number is required.");
    } else if (!/^\d{10}$/.test(value)) {
      error("#phone-error", "*Please enter a valid 10 digit phone number.");
    } else {
      clearError("#phone-error");
    }
  }

  if (name_value === "address") {
    if (!value) {
      error("#address-error", "*Address is required.");
    } else {
      clearError("#address-error");
    }
  }

  if (name_value === "city") {
    if (!value) {
      error("#city-error", "*City is required.");
    } else {
      clearError("#city-error");
    }
  }

  if (name_value === "state") {
    if (!value) {
      error("#state-error", "*State is required.");
    } else {
      clearError("#state-error");
    }
  }

  if (name_value === "zip") {
    if (!value) {
      error("#zip-error", "*ZIP code is required.");
    } else if (!/^\d{5,6}$/.test(value)) {
      error("#zip-error", "*Please enter a valid ZIP code.");
    } else {
      clearError("#zip-error");
    }
  }

  if (name_value === "country") {
    if (!value) {
      error("#country-error", "*Country is required.");
    } else {
      clearError("#country-error");
    }
  }

  if (name_value === "itemname") {
    if (!value) {
      error("#itemname-error", "*Item Name is required.");
    } else {
      clearError("#itemname-error");
    }
  }

  if (name_value === "price") {
    if (!value) {
      error("#price-error", "*Price is required.");
    } else if (value <= 0) {
      error("#price-error", "*Price can't be zero.");
    } else {
      clearError("#price-error");
    }
  }

  return isValid;
}




function triggerFileInput() {
  $("#profile-picture").click();
}

function loadFile(event) {
  var $circleContainer = $("#circle-container");
  var reader = new FileReader();

  reader.onload = function () {
    var imgElement = $("<img />", {
      src: reader.result,
      alt: "Profile Picture",
      id: "profile-image",
      css: {
        width: "70px",
        height: "70px",
        borderRadius: "50%",
      },
    });

    $circleContainer.empty().append(imgElement);
  };

  if (event.target.files && event.target.files[0]) {
    reader.readAsDataURL(event.target.files[0]);
  }
}

$("#profile-picture").on("click", loadFile);

function showToast() {
  const toast = document.getElementById("toast");
  toast.classList.remove("hide");
  toast.classList.add("show");
  const progress = toast.querySelector(".progress");
  progress.style.width = "0";
  setTimeout(() => {
    progress.style.width = "100%";
  }, 10);
  setTimeout(() => {
    hideToast();
  }, 2000);
}



// ==========================================  Table ==========================================

function urlMaker() {
  const baseURL = window.location.href;
  return baseURL.split("?")[0];
}
/// URL MAKER for pagination

function reloadTable() {
  const page_limit = $("#page_limit").val();
  const url = urlMaker();
  const page_no = $(".active-pagination").attr("id") ?? 1;
  loadMasters(page_no, page_limit, url);
}

$(document).on("click", ".pagination_link", function () {
  var page_no = $(this).attr("id");
  var page_limit = $("#page_limit").val();
  const url = urlMaker();
  loadMasters(page_no, page_limit, url);
});

$(document).on("change", ".page_limit", function (e) {
  const url = urlMaker();
  var page_limit = $(this).val();
  loadMasters(1, page_limit, url);
});

$(document).on("click", ".column_sort", function (e) {
  e.preventDefault();
  const column = $(this).attr("data-column") ?? "id";
  const order = $(this).attr("data-order") ?? "desc";
  const url = urlMaker();
  const page_limit = $("#page_limit").val();
  const page_no = $(".active-pagination").attr("id") ?? 1;
  loadMasters(page_no, page_limit, url, column, order);
});

$("#searchBtn").on("click", function (e) {
  e.preventDefault();
  let form = $("#searchForm")[0];
  const page_limit = $("#page_limit").val();
  const url = urlMaker();
  if (form) {
    let formData = new FormData(form);
    formData.append("page_limit", page_limit);
    loadMasters(1, page_limit, url, undefined, undefined, formData);
  } else {
    console.error("Form element not found!");
  }
});

function loadMasters(
  page,
  page_limit,
  url,
  column = "id",
  order = "desc",
  formData = null
) {
  if (!formData) {
    formData = new FormData($("#searchForm")[0]);
  }
  formData.append("page", page);
  formData.append("page_limit", page_limit);
  formData.append("column", column);
  formData.append("order", order);
  $.ajax({
    url: url + "/view",
    method: "POST",
    data: formData,
    processData: false,
    contentType: false,
    dataType: "json",
    success: function (response) {
      // if (data.error) {
      // 	swal.fire({
      // 		title: "Error!",
      // 		text: data.message,
      // 		icon: "error",
      // 		confirmButtonText: "Ok",
      // 	});
      // }
      // $("#containerPage").html(response.pagination.pagination);
      $("#tableDiv").html(response.data);
      $("#totalRecord").html(response.total_records);
      $("#totalPage").html(response.total_pages);
    },
    error: function (xhr, status, error) {
      console.error("AJAX Error: " + error); // Log the error message
      // alert("There was an error with the request.");
    }
  });
}















$(document).ready(function () {
  reloadTable();
});







// =====================================   Delete For All ============================================== //
$(document).on('click', '.delete', function () {

  var deleteId = $(this).data('deleteid');
  var url = urlMaker();

  Swal.fire({
    title: "Are you sure?",
    text: "You won't be able to revert this!",
    icon: "warning",
    showCancelButton: true,
    confirmButtonColor: "#3085d6",
    cancelButtonColor: "#d33",
    confirmButtonText: "Yes, delete it!"
  }).then((result) => {
    if (result.isConfirmed) {
      $.ajax({
        url: url + '/delete',
        type: 'POST',
        data: { id: deleteId },
        success: function (response) {
          if (response.status) {

            Swal.fire({
              title: "Deleted!",
              text: response.message,
              icon: "success"
            });
            reloadTable();
          } else {
            Swal.fire({
              icon: "error",
              title: "Oops...",
              text: response.message,
            });
          }
        },
        error: function (xhr, status, error) {
          Swal.fire({
            icon: "error",
            title: "Oops...",
            text: error,
          });
        }
      });
    }
  });

  // ===============================================================================================
});

const uploadurl = 'http://localhost/ci/public/uploads/images/';

$(document).on('click', '.edit', function () {
  var editId = $(this).data('editid');
  $('.usubmit').html('<button type="submit" class="btn btn-primary button-90 uupdate" id="update">Update</button>');
  $('#fieldId').val(editId);
  $('.AllForm').data('request', 'update');
  var url = urlMaker();
  $.ajax({
    url: url + '/edit',
    type: 'POST',
    data: { id: editId },
    success: function (response) {
      // console.log(response);
      if (response.status) {
        $('#profile-tab').text('Update').tab('show');
        var data = response.data;
        // console.log(data);
        for (var key in data) {
          if (data.hasOwnProperty(key)) {
            var element = $('#' + key);
            if (key === 'password') {
              $('#password').attr('placeholder', '●●●●●●●●●●●●●●');
              $('#password').attr('name', '');

            }
            else if (element.length) {
              element.val(data[key]);
            }

            if (key === 'profile_pic') {
              const img = new Image();
              img.src = uploadurl + data[key];
              img.onload = function () {
                $('#profile-image').attr('src', img.src).css({
                  'width': '70px',
                  'height': '70px',
                  'border-radius': '50%',
                  'object-fit': 'cover'
                });
              };

              img.onerror = function () {
                $('#profile-image').attr('src', uploadurl + 'upload.png');
              };
            }
          }
        }
      } else {
        // alert('Failed to fetch data');
      }
    },
    error: function (xhr, status, error) {
      // Handle error
      alert('Error: ' + error);
    }
  });
});

$('#resetSearch').on('click', function () {
  $('#searchForm')[0].reset();
   $('#searchBtn').trigger('click');
});

// ======================  on Change tab =============================

function resetAll() {
  $(".error").html("");
  $("input").val("");
  $('#profile-image').attr('src', uploadurl + 'upload.png').css({
    'width': '50px',
    'height': '50px',
    'border-radius': '0%',
    'object-fit': 'cover'
  });
}


$('#home-tab').click(function () {
  $('#profile-tab').text('Add User');
  $('.usubmit').html('<button type="submit" class="btn btn-primary button-90 "id="submit">Submit</button>');
  $('#password').attr('placeholder', 'Enter Your Password');
  $('#home-tab').tab('show');
  resetAll();
});


$(".reset").on("click", function (e) {
  resetAll();
});

$(document).on('click', '.tableimage', function () {
  console.log("clicked");
var imageSrc = $(this).attr("src");
console.log(imageSrc); 

Swal.fire({
  imageUrl: imageSrc,
  imageWidth: 250,
  imageHeight: 250,
  imageAlt: "Custom image",
  showCloseButton: true,
  closeButtonHtml: '&times;',
  showConfirmButton: false,
  customClass: {
    popup: 'custom-popup', 
  }
});
});


