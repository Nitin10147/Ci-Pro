<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class Invoicemaster extends Migration
{
    public function up()
    {
        // Create invoicemaster table
        $this->forge->addField([
            'invoice_id' => [
                'type'           => 'INT',
                'constraint'     => 11,
                'auto_increment' => true,
            ],
            'invoice_no' => [
                'type'       => 'VARCHAR',
                'constraint' => '50',
            ],
            'client_id' => [
                'type'       => 'INT',
                'constraint' => 11,
            ],
            'invoice_date' => [
                'type'    => 'DATETIME',
                'default' => 'CURRENT_TIMESTAMP',
            ],
            'total_amount' => [
                'type'       => 'DECIMAL',
                'constraint' => '10,2',
            ],
            'createdAt' => [
                'type'    => 'DATETIME',
                'default' => 'CURRENT_TIMESTAMP',
            ],
        ]);

        $this->forge->addKey('invoice_id', true);  
        $this->forge->addForeignKey('client_id', 'clientmaster', 'id', 'CASCADE', 'CASCADE');
        $this->forge->createTable('invoicemaster');

    }
    public function down()
    {
        // Drop the tables
        $this->forge->dropTable('invoice');
        $this->forge->dropTable('invoicemaster');
    }
}
