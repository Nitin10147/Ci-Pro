<?php

namespace App\Models;

use CodeIgniter\Model;
use CodeIgniter\Database\Exceptions\DatabaseException;

class Invoicemaster extends Model
{
    protected $table      = 'invoicemaster';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;
    protected $returnType       = 'array';
    protected $useSoftDeletes   = false;
    protected $protectFields    = true;
   



   
    public function deleteuser($id)
    {
        try {
            $builder = $this->db->table('invoice');
            $delete_items = $builder->delete(['invoice_id' => $id]);

            if (!$delete_items) {
                throw new \Exception("Failed to delete invoice items.");
            }

            $builder = $this->db->table('invoicemaster');
            $delete_master = $builder->delete(['invoice_id' => $id]);

            if (!$delete_master) {
                throw new \Exception("Failed to delete invoice master.");
            }

            return [
                'status' => true,
                'message' => 'Data Deleted Successfully',
                'table_name' => 'invoice_master'
            ];
        } catch (\Exception $e) {
            return [
                'status' => false,
                'message' => 'Error: ' . $e->getMessage(),
                'table_name' => 'invoice_master'
            ];
        }
    }

    public function fetch( $sort_column2, $sort_order, $page_limit, $offset, $invoice_no, $name, $email, $phone, $start_date, $end_date)
    {
        // try {
            $builder = $this->db->table('invoicemaster im');
            $builder->select("im.invoice_id, im.invoice_no, im.invoice_date, im.total_amount, cm.first_name as first_name, cm.last_name as last_name,
                   CONCAT(
                       COALESCE(cm.address, ''), ', ', 
                       COALESCE(dt.district_name, ''), ', ', 
                       COALESCE(st.state_name, ''), '- ', 
                       COALESCE(cm.zip, '')) as address, 
                   cm.email, cm.mobile_number");
            $builder->join('clientmaster cm', 'cm.id = im.client_id', 'left');
            $builder->join('state_master st', 'st.state_id = cm.state', 'left');
            $builder->join('district_master dt', 'dt.district_id = cm.city', 'left');
            
          
            if (!empty($invoice_no)) {
                $builder->where('im.invoice_no', $invoice_no);
            }
            if (!empty($email)) {
                $builder->where('cm.email', $email);
            }
            if (!empty($phone)) {
                $builder->where('cm.mobile_number', $phone);
            }
            if (!empty($start_date)) {
                $builder->where('im.invoice_date >=', $start_date);
            }
            if (!empty($end_date)) {
                $builder->where('im.invoice_date <=', $end_date);
            }
            if (!empty($name)) {
                $nameParts = explode(' ', $name);
                if (count($nameParts) > 1) {
                    $firstName = $nameParts[0];
                    $lastName = $nameParts[1];
                    $builder->like('cm.first_name', $firstName)->orLike('cm.last_name', $lastName);
                }
            }
            if (!empty($start_date) && !empty($end_date)) {
                $builder->where('im.invoice_date >=', $start_date);
                $builder->where('im.invoice_date <=', $end_date);
            }


            if (!empty($sort_column2) && !empty($sort_order)) {
                $builder->orderBy($sort_column2, $sort_order);
            }

            $builder->limit($page_limit, $offset);
            $query = $builder->get();
            $data = $query->getResultArray();

            $builderCount = $this->db->table('invoicemaster im');
            $builderCount->select("im.invoice_id, im.invoice_no, im.invoice_date, im.total_amount, cm.first_name as first_name, cm.last_name as last_name,
            CONCAT(
                COALESCE(cm.address, ''), ', ', 
                COALESCE(dt.district_name, ''), ', ', 
                COALESCE(st.state_name, ''), '- ', 
                COALESCE(cm.zip, '')) as address, 
            cm.email, cm.mobile_number");
            $builderCount->join('clientmaster cm', 'cm.id = im.client_id', 'left');
            $builderCount->join('state_master st', 'st.state_id = cm.state', 'left');
            $builderCount->join('district_master dt', 'dt.district_id = cm.city', 'left');

            // Apply same filters to count query
            if (!empty($invoice_no)) {
                $builderCount->where('im.invoice_no', $invoice_no);
            }
            if (!empty($email)) {
                $builderCount->where('cm.email', $email);
            }
            if (!empty($phone)) {
                $builderCount->where('cm.mobile_number', $phone);
            }
            if (!empty($start_date)) {
                $builderCount->where('im.invoice_date >=', $start_date);
            }
            if (!empty($end_date)) {
                $builderCount->where('im.invoice_date <=', $end_date);
            }
            if (!empty($name)) {
                $builderCount->where('cm.first_name', $name);
            }
            if (!empty($start_date) && !empty($end_date)) {
                $builderCount->where('im.invoice_date >=', $start_date);
                $builderCount->where('im.invoice_date <=', $end_date);
            }

            $total_count = $builderCount->countAllResults();
            return [
                'data' => $data,
                'count' => $total_count,
            ];
        // } catch (\Exception $e) {
        //     log_message('error', $e->getMessage());
        //     return false;
        // }
    }


    public function getDataForInvoice($invoice_id)
    {
        try {
            $builder = $this->db->table('invoicemaster im');
    
            $builder->select('
                im.invoice_id,
                im.invoice_no,
                im.invoice_date,
                im.client_id,
                CONCAT(cm.first_name, " ", cm.last_name) AS client_name,
                cm.email AS client_email,
                cm.mobile_number AS client_phone,
                CONCAT(cm.address, ", ", cm.city, ", ", cm.state, ", ", cm.zip) AS address,
                GROUP_CONCAT(idt.item_id SEPARATOR ", ") AS item_ids,
                GROUP_CONCAT(itm.item_name SEPARATOR ", ") AS item_names,
                GROUP_CONCAT(idt.quantity SEPARATOR ", ") AS quantities,
                GROUP_CONCAT(itm.price SEPARATOR ", ") AS item_prices,
                im.total_amount
            ');
            $builder->join('clientmaster cm', 'im.client_id = cm.id', 'inner');
            $builder->join('invoice idt', 'im.invoice_id = idt.invoice_id', 'inner');
            $builder->join('itemmaster itm', 'idt.item_id = itm.id', 'inner');
            $builder->where('im.invoice_id', $invoice_id);
            $query = $builder->get();
            return $query->getRowArray();
        } catch (\Exception $e) {
            return $e->getMessage();
        }
    }
    

}