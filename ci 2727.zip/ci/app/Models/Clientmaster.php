<?php

namespace App\Models;
use CodeIgniter\Database\Exceptions\DatabaseException;


use CodeIgniter\Model;

class Clientmaster extends Model
{
    protected $table            = 'clientmaster';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;
    protected $returnType       = 'array';
    protected $useSoftDeletes   = false;
    protected $protectFields    = true;
    protected $allowedFields    = [
        'id',
        'first_name',
        'last_name',
        'email',
        'mobile_number',
        'address',
        'state',
        'city',
        'zip'
    ];



    public function addUpdate(array $data)
    {

        $reqType = $data['req_type'];
        unset($data['req_type']);

        if ($reqType === 'add') {
            return $this->addUser($data);
        } elseif ($reqType === 'update') {
            return $this->updateUser($data);
        }
        return ['status' => false, 'message' => 'Invalid request type'];
    }

 
    private function addUser(array $data)
    {
        unset($data['id']);

        try {
            $this->insert($data);
            return [
                'status' => true,
                'message' => 'Data Inserted Successfully',
                'table_name' => $this->table,
                'id' => $this->db->insertID()
            ];
        } catch (DatabaseException $e) {
            return [
                'status' => false,
                'message' => 'Database error: ' . $e->getMessage(),
                'table_name' => $this->table
            ];
        }
    }

    private function updateUser(array $data)
    {
        // print_r($data);
        $id = $data['id'];
        try {
            $updated = $this->update($id, $data);
            // echo $this->getLastQuery();
            if ($updated) {
                return [
                    'status' => true,
                    'message' => 'Data Updated Successfully',
                    'table_name' => $this->table
                ];
            } else {
                return [
                    'status' => false,
                    'message' => 'No changes were made to the data.',
                    'table_name' => $this->table
                ];
            }
        } catch (DatabaseException $e) {
            return [
                'status' => false,
                'message' => 'Database error: ' . $e->getMessage(),
                'table_name' => $this->table
            ];
        }
    }

    public function deleteuser($id)
    {
        try {
            $this->delete($id);
            return [
                'status' => true,
                'message' => 'Data Deleted Successfully',
                'table_name' => $this->table
            ];
        } catch (DatabaseException $e) {
            return [
                'status' => false,
                'message' => 'Database error: ' . $e->getMessage(),
                'table_name' => $this->table
            ];
        }
    }


    public function getuserData($id)
    {
        try {
            $result = $this->where('id', $id)->first();
            return [
                'status' => true,
                'data' => $result,
                'table_name' => $this->table
            ];
        } catch (DatabaseException $e) {
            return [
                'status' => false,
                'message' => 'Database error: ' . $e->getMessage(),
                'table_name' => $this->table
            ];
        }
    }


    public function fetch($sort_column2, $sort_order, $page_limit, $offset, $name=" ", $email="", $phone=" ")
    {
        try {
          
            $table_name = 'clientmaster';
            $builder = $this->db->table($table_name . ' as cm')
                ->select('cm.id as id, cm.first_name as first_name,  cm.last_name as last_name, cm.email as email, cm.mobile_number as mobile_number, concat(cm.address, ", ", district.district_name, ", ", state.state_name, "- ", cm.zip) as address')
                ->join('district_master as district', 'district.district_id = cm.city', 'left')
                ->join('state_master as state', 'state.state_id = cm.state', 'left');

          
            if (!empty($name)) {
                $builder->like('first_name', $name);
            }
            if (!empty($email)) {
                $builder->where('cm.email', $email);
            }
            if (!empty($phone)) {
                $builder->where('cm.mobile_number', $phone);
            }
            // if (!empty($address)) {
            //     $builder->groupStart() 
            //         ->like('cm.address', $address)
            //         ->orLike('district.district_name', $address)
            //         ->orLike('state.state_name', $address)
            //         ->groupEnd();  
            // }

    
            if (!empty($sort_column2) && !empty($sort_order)) {
                $builder->orderBy('cm.' . $sort_column2, $sort_order);
            }

            $builder->limit($page_limit, $offset);
            $data = $builder->get()->getResultArray();
            // echo $this->db->getLastQuery();
            
            $builderCount = $this->db->table($table_name . ' as cm')
                ->join('district_master as d', 'cm.city = d.district_id', 'left')
                ->join('state_master as s', 'cm.state = s.state_id', 'left');

            if (!empty($name)) {
                $builderCount->like('cm.first_name', $name);
            }
            if (!empty($email)) {
                $builderCount->where('cm.email', $email);
            }
            if (!empty($phone)) {
                $builderCount->where('cm.mobile_number', $phone);
            }
            if (!empty($address)) {
                $builderCount->groupStart()
                    ->like('cm.address', $address)
                    ->orLike('d.district_name', $address)
                    ->orLike('s.state_name', $address)
                    ->groupEnd();
            }

            $total_count = $builderCount->countAllResults();
            // echo $this->db->getLastQuery();

            return [
                'count' => $total_count,  
                'data' => $data           
            ];
        } catch (DatabaseException $e) {
            return ['status' => false, 'message' => $e->getMessage(), 'table_name' => $table_name];
        }
    }

    
     
    public function getStates()
    {
        try {
            $query = $this->db->table('state_master')
                              ->select('state_id, state_name')
                              ->get();
            
            return $query->getResultArray();
        } catch (DatabaseException $e) {
            return $e->getMessage();
        }
    }

    public function getCities($state_id)
    {
        try {
            $query = $this->db->table('district_master')
                              ->select('district_id, district_name')
                              ->where('state_id', $state_id)
                              ->get();
            
            return $query->getResultArray();
        } catch (DatabaseException $e) {
            return $e->getMessage();
        }
    }
 
}
