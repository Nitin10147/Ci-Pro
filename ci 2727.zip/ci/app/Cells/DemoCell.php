<?php

namespace App\Cells;

use CodeIgniter\View\Cells\Cell;

class DemoCell extends Cell
{
    public function render(): string
    {
        return view('Cells/alert', ['type' => 'success', 'message' => 'Hello World!']);
    }
}
