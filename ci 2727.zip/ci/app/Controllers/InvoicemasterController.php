<?php

namespace App\Controllers;
use App\Controllers\BaseController;
use CodeIgniter\HTTP\ResponseInterface;
require_once FCPATH . 'vendor/autoload.php';
use Mpdf\Mpdf;

class InvoicemasterController extends BaseController
{
    public function index()
    {
        return view('Invoicemaster/invoicemaster');
    }

    public function addupdate()
    {
      

    }

    public function delete()
    {
        $id = $this->request->getPost('id');
        $userModel = new \App\Models\Invoicemaster();
        $result = $userModel->deleteuser($id);
        return $this->response->setJSON($result);

    }
    public function edit()
    {

    }

    public function pdfGenerate()
    {
        $invoice_id = $this->request->getPost('invoice_id');
        $invoiceModel = new \App\Models\Invoicemaster();
        $data = $invoiceModel->getDataForInvoice($invoice_id);
        // $numberToword = service('pdfgenerator')->numberToWords($data['total_amount']);
        // $data['numberToword'] = $numberToword;
        print_r($data);
        $html = view('Invoicemaster/invoice_pdf', ['data' => $data]);
        $mpdf = new Mpdf();

        $mpdf->WriteHTML($html);
        $invoice_folder = WRITEPATH . 'invoice_pdf/';
        if (!is_dir($invoice_folder)) {
            mkdir($invoice_folder, 0777, true);
        }
        $file_name = $invoice_id . '.pdf';
        $file_path = $invoice_folder . $file_name;
        $mpdf->Output($file_path, 'F');
        return redirect()->to(base_url('invoice_pdf/' . $file_name));
    }


    public function view()
    {
        helper('pagination');
        $page_limit = $this->request->getPost('page_limit') !== null && $this->request->getPost('page_limit') !== "undefined" ? (int) $this->request->getPost('page_limit') : 5;
        $page_no = $this->request->getPost('page') !== null && $this->request->getPost('page') !== "undefined" ? (int) $this->request->getPost('page') : 1;

        $sort_column2 = $this->request->getPost('column') ?? 'id';
        $sort_order = $this->request->getPost('order') ?? 'DESC';

        $offset = ($page_no - 1) * $page_limit;

        $invoice_no = !empty($this->request->getPost('search_invoice_no')) ? trim($this->request->getPost('search_invoice_no')) : "";
        $name = !empty($this->request->getPost('search_name')) ? trim($this->request->getPost('search_name')) : "";
        $email = !empty($this->request->getPost('search_email')) ? trim($this->request->getPost('search_email')) : "";
        $phone = !empty($this->request->getPost('search_phone')) ? trim($this->request->getPost('search_phone')) : "";
        $start_date = !empty($this->request->getPost('date_from')) ? trim($this->request->getPost('date_from')) : "";
        $end_date = !empty($this->request->getPost('date_to')) ? trim($this->request->getPost('date_to')) : "";

        $invoiceModel = new \App\Models\Invoicemaster();

        $queryData = $invoiceModel->fetch($sort_column2, $sort_order, $page_limit, $offset, $invoice_no, $name, $email, $phone, $start_date, $end_date);
        $result = $queryData['data'];
        $total_records = $queryData['count'];
        $columns = ['invoice_id', 'invoice_no', 'invoice_date', 'total_amount', 'first_name', 'address', 'email', 'mobile_number'];

        $output = '<div class="table-wrap">
            <table class="table table-bordered scrollable">
                <thead class="table-secondary">
                    <tr>
                        <th scope="col" class="text-center" style="width: 50px;">Sr.No</th>';

        foreach ($columns as $column) {
            $new_sort_order = 'ASC';
            $sort_icons = '<i class="fa fa-sort-amount-desc" aria-hidden="true"></i>';

            $new_sort_order = ($sort_column2 == $column && $sort_order == 'ASC') ? 'DESC' : 'ASC';
            $sort_icons = ($sort_column2 == $column && $sort_order == 'ASC') ? '<i class="fa fa-sort-alpha-asc" aria-hidden="true"></i>' : '<i class="fa fa-sort-alpha-desc" aria-hidden="true"></i>';

            $output .= $this->generateColumnHeader($column, $new_sort_order, $sort_icons);
        }

        $output .= '<th scope="col" class="text-center" style="width: 250px;">Action</th></tr></thead><tbody>';

        if (!empty($result)) {
            $s_no = $offset + 1;
            foreach ($result as $row) {
                $output .= '<tr>';
                $output .= '<td class="text-center">' . $s_no++ . '</td>';
                $output .= '<td style="width: 100px;" class="text-end" >' . $row['invoice_id'] . '</td>';
                $output .= '<td style="width: 100px;"class="text-end" >' . $row['invoice_no'] . '</td>';
                $output .= '<td style="width: 150px;" >' . date('d-m-Y', strtotime($row['invoice_date'])) . '</td>';
                $output .= '<td style="width: 150px;" class="text-end">₹ ' . $row['total_amount'] . '</td>';
                $output .= '<td style="width: 150px;" >' . $row['first_name'] . ' ' . $row['first_name'] . '</td>';
                $output .= '<td style="width: 250px;" >' . $row['address'] . '</td>';
                $output .= '<td style="width: 150px;" >' . $row['email'] . '</td>';
                $output .= '<td style="width: 150px;" class="text-end">' . $row['mobile_number'] . '</td>';
                $output .= $this->generateActionButtons($row['invoice_id'], $row['email']);
                $output .= '</tr>';
            }
        } else {
            $output .= '<tr><td colspan="10" class="text-center text-danger font-weight-bold" style="font-size: 16px; background-color: rgba(255, 0, 0, 0.1);">No Data Found</td></tr>';
        }

        $output .= '</tbody></table></div>';

        $pagination = pagination($page_no, $total_records, $page_limit);
        echo json_encode([
            'data' => $output,
            'pagination' => $pagination,
            'total_records' => $total_records,
            'total_pages' => $pagination['total_page']
        ]);
    }
    private function generateColumnHeader($column, $new_sort_order, $sort_icons)
    {
        return '<th scope="col" class="text-center" style="width: 150px;">
                        <a class="column_sort text-black" href="#" data-column="' . $column . '" data-order="' . $new_sort_order . '" style="align-items: center; gap: 5px;">
                            <span>' . ucfirst($column) . '</span>
                            ' . $sort_icons . '
                        </a>
                    </th>';
    }

    private function generateActionButtons($id, $email)
    {
        return '<td class="text-center" style="width: 250px;">
                <button class="btn btn-info btn-sm pdf-generate" invoice_id="' . $id . '" style="padding: 4px 6px; font-size: 12px;">
                  <i class="fa fa-file" aria-hidden="true" style="width: 16px; height: 16px;"></i>
                </button>
                <button class="btn btn-primary btn-sm email_send" email_id="' . $id . '" client_email="' . $email . '" style="padding: 4px 6px; font-size: 12px;">
                  <i class="fa fa-envelope" aria-hidden="true" style="width: 16px; height: 16px;"></i>
                </button>
                <button class="btn btn-secondary btn-sm edit" edit_id="' . $id . '" style="padding: 4px 6px; font-size: 12px;">
                  <i class="fa fa-pencil" aria-hidden="true" style="width: 16px; height: 16px;"></i>
                </button>
                <button class="btn btn-danger btn-sm delete" data-deleteid="' . $id . '" style="padding: 4px 6px; font-size: 12px;">
                   <i class="fa fa-trash" aria-hidden="true" style="width: 16px; height: 16px;"></i>
                </button>
            </td>';
    }

}



