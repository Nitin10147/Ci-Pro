<div class="d-flex justify-content-between align-items-end mb-1 mt-1">
    <div class="container mt-1 searchcontainer">

        <button class="btn " type="button" id="togglerButton">
            ▼ &nbsp Search Form
        </button>


        <div id="searchBarContainer" class="collapse">
            <form action="" if="searchForm" method="POST" class="form-inline">
                <input type="text" name="searchname" id="Namesearch" class="form-control search" placeholder=" Name ">
                <input type="text" name="searchemail" id="Emailsearch" class="form-control search" placeholder="Email">
                <input type="text" name="searchphone" id="Phonesearch" class="form-control search"
                    placeholder="Phone Number">

                <button type="button" id="searchButton" class="btn btn-primary button-90 " id="submit"
                    style="margin-right: 10px">Search</button></span>
                <button type="reset" class="btn btn-secondary button-80" id="resetSearch">Reset</button>
            </form>
        </div>
    </div>
</div>

<div class="d-flex flex-row  flex-row-reverse">
    <select id="page_limit" style="width: 55px; margin-top: 20px; margin-right: 20px; display: inline-block">
        <option value="5" selected>5</option>
        <option value="10">10</option>
        <option value="15">15</option>
        <option value="20">20</option>
        <option value="25">25</option>
        <option value="30">30</option>
    </select>
</div>
<div class="dynamicPagination mr-3"></div>
<div id="tableList" class="table-responsive card-body"></div>