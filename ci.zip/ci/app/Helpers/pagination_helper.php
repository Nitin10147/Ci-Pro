<?php

function pagination($page_no, $total_data, $page_limit)
{
    try {
        $total_page = ($total_data > 0 && $page_limit > 0) ? ceil($total_data / $page_limit) : 1;
        if ($total_page == 1) {
            return ['pagination' => '', 'total_page' => $total_page];
        }
        $previous_page = max(1, $page_no - 1);
        $next_page = min($total_page, $page_no + 1);

        $output = '<div><div class="paginationDiv" style="margin-top: 8px;">';
        if ($page_no > 1) {
            $output .= '<span class="pagination_link" style="cursor:pointer; padding:6px; font-size:13px; border:1px solid rgb(37, 92, 119); border-top-left-radius:5px; border-bottom-left-radius:5px;" id="1">First</span>';
            $output .= '<span class="pagination_link" style="cursor:pointer; padding:6px; font-size:13px; border:1px solid rgb(37, 92, 119);" id="' . $previous_page . '"><<</span>';
        }
        for ($i = 1; $i <= $total_page; $i++) {
            if ($i == $page_no) {
                $output .= "<span class='pagination_link active-pagination' style='cursor:pointer; pointer-events: none; padding:6px; border:1px solid rgb(37, 92, 119); color:#fff; font-size:13px; background-color:#169F85;' id='$i'>$i</span>";
            } elseif ($i >= ($page_no - 2) && $i <= ($page_no + 2)) {
                $output .= "<span class='pagination_link' style='cursor:pointer; padding:6px; border:1px solid rgb(37, 92, 119); font-size:13px;' id='$i'>$i</span>";
            }
        }
        if ($page_no < $total_page) {
            $output .= '<span class="pagination_link" style="cursor:pointer; padding:6px; border:1px solid rgb(37, 92, 119); font-size:13px;" id="' . $next_page . '">>></span>';
            $output .= '<span class="pagination_link" style="cursor:pointer; padding:6px; font-size:13px; border:1px solid rgb(37, 92, 119); border-top-right-radius:5px; border-bottom-right-radius:5px;" id="' . $total_page . '">Last</span>';
        }

        $output .= '</div></div>';

        return [
            'pagination' => $output,
            'total_page' => $total_page,
        ];
    } catch (Exception $e) {

    }
}


?>