//======================= This Js is For Login Page ===========================

$("#loginform").submit(function (e) {
  e.preventDefault();

  isvalid = false;

  let base_url = $("#baseUrl").val();

  $("#loginform")
    .find("input, select, textarea")
    .each(function () {
      var fieldName = $(this).attr("name");
      var errorSpan = $("#" + fieldName + "Error");
      var fieldValue = $(this).val().trim();

      isvalid = validate(fieldName, fieldValue);
    });

  if (isvalid) {
    let formData = new FormData(loginform);
    $.ajax({
      url: base_url + "login",
      type: "POST",
      data: formData,
      processData: false,
      contentType: false,
      dataType: "json",
      success: function (response) {
        if (response.status) {
          window.location.href = base_url + "dashboard";
        } else {
          Swal.fire({
            icon: "error",
            title: "Oops...",
            text: response.message,
          });

        }
      },
      error: function (response) {
        $("#loginError").text("Something went wrong. Please try again.");
      },
    });
  }
});

// ====== on input validation ==============
$("#loginform")
  .find("input, textarea")
  .on("input", function () {
    const name_value = $(this).attr("name");
    let value = $(this).val();
    $(this).val(value);
    validate(name_value, value);
  });

$("#captcha-input").on("input", function () {
  $("#captachaError").text("");
});

// ========= logout ================
$("#logout").click(function () {
  $.ajax({
    url: base_url + "logout",
  });
});

// ================================== Login Form JS ================================
$(document).ready(function () {
  $(".input-field").each(function () {
    $(this).on("focus", function () {
      $(this).addClass("active");
    });
    $(this).on("blur", function () {
      if ($(this).val() != "") return;
      $(this).removeClass("active");
    });
  });

  $(".toggle").each(function () {
    $(this).on("click", function () {
      $("main").toggleClass("sign-up-mode");
    });
  });

  function moveSlider() {
    let index = $(this).data("value");

    let currentImage = $(".img-" + index);
    $(".image").removeClass("show");
    currentImage.addClass("show");

    const textSlider = $(".text-group");
    textSlider.css("transform", `translateY(${-(index - 1) * 2.2}rem)`);

    $(".bullets span").removeClass("active");
    $(this).addClass("active");
  }

  $(".bullets span").each(function () {
    $(this).on("click", moveSlider);
  });

  // ============================ Function To GenerEATE Captcha ===============================

  function generateCaptcha() {
    const chars =
      "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
    let captcha = "";
    for (let i = 0; i < 6; i++) {
      captcha += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    $("#captcha").text(captcha);
  }

  function verifyCaptcha() {
    const captchaInput = $("#captcha-input").val();
    const captchaText = $("#captcha").text();

    if (captchaInput !== captchaText) {
      // alert("Captcha doesn't match. Please try again.");
      $("#captachaError").html(`Captcha doesn't match. Please try again.`);
      return false;
    }
    return true;
  }

  generateCaptcha();

  $("form").on("submit", function (event) {
    if (!verifyCaptcha()) {
      event.preventDefault();
    }
  });

  $("#refreshCaptcha").on("click", generateCaptcha);
});

// ========================================== VALIDATE=========================================
function validate(name_value, value) {
  let isValid = true;

  const error = (selector, message) => {
    const element = document.querySelector(selector);
    if (element) {
      element.innerText = message;
    } else {
    }
    isValid = false;
  };

  const clearError = (selector) => {
    const element = document.querySelector(selector);
    if (element) {
      element.innerText = "";
    }
  };

  if (name_value === "email") {
    const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,3}$/;
    if (!value) {
      error("#emailError", "*Email is required.");
    } else if (!emailRegex.test(value)) {
      error("#emailError", "*Please enter a valid email address.");
    } else {
      clearError("#emailError");
    }
  }

  if (name_value === "password") {
    if (!value) {
      error("#passwordError", "*Password is required.");
    } else {
      clearError("#passwordError");
    }
  }

  return isValid;
}



// =======================================  Forgot Password ==========================================
$("#forgotform").submit(function (event) {
  event.preventDefault();
  let base_url = $("#baseUrl").val();
  const email = $("#Forgotemail").val();
  $.ajax({
    url: base_url + "checkEmailExist",
    type: "POST",
    data: { email },
    success: function (response) {
      console.log(response);
      if (response.status) {
        Swal.fire({
          title: "<h5>Please wait...</h5>",
          html: '<img class="img" src="http://localhost/ci/assets/images/send.gif" style="width: 60%; height: auto;"/>',
          showConfirmButton: false,
        });

        // ==============================================================================

        $.ajax({
          url: base_url + "sendForgotPassswordlink",
          type: "POST",
          data: {
            email: email,
          },
          dataType: "json",
          success: function (response) {
            console.log(response);
            if (response.status) {
              Swal.fire({
                icon: "success",
                text: response.message,
              });
            } else {
              Swal.fire({
                icon: "error",
                title: "Oops...",
                text: response.message,
              });
            }
          },
          // error: function() {
          //     alert("An error occurred while processing your request.");
          // }
        });

        // =============================================================================
      } else {
        Swal.fire({
          icon: "error",
          title: "Oops...",
          text: response.message,
        });
      }
    },
    error: function (response) {
      $("#forgotError").text("Something went wrong. Please try again.");
    },
  });
});
