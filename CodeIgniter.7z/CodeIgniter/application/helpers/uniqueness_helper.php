<?php
defined('BASEPATH') or exit('No direct script access allowed');

function uniqueHelper($fieldName , $table_name , $check_duplicate , $unique_field , $unique_value  ){


    $CI =& get_instance();

    if ($CI->input->post('type') == "update") {
        $CI->db->select('*');
        $CI->db->from($table_name);
        $CI->db->where($fieldName, $check_duplicate );
        $CI->db->where($unique_field.'!=', $unique_value);
        $query = $CI->db->get()->num_rows();
        if ($query > 0) {
           return $is_unique =  '|is_unique[' . $table_name . '.'.$fieldName.']';
        } else {
            return $is_unique = "";
        }
    } else {
       return $is_unique = '|is_unique[' . $table_name . '.'.$fieldName.']';
    }

}


// SELECT * 
// FROM table_name
// WHERE field_name = 'check_duplicate_value'
// AND unique_field != 'unique_value';
