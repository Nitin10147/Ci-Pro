<?php
class Item_Model extends CI_Model
{


    public function __construct()
    {
        parent::__construct();
        $this->load->database();
    }



    public function addUpdate($data)
    {
        $table_name = $data['table'];
        $reqtype = $data['type'];
        unset($data['table']);
        unset($data['type']);
        if ($reqtype == 'add') {
            unset($data['id']);
            try {
                $this->db->insert($table_name, $data);
                return ['status' => true, 'message' => 'Data Inserted Successfully', 'table_name' => $table_name, 'id' => $this->db->insert_id()];
            } catch (Exception $e) {
                return ['status' => false, 'message' => $e->getMessage(), 'table_name' => $table_name];
            }
        } else if ($reqtype == 'update') {
            try {
                if (empty($data['image'])) {
                    unset($data['image']);
                }
                $this->db->update($table_name, $data, ['id' => $data['id']]);
                return ['status' => true, 'message' => 'Data Updated Successfully', 'table_name' => $table_name, 'id' => $data['id']];
            } catch (Exception $e) {
                return ['status' => false, 'message' => $e->getMessage(), 'table_name' => $table_name];
            }
        }
    }


    public function fetch($sort_column1, $sort_column2, $sort_order, $page_limit, $offset, $name)
    {
        try {
            $table_name = $this->input->post('table') ?? 'item_master';
            $this->db->from($table_name);
            if (!empty($name)) {
                $this->db->where('item_name', $name);
            }

            // Apply sorting
            if (!empty($sort_column1) && !empty($sort_order)) {
                if ($sort_column2 == 'status') {      
                }else{
                    $this->db->order_by("status", "desc");
                }    
            }

            if (!empty($sort_column2) && !empty($sort_order)) {
                $this->db->order_by($sort_column2, $sort_order);
            }

            // Apply limit and offset for pagination
            $this->db->limit($page_limit, $offset);
            $query = $this->db->get();
            $data = $query->result_array();

            // To get the correct total count
            $this->db->from($table_name);

            // Reapply the filters
            if (!empty($name)) {
                $this->db->like('item_name', $name);
            }

            // Get the total count after filtering
            $total_count = $this->db->count_all_results();
            // Return data and count
            return [
                'count' => $total_count,  // Total count of filtered data
                'data' => $data           // Data for current page
            ];
        } catch (Exception $e) {
            return json_encode(['status' => false, 'message' => $e->getMessage(), 'table_name' => $table_name]);
        }
    }

    public function edit($id)
    {
        try {
            $table_name = $this->input->post('table') ?? 'item_master';
            $data = $this->db->get_where($table_name, ['id' => $id])->result_array();
            return $data;
        } catch (Exception $e) {
            return json_encode(['status' => false, 'message' => $e->getMessage(), 'table_name' => $table_name]);
        }
    }

    public function delete($id)
{
 
    $table_name = $this->input->post('table') ?? 'item_master';
    try {
        $this->db->delete($table_name, ['id' => $id]);
        // Check if any row was deleted
        if ($this->db->affected_rows() > 0) {
            return json_encode(['status' => true, 'message' => 'Data Deleted Successfully', 'table_name' => $table_name]);
        } else {
            return json_encode(['status' => false, 'message' => 'No matching data found to delete', 'table_name' => $table_name]);
        }
    } catch (Exception $e) {
        return json_encode(['status' => false, 'message' => $e->getMessage(), 'table_name' => $table_name]);
    }
}

}
