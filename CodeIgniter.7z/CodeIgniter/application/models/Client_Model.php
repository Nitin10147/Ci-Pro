<?php
class Client_Model extends CI_Model
{


    public function __construct()
    {
        parent::__construct();
        $this->load->database();
    }



    public function addUpdate($data)
    {
        $table_name = $data['table'];
        $reqtype = $data['type'];
        unset($data['table']);
        unset($data['type']);
        if ($reqtype == 'add') {
            unset($data['id']);
            try {
                $this->db->insert($table_name, $data);
                return ['status' => true, 'message' => 'Data Inserted Successfully', 'table_name' => $table_name, 'id' => $this->db->insert_id()];
            } catch (Exception $e) {
                return ['status' => false, 'message' => $e->getMessage(), 'table_name' => $table_name];
            }
        } else if ($reqtype == 'update') {
            try {
                $this->db->update($table_name, $data, ['id' => $data['id']]);
                return ['status' => true, 'message' => 'Data Updated Successfully', 'table_name' => $table_name, 'id' => $data['id']];
            } catch (Exception $e) {
                return ['status' => false, 'message' => $e->getMessage(), 'table_name' => $table_name];
            }
        }
    }


    public function fetch($sort_column1, $sort_column2, $sort_order, $page_limit, $offset, $name, $email, $phone, $address)
    {
        try {
            $table_name = $this->input->post('table') ?? 'client_master';
            $this->db->select('cm.id as id, cm.name as name, cm.email as email, cm.phone as phone, concat(cm.address, ", ", district.district_name, ", ", state.state_name, "- ", cm.pincode) as address,  cm.status');
            $this->db->from($table_name . ' as cm');
            $this->db->join('district_master as district', 'district.district_id = cm.city', 'left');
            $this->db->join('state_master as state', 'state.state_id = cm.state', 'left');
            if (!empty($name)) {
                $this->db->like('cm.name', $name);
            }
            if (!empty($email)) {
                $this->db->where('cm.email', $email);
            }
            if (!empty($phone)) {
                $this->db->where('cm.phone', $phone);
            }
            if (!empty($address)) {
                $this->db->like('cm.address', $address);
                $this->db->or_like('district.district_name', $address);
                $this->db->or_like('state.state_name', $address);
            }
            // Apply sorting
            if (!empty($sort_column1) && !empty($sort_order)) {
                if ($sort_column2 == 'status') {      
                }else{
                    $this->db->order_by("cm.status", "desc");
                }    
            }
            if (!empty($sort_column2) && !empty($sort_order)) {
                $this->db->order_by("cm.".$sort_column2, $sort_order);
            }
            // Apply limit and offset for pagination
            $this->db->limit($page_limit, $offset);
            $query = $this->db->get();
            $data = $query->result_array();
            // To get the correct total count
            $this->db->from($table_name . ' as cm');
            $this->db->join('district_master AS d', 'cm.city = d.district_id', 'left');
            $this->db->join('state_master AS s', 'cm.state = s.state_id', 'left');


            // Reapply the filters
            if (!empty($name)) {
                $this->db->like('cm.name', $name);
            }
            if (!empty($email)) {
                $this->db->where('cm.email', $email);
            }
            if (!empty($phone)) {
                $this->db->where('cm.phone', $phone);
            }
            if (!empty($address)) {
                $this->db->like('cm.address', $address);
                $this->db->or_like('d.district_name', $address);
                $this->db->or_like('s.state_name', $address);
            }
          
            // Get the total count after filtering
            $total_count = $this->db->count_all_results();

            // Return data and count
            return [
                'count' => $total_count,  // Total count of filtered data
                'data' => $data           // Data for current page
            ];
        } catch (Exception $e) {
            return ['status' => false, 'message' => $e->getMessage(), 'table_name' => $table_name];
        }
    }

    public function getStates()
    {
        try {
            $query = $this->db->select('state_id, state_name');
            $query = $this->db->get('state_master');
            return $query->result_array();
        } catch (Exception $e) {
            return $e->getMessage();
        }
    }

    public function getCities($state_id)
    {
        try {
            $this->db->where('state_id', $state_id);
            $query = $this->db->select('district_id, district_name');
            $query = $this->db->get('district_master');
            return $query->result_array();
        } catch (Exception $e) {
            return $e->getMessage();
        }
    }


    public function delete($id)
    {
        $table_name = $this->input->post('table') ?? 'client_master';
        try {
            $this->db->delete($table_name, ['id' => $id]);
            if ($this->db->affected_rows() > 0) {
                return json_encode(['status' => true, 'message' => 'Data Deleted Successfully', 'table_name' => $table_name]);
            } else {
                return json_encode(['status' => false, 'message' => 'No matching data found to delete', 'table_name' => $table_name]);
            }
        } catch (Exception $e) {
            return json_encode(['status' => false, 'message' => $e->getMessage(), 'table_name' => $table_name]);
        }
    }


    public function edit($id)
    {
        try {
            $table_name = $this->input->post('table') ?? 'client_master';
            $data = $this->db->get_where($table_name, ['id' => $id])->result_array();
            return $data;
        } catch (Exception $e) {
            return json_encode(['status' => false, 'message' => $e->getMessage(), 'table_name' => $table_name]);
        }
    }
}
