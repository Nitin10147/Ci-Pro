<?php 

class Dashboard_Model extends CI_Model{
    public function __construct()
    {
        parent::__construct();
        $this->load->database();
    }


    public function get_data(){
       $query = $this->db->query("CALL GetCounts()");
       return $query->result_array();
    }
}



?>