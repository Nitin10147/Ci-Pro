<?php

class Invoice_Model extends CI_Model
{

    public function __construct()
    {
        parent::__construct();
        $this->load->database();
    }

    public function client_autocomplete($name)
    {
        try {
            if (empty($name)) {
                return [];
            }
            $this->db->select('id, name, phone, email')
                ->like('name', $name, 'both') // 'both' for searching before and after the $name string
                ->where('status', 1);
            $result = $this->db->get('client_master')->result();
            return $result;
        } catch (Exception $e) {
            return json_encode(['status' => false, 'message' => $e->getMessage()]);
        }
    }


    public function item_autocomplete($name)
    {
        try {
            $name = trim($name);
            if (empty($name)) {
                return [];
            }
            $result = $this->db->select('id, item_name, price')
                ->like('item_name', $name, 'both')  // 'both' for searching before and after the $name string
                ->where('status', 1)
                ->get('item_master')
                ->result();
            return $result;
        } catch (Exception $e) {
            return json_encode(['status' => false, 'message' => $e->getMessage()]);
        }
    }


    public function addUpdate($data)
    {
        $table_name = $data['table'];
        $reqtype = $data['type'];
        if ($reqtype == 'add') {
            try {
                $invoiceData = [
                    'client_id' => $data['client_id'],
                    'invoice_no' => $data['invoice_no'],
                    'invoice_date' => $data['invoice_date'],
                    'total_amount' => $data['total_amount']
                ];
                $this->db->insert('invoice_master', $invoiceData);
                $invoice_id = $this->db->insert_id();
                $invoiceItems = [];
                foreach ($data['item_id'] as $key => $value) {
                    $invoiceItems[] = [
                        'item_id' => $value,
                        'invoice_id' => $invoice_id,
                        'quantity' => $data['quantity'][$key],
                        'price' => $data['price'][$key],
                        'total_price' => $data['amount'][$key],
                    ];
                }
                $this->db->insert_batch('invoice_items', $invoiceItems);
                return ['status' => true, 'message' => 'Invoice added successfully', 'table_name' => $table_name];
            } catch (Exception $e) {
                return ['status' => false, 'message' => $e->getMessage(), 'table_name' => $table_name];
            }
        } else if ($reqtype == 'update') {
            try {
                $invoiceData = [
                    'client_id' => $data['client_id'],
                    'invoice_no' => $data['invoice_no'],
                    'invoice_date' => $data['invoice_date'],
                    'total_amount' => $data['total_amount']
                ];
                $this->db->update('invoice_master', $invoiceData, ['id' => $data['id']]);
                $this->db->delete('invoice_items', ['invoice_id' => $data['id']]);
                $invoiceItems = [];
                foreach ($data['item_id'] as $key => $value) {
                    $invoiceItems[] = [
                        'item_id' => $value,
                        'invoice_id' => $data['id'],
                        'quantity' => $data['quantity'][$key],
                        'price' => $data['price'][$key],
                        'total_price' => $data['amount'][$key],
                    ];
                }
                $this->db->insert_batch('invoice_items', $invoiceItems);
                return ['status' => true, 'message' => 'Invoice updated successfully', 'table_name' => $table_name];
            } catch (Exception $e) {
                return ['status' => false, 'message' => $e->getMessage(), 'table_name' => $table_name];
            }
        }
    }

    public function generateInvoiceNo()
    {
        try {
            $this->db->select('invoice_no');
            $this->db->order_by('invoice_no', 'desc');
            $this->db->limit(1);
            $query = $this->db->get('invoice_master');
            if ($query->num_rows() > 0) {
                $lastInvoiceNo = $query->row()->invoice_no;
                $newInvoiceNo = $lastInvoiceNo + 1;
            } else {
                $newInvoiceNo = 1;
            }
            return $newInvoiceNo;
        } catch (Exception $e) {
            return $e->getMessage();
        }
    }


    public function fetch($sort_column1, $sort_column2, $sort_order, $page_limit, $offset, $invoice_no, $name, $email, $phone, $start_date, $end_date)
    {

        try {
            $this->db->select("im.id, im.invoice_no, im.invoice_date, im.total_amount, cm.name as client_name, 
                   CONCAT(
                       COALESCE(cm.address, ''), ', ', 
                       COALESCE(dt.district_name, ''), ', ', 
                       COALESCE(st.state_name, ''), '- ', 
                       COALESCE(cm.pincode, '')
                   ) as address, 
                   cm.email, cm.phone");
            $this->db->from('invoice_master im');
            $this->db->join('client_master cm', 'cm.id = im.client_id', 'left');
            $this->db->join('state_master st', 'st.state_id = cm.state', 'left');
            $this->db->join('district_master dt', 'dt.district_id = cm.city', 'left');


            // apply join from client_master and item_master
            if (!empty($invoice_no)) {
                $this->db->where('invoice_no', $invoice_no);
            }
            if (!empty($email)) {
                $this->db->where('email', $email);
            }
            if (!empty($phone)) {
                $this->db->where('phone', $phone);
            }
            if (!empty($start_date)) {
                $this->db->where('invoice_date >=', $start_date);
            }
            if (!empty($end_date)) {
                $this->db->where('invoice_date <=', $end_date);
            }
            if (!empty($name)) {
                $this->db->where('name', $name);
            }
            if (!empty($start_date) && !empty($end_date)) {
                $this->db->where('invoice_date >=', $start_date);
                $this->db->where('invoice_date <=', $end_date);
            }

            // Apply sorting
            if (!empty($sort_column1) && !empty($sort_order)) {
                $this->db->order_by($sort_column1, $sort_order);
            }
            if (!empty($sort_column2) && !empty($sort_order)) {
                $this->db->order_by($sort_column2, $sort_order);
            }
            // Apply limit and offset for pagination
            $this->db->limit($page_limit, $offset);
            $query = $this->db->get();
            $data = $query->result_array();
            // To get the correct total count
            $this->db->select("im.id, im.invoice_no, im.invoice_date, im.total_amount, cm.name as client_name, 
                   CONCAT(
                       COALESCE(cm.address, ''), ', ', 
                       COALESCE(dt.district_name, ''), ', ', 
                       COALESCE(st.state_name, ''), '- ', 
                       COALESCE(cm.pincode, '')
                   ) as address, 
                   cm.email, cm.phone");
            $this->db->from('invoice_master im');
            $this->db->join('client_master cm', 'cm.id = im.client_id', 'left');
            $this->db->join('state_master st', 'st.state_id = cm.state', 'left');
            $this->db->join('district_master dt', 'dt.district_id = cm.city', 'left');

            if (!empty($invoice_no)) {
                $this->db->where('invoice_no', $invoice_no);
            }
            if (!empty($email)) {
                $this->db->where('email', $email);
            }
            if (!empty($phone)) {
                $this->db->where('phone', $phone);
            }
            if (!empty($start_date)) {
                $this->db->where('invoice_date >=', $start_date);
            }
            if (!empty($end_date)) {
                $this->db->where('invoice_date <=', $end_date);
            }
            if (!empty($name)) {
                $this->db->where('name', $name);
            }
            if (!empty($start_date) && !empty($end_date)) {
                $this->db->where('invoice_date >=', $start_date);
                $this->db->where('invoice_date <=', $end_date);
            }
            $total_count = $this->db->count_all_results();
            return [
                'data' => $data,
                'count' => $total_count,
            ];
        } catch (Exception $e) {
            echo $e->getMessage();
        }
    }


    // getInvoiceData for pdf generation
    public function getDataForInvoice($invoice_id)
    {
        try {
            $this->db->select('
        im.id,
        im.invoice_no,
        im.invoice_date,
        im.client_id,
        cm.name AS client_name,
        cm.email AS client_email,
        cm.phone AS client_phone,
        CONCAT(cm.address, ", ", cm.city, ", ", cm.state, ", ", cm.pincode) AS address,
        GROUP_CONCAT(idt.item_id SEPARATOR ", ") AS item_ids,
        GROUP_CONCAT(itm.item_name SEPARATOR ", ") AS item_names,
        GROUP_CONCAT(idt.quantity SEPARATOR ", ") AS quantities,
        GROUP_CONCAT(itm.price SEPARATOR ", ") AS item_prices,
        im.total_amount
    ');
            $this->db->from('invoice_master im');
            $this->db->join('client_master cm', 'im.client_id = cm.id', 'inner');
            $this->db->join('invoice_items idt', 'im.id = idt.invoice_id', 'inner');
            $this->db->join('item_master itm', 'idt.item_id = itm.id', 'inner');
            $this->db->where('im.id', $invoice_id);
            $query = $this->db->get();
            return $query->row_array();
        } catch (Exception $e) {
            return $e->getMessage();
        }
    }

    public function delete($id)
    {

        try {
            // First, delete invoice items
            $this->db->where('invoice_id', $id);
            $delete_items = $this->db->delete('invoice_items');

            if (!$delete_items) {
                throw new Exception("Failed to delete invoice items.");
            }

            // Then, delete invoice master
            $this->db->where('id', $id);
            $delete_master = $this->db->delete('invoice_master');

            if (!$delete_master) {
                throw new Exception("Failed to delete invoice master.");
            }

            return json_encode([
                'status' => true,
                'message' => 'Data Deleted Successfully',
                'table_name' => 'invoice_master'
            ]);
        } catch (Exception $e) {
            // Log the error or return it in the response
            return json_encode([
                'status' => false,
                'message' => 'Error: ' . $e->getMessage(),
                'table_name' => 'invoice_master'
            ]);
        }
    }
}
