<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login_Model extends CI_Model
{
    public function __construct()
    {
        parent::__construct();
        $this->load->database();
    }
    public function checkLoginDetail($post) {
        try{
        $hashedPassword = md5($post['password']);
        $this->db->select('*');
        $this->db->from('user_master');
        $this->db->where('email', $post['email']);
        $this->db->where('password', $hashedPassword); 
        $result = $this->db->get()->row_array();
        return $result;
        } catch (Exception $e) {
            return json_encode(['status' => false, 'message' => $e->getMessage()]);
        }
    }



    public function get_user_by_email($email) {
        return $this->db->get_where('user_master', ['email' => $email])->row();
    }

    public function store_reset_token($email, $token, $expiry) {
        $data = [
            'reset_token' => $token,
            'reset_expiry' => $expiry
        ];
        $this->db->where('email', $email);
        $this->db->update('user_master', $data);
    }

    public function get_user_by_token($token) {
        return $this->db->get_where('user_master', ['reset_token' => $token])->row();
    }

    public function update_password($email, $new_password) {
        $this->db->where('email', $email);
        $this->db->update('user_master', ['password' => $new_password]);
    }

    public function clear_reset_token($email) {
        $this->db->where('email', $email);
        $this->db->update('user_master', ['reset_token' => NULL, 'reset_expiry' => NULL]);
    }
}