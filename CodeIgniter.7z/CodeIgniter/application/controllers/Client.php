<?php

class Client extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->model('Client_Model');
    }

    public function index()
    {
        $this->load->view('client/index');
    }



    public function addUpdate()
    {

        $post = $this->input->post();
        $table_name = $post['table'];
        $this->load->library('FormValidator');
        $validation_result = $this->formvalidator->validateForm($post, $table_name);
        if (!$validation_result['status']) {
            $errors = $validation_result['errors'];
            if (isset($errors['email']) || isset($errors['phone']) || isset($errors['item_name'])) {
                echo json_encode(["duplication_error" => true, "errors" => $errors]);
            } else {
                echo json_encode(["error" => false, "errors" => $errors]);
            }
            return;
        }
        $keys = array_keys($post);
        $values = array_values($post);
        $data = array_combine($keys, $values);
        $result = $this->Client_Model->addUpdate($data);
        echo json_encode($result);
    }




    public function getAddress()
    {
        $type = $this->input->post('type');
        if ($type == 'state') {
            $states = $this->Client_Model->getStates();
            foreach ($states as $state) {
                echo "<option class='dynamic_state' value='{$state['state_id']}'>{$state['state_name']}</option>";
            }
        } elseif ($type == 'city') {
            $state_id = $this->input->post('state');
            // print_r($state_id);
            $cities = $this->Client_Model->getCities($state_id);
            foreach ($cities as $city) {
                echo "<option class='dynamic_city' value='{$city['district_id']}'>{$city['district_name']}</option>";
            }
        }
    }

    public function fetch()
    {

        $page_limit = $this->input->post('page_limit') !== null && $this->input->post('page_limit') !== "undefined" ? (int) $this->input->post('page_limit') : 5;
        // print_r($page_limit);

        $page_no = $this->input->post('page') !== null && $this->input->post('page') !== "undefined" ? (int) $this->input->post('page') : 1;
        $sort_column1 = $this->input->post('column') ?? 'status';
        $sort_column2 = $this->input->post('column') ?? 'id';
        $sort_order = $this->input->post('order') ?? 'DESC';
        $offset = ($page_no - 1) * $page_limit;
        // print_r($this->input->post());
        $name = !empty($this->input->post('searchname')) ? trim($this->input->post('searchname')) : "";
        $email = !empty($this->input->post('searchemail')) ? trim($this->input->post('searchemail'))  : "";
        $phone = !empty($this->input->post('searchphone')) ? trim($this->input->post('searchphone'))  : "";
        $address = !empty($this->input->post('searchaddress')) ? trim($this->input->post('searchaddress'))  : "";
        $queryData = $this->Client_Model->fetch($sort_column1, $sort_column2, $sort_order, $page_limit, $offset, $name, $email, $phone, $address);
        $result = $queryData['data'];
        $total_records = $queryData['count'];
        // print_r($result);
        $columns = ['id', 'name', 'email', 'phone', 'address', 'status'];
        $output = '<div class="table-wrap">
        <table class="table table-bordered" style="width: 100%; min-width: 900px; border-collapse: collapse;">
            <thead class="table-secondary">
                <tr>
                    <th scope="col" class="text-center" style="width: 50px;">Sr.No</th>';
        foreach ($columns as $column) {
            $new_sort_order = 'ASC';
            $sort_icons = '<i class="fa fa-sort-amount-desc" aria-hidden="true"></i>';
            $new_sort_order = ($sort_column2 == $column && $sort_order == 'ASC') ? 'DESC' : 'ASC';
            $sort_icons = ($sort_column2 == $column && $sort_order == 'ASC') ? '<i class="fa fa-sort-alpha-asc" aria-hidden="true"></i>' : '<i class="fa fa-sort-alpha-desc" aria-hidden="true"></i>';
            $output .= '<th scope="col" class="text-center" style="width: 150px;">
                            <a class="column_sort text-black" href="#" data-column="' . $column . '" data-order="' . $new_sort_order . '" style="align-items: center; gap: 5px;">
                                <span>' . ucfirst($column) . '</span>
                                ' . $sort_icons . '
                            </a>
                        </th>';
        }
        $output .= '<th scope="col" class="text-center" style="width: 150px;">Action</th></tr></thead><tbody>';
        if (!empty($result)) {
            $s_no = $offset + 1;
            foreach ($result as $row) {
                $statusClass = $row['status'] == 1 ? '#157347' : '#BB2D3B';
                $statusText = $row['status'] == 1 ? 'Active' : 'Inactive';
                $output .= '<tr>';
                $output .= '<td class="text-center">' . $s_no++ . '</td>';
                $output .= '<td >' . $row['id'] . '</td>';
                $output .= '<td >' . $row['name'] . '</td>';
                $output .= '<td >' . $row['email'] . '</td>';
                $output .= '<td >' . $row['phone'] . '</td>';
                $output .= '<td >' . $row['address'] . '</td>';
                $output .= '<td style="width: 150px;">
    <span class="text-white" 
          style="display: inline-block; width: 62px; height: 22px;  border-radius: 5px; background-color:' . $statusClass . '; text-align: center; line-height: 20px;">
        ' . $statusText . '
    </span>
</td>';

                $output .= '<td class="text-center" style="width: 120px;">
<button class="btn btn-secondary btn-sm edit" edit_id="' . $row['id'] . '" style="padding: 4px 6px; font-size: 12px;">
  <i class="fa fa-pencil" aria-hidden="true" style="width: 16px; height: 16px;"></i>
</button>
<button class="btn btn-danger btn-sm delete" delete_id="' . $row['id'] . '" style="padding: 4px 6px; font-size: 12px;">
   <i class="fa fa-trash" aria-hidden="true" style="width: 16px; height: 16px;"></i>
</button>
</td>';
                $output .= '</tr>';
            }
        } else {
            $output .= '<tr><td colspan="9" style="font-size: 16px; background-color: rgba(255, 0, 0, 0.1); class="text-center text-danger font-weight-bold">No Data Found</td></tr>';
        }
        $output .= '</tbody></table></div>';
        $pagination = $this->main->pagination($page_no, $total_records, $page_limit);
        echo json_encode(['data' => $output, 'pagination' => $pagination['pagination'], 'total_records' => $total_records, 'total_pages' => $pagination['total_page']]);
    }


    public function delete()
    {

        $id = $this->input->post('delete_id');
        $result = $this->Client_Model->delete($id);
        echo $result;
    }


    public function edit()
    {


        $id = $this->input->post('edit_id');

        $result = $this->Client_Model->edit($id);
        echo json_encode($result);
    }
}
