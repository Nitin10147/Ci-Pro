<?php
class User extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('User_Model');
    }
    public function index()
    {
        $this->load->view('user/index');
    }
    public function addUpdate()
    {
        try {
            $post = $this->input->post();
            $table_name = $post['table'] ?? 'user_master';

            // Load and validate form data
            $this->load->library('FormValidator');
            $validation_result = $this->formvalidator->validateForm($post, $table_name);

            // Handle validation errors
            if (!$validation_result['status']) {
                $errors = $validation_result['errors'];
                $response = isset($errors['email']) || isset($errors['phone']) || isset($errors['item_name'])
                    ? ["duplication_error" => true, "errors" => $errors]
                    : ["error" => false, "errors" => $errors];
                echo json_encode($response);
                return;
            }

            // Encrypt password if it exists
            if (isset($post['password'])) {
                $post['password'] = md5($post['password']); // MD5 encryption
            }

            // Handle file upload
            if (!empty($_FILES['image']['name'])) {
                $upload_result = $this->handleFileUpload();
                if ($upload_result['error']) {
                    echo json_encode($upload_result);
                    return;
                }
                $post['image'] = $upload_result['file_name'];
            }
            $result = $this->User_Model->addUpdate($post);
            echo json_encode($result);
        } catch (Exception $e) {
            log_message('error', 'Error in addUpdate: ' . $e->getMessage());
            echo json_encode(["error" => true, "message" => "An unexpected error occurred while processing your request. Please try again later."]);
        }
    }


    private function handleFileUpload()
    {
        try {
            $config['upload_path'] = './uploads/user/';
            $config['allowed_types'] = 'jpg|png|gif|jpeg';
            $config['max_size'] = 2048;
            $config['encrypt_name'] = true; 

            if (!is_dir($config['upload_path'])) {
                mkdir($config['upload_path'], 0777, true);
            }

            $this->load->library('upload', $config);

            if (!$this->upload->do_upload('image')) {
                return ['error' => true, 'message' => $this->upload->display_errors()];
            }
            $upload_data = $this->upload->data();
            return ['error' => false, 'file_name' => $upload_data['file_name']];
        } catch (Exception $e) {
            log_message('error', 'Error in handleFileUpload: ' . $e->getMessage());
            return ['error' => true, 'message' => 'An unexpected error occurred while uploading the file. Please try again later.'];
        }
    }
    public function fetch()
    {
        try {
            $page_limit = $this->input->post('page_limit') !== null && $this->input->post('page_limit') !== "undefined" ? (int) $this->input->post('page_limit') : 5;
            // print_r($page_limit);
            $page_no = $this->input->post('page') !== null && $this->input->post('page') !== "undefined" ? (int) $this->input->post('page') : 1;
            $sort_column1 = $this->input->post('column') ?? 'status';
            $sort_column2 = $this->input->post('column') ?? 'id';
            $sort_order = $this->input->post('order') ?? 'DESC';
            $offset = ($page_no - 1) * $page_limit;
            // print_r($this->input->post());
            $name = !empty($this->input->post('searchname')) ? trim($this->input->post('searchname')) : "";
            $email = !empty($this->input->post('searchemail')) ? trim($this->input->post('searchemail'))  : "";
            $phone = !empty($this->input->post('searchphone')) ? trim($this->input->post('searchphone'))  : "";
            $queryData = $this->User_Model->fetch($sort_column1, $sort_column2, $sort_order, $page_limit, $offset, $name, $email, $phone);
            $result = $queryData['data'];
            $total_records = $queryData['count'];
            // print_r($result);
            $columns = ['id', 'name', 'email', 'phone', 'status'];
            $output = '<div class="table-wrap">
        <table class="table table-bordered" style="width: 100%; min-width: 900px; border-collapse: collapse;">
            <thead class="table-secondary">
                <tr>
                    <th scope="col" class="text-center"">Sr.No</th>';

            foreach ($columns as $column) {
                $new_sort_order = 'ASC';
                $sort_icons = '<i class="fa fa-sort-amount-desc" aria-hidden="true"></i>';
                $new_sort_order = ($sort_column2 == $column && $sort_order == 'ASC') ? 'DESC' : 'ASC';
                $sort_icons = ($sort_column2 == $column && $sort_order == 'ASC') ? '<i class="fa fa-sort-alpha-asc" aria-hidden="true"></i>' : '<i class="fa fa-sort-alpha-desc" aria-hidden="true"></i>';

                // Set a fixed width for each column
                $output .= '<th scope="col" class="text-center"">
                <a class="column_sort text-black" href="#" data-column="' . $column . '" data-order="' . $new_sort_order . '" style="align-items: center; gap: 5px;">
                    <span>' . ucfirst($column) . '</span>
                    ' . $sort_icons . '
                </a>
            </th>';
            }

            $output .= '<th scope="col" class="text-center" ">Action</th></tr></thead><tbody>';

            if (!empty($result)) {
                $s_no = $offset + 1;
                foreach ($result as $row) {
                    $statusClass = $row['status'] == 1 ? '#157347' : '#BB2D3B';
                    $statusText = $row['status'] == 1 ? 'Active' : 'Inactive';
                    $image = $row['image'] ? $row['image'] : 'profile.png';
                    $output .= '<tr>';
                    $output .= '<td class="text-center">' . $s_no++ . '</td>';
                    $output .= '<td >' . $row['id'] . '</td>';
                    $output .= '<td >' . $row['name'] . '</td>';
                    $output .= '<td >' . $row['email'] . '</td>';
                    $output .= '<td >' . $row['phone'] . '</td>';
                    $output .= '<td >
    <span class="text-white" 
          style="display: inline-block; width: 62px; height: 22px;  border-radius: 5px; background-color:' . $statusClass . '; text-align: center; line-height: 20px;">
        ' . $statusText . '
    </span>
</td>';

                    $output .= '<td class="text-center">
<button class="btn btn-secondary btn-sm edit" edit_id="' . $row['id'] . '" style="padding: 4px 6px; font-size: 12px;">
  <i class="fa fa-pencil" aria-hidden="true" style="width: 16px; height: 16px;"></i>
</button>
<button class="btn btn-danger btn-sm delete" delete_id="' . $row['id'] . '" style="padding: 4px 6px; font-size: 12px;">
   <i class="fa fa-trash" aria-hidden="true" style="width: 16px; height: 16px;"></i>
</button>
</td>';

                    $output .= '</tr>';
                }
            } else {
                $output .= '<tr><td colspan="9" class="text-center text-danger bg-secondary font-weight-bold" style="font-size: 16px; background-color: rgba(255, 0, 0, 0.1);>No Data Found</td></tr>';
            }

            $output .= '</tbody></table></div>';

            $pagination = $this->main->pagination($page_no, $total_records, $page_limit);
            echo json_encode(['data' => $output, 'pagination' => $pagination['pagination'], 'total_records' => $total_records, 'total_pages' => $pagination['total_page']]);
        } catch (Exception $e) {
            log_message('error', 'Error in handleFileUpload: ' . $e->getMessage());
            echo json_encode(['error' => true, 'message' => 'An unexpected error occurred while fetching user data. Please try again later.']);
        }
    }
    public function delete()
    {
        try {
            $id = $this->input->post('delete_id');
            $result = $this->User_Model->delete($id);
            echo $result;
        } catch (Exception $e) {
            log_message('error', 'Error in handleFileUpload: ' . $e->getMessage());
            echo json_encode(['error' => true, 'message' => 'An unexpected error occurred while deleting user data. Please try again later.']);
        }
    }
    public function edit()
    {
        try {
            $id = $this->input->post('edit_id');
            $result = $this->User_Model->edit($id);
            echo json_encode($result);
        } catch (Exception $e) {
            log_message('error', 'Error in handleFileUpload: ' . $e->getMessage());
            echo json_encode(['error' => true, 'message' => 'An unexpected error occurred while editing user data. Please try again later.']);
        }
    }
}
