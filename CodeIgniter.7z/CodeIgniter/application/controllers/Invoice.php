<?php
// Ensure that the Composer autoloader is included correctly

defined('BASEPATH') or exit('No direct script access allowed');

require_once 'C:\xampp\htdocs\CodeIgniter/vendor/autoload.php';

use Mpdf\Mpdf;
class Invoice extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->model('Invoice_Model');
    }
    public function index()
    {
        $this->load->view('invoice/index');
    }

    public function addUpdate()
    {
        $post = $this->input->post();
        $this->load->library('FormValidator');
        $validation_result = $this->formvalidator->validateInvoiceForm($post, 'invoice_master');
        if (!$validation_result['status']) {
            $errors = $validation_result['errors'];
            $response =  isset($errors['invoice_no']) 
                ? ["duplication_error" => true, "errors" => $errors] 
                : ["error" => false, "errors" => $errors];
            echo json_encode($response);
            return;
        }
        $keys = array_keys($post);
        $values = array_values($post);
        $data = array_combine($keys, $values);
        $result = $this->Invoice_Model->addUpdate($data);
        echo json_encode($result);
    }

    public function client_autocomplete()
    {
        $name = $this->input->post('client_name');
        $result = $this->Invoice_Model->client_autocomplete($name);
        echo json_encode(['data' => $result]);
    }

    public function item_autocomplete()
    {
        
        $name = $this->input->post('item_name');
        $result = $this->Invoice_Model->item_autocomplete($name);
        echo json_encode(['data' => $result]);
    }


    public function generateInvoiceNo()
    {
        $result = $this->Invoice_Model->generateInvoiceNo();
        echo json_encode(['data' => $result]);
    }

    public function fetch()
    {
        
        $page_limit = $this->input->post('page_limit') !== null && $this->input->post('page_limit') !== "undefined" ? (int) $this->input->post('page_limit') : 5;
        // print_r($page_limit);
        $page_no = $this->input->post('page') !== null && $this->input->post('page') !== "undefined" ? (int) $this->input->post('page') : 1;
        $sort_column1 = $this->input->post('column') ?? 'status';
        $sort_column2 = $this->input->post('column') ?? 'id';
        $sort_order = $this->input->post('order') ?? 'DESC';
        $offset = ($page_no - 1) * $page_limit;
        // print_r($this->input->post());
        // search by invoice_no and invoice_date is in range and client_name client_email, client_phone 
        $invoice_no = !empty($this->input->post('search_invoice_no')) ? trim($this->input->post('search_invoice_no')) : "";

        $name = !empty($this->input->post('search_name')) ? trim($this->input->post('search_name')) : "";
        $email = !empty($this->input->post('search_email')) ? trim($this->input->post('search_email'))  : "";
        $phone = !empty($this->input->post('search_phone')) ? trim($this->input->post('search_phone'))  : "";

        $start_date = !empty($this->input->post('date_from')) ? trim($this->input->post('date_from'))  : "";
        $end_date = !empty($this->input->post('date_to')) ? trim($this->input->post('date_to'))  : "";


        $queryData = $this->Invoice_Model->fetch($sort_column1, $sort_column2, $sort_order, $page_limit, $offset, $invoice_no, $name, $email, $phone, $start_date, $end_date);

        $result = $queryData['data'];
        $total_records = $queryData['count'];
        // print_r($result);
        $columns = ['id', 'invoice_no', 'invoice_date', 'total_amount', 'client_name', 'address', 'email', 'phone'];
        $output = '<div class="table-wrap">
        <table class="table table-bordered " style="width: 100%; min-width: 1300px; border-collapse: collapse;" >
            <thead class="table-secondary">
                <tr>
                    <th scope="col" class="text-center" style="width: 50px;">Sr.No</th>';
        foreach ($columns as $column) {
            $new_sort_order = 'ASC';
            $sort_icons = '<i class="fa fa-sort-amount-desc" aria-hidden="true"></i>';

            $new_sort_order = ($sort_column2 == $column && $sort_order == 'ASC') ? 'DESC' : 'ASC';
            $sort_icons = ($sort_column2 == $column && $sort_order == 'ASC') ? '<i class="fa fa-sort-alpha-asc" aria-hidden="true"></i>' : '<i class="fa fa-sort-alpha-desc" aria-hidden="true"></i>';
            if ($column == 'id') {
                $output .= '<th scope="col" class="text-center" style="width: 100px;">
                            <a class="column_sort text-black" href="#" data-column="' . $column . '" data-order="' . $new_sort_order . '" style="align-items: center; gap: 5px;">
                                <span>ID</span>
                                ' . $sort_icons . '
                            </a>
                        </th>';
                continue;
            } else if ($column == 'invoice_date') {
                $output .= '<th scope="col" class="text-center" style="width: 150px;">
                            <a class="column_sort text-black" href="#" data-column="' . $column . '" data-order="' . $new_sort_order . '" style="align-items: center; gap: 5px;">
                                <span>Invoice Date</span>
                                ' . $sort_icons . '
                            </a>
                        </th>';
                continue;
            } else if ($column == 'total_amount') {
                $output .= '<th scope="col" class="text-center" style="width: 150px;">
                            <a class="column_sort text-black" href="#" data-column="' . $column . '" data-order="' . $new_sort_order . '" style="align-items: center; gap: 5px;">
                                <span>Total Amount</span>
                                ' . $sort_icons . '
                            </a>
                        </th>';
                continue;
            } else if ($column == 'client_name') {
                $output .= '<th scope="col" class="text-center" style="width: 150px;">
                            <a class="column_sort text-black" href="#" data-column="' . $column . '" data-order="' . $new_sort_order . '" style="align-items: center; gap: 5px;">
                                <span>Client Name</span>
                                ' . $sort_icons . '
                            </a>
                        </th>';
                continue;
            } else if ($column == 'invoice_no') {
                $output .= '<th scope="col" class="text-center" style="width: 150px;">
                            <a class="column_sort text-black" href="#" data-column="' . $column . '" data-order="' . $new_sort_order . '" style="align-items: center; gap: 5px;">
                                <span>Invoice No</span>
                                ' . $sort_icons . '
                            </a>
                        </th>';
                continue;
            }

            $output .= '<th scope="col" class="text-center" style="width: 150px;">
                            <a class="column_sort text-black" href="#" data-column="' . $column . '" data-order="' . $new_sort_order . '" style="align-items: center; gap: 5px;">
                                <span>' . ucfirst($column) . '</span>
                                ' . $sort_icons . '
                            </a>
                        </th>';
        }
        $output .= '<th scope="col" class="text-center" style="width: 250px;">Action</th></tr></thead><tbody>';

        if (!empty($result)) {
            $s_no = $offset + 1;
            foreach ($result as $row) {
                $output .= '<tr>';
                $output .= '<td class="text-center">' . $s_no++ . '</td>';
                $output .= '<td style="width: 100px;" >' . $row['id'] . '</td>';
                $output .= '<td style="width: 100px;" >' . $row['invoice_no'] . '</td>';
                $output .= '<td style="width: 150px;" >' . date_format(date_create($row['invoice_date']), 'd-m-Y') . '</td>';
                $output .= '<td style="width: 150px;" >' . $row['total_amount'] . '</td>';
                $output .= '<td style="width: 150px;" >' . $row['client_name'] . '</td>';
                $output .= '<td style="width: 250px;" >' . $row['address'] . '</td>';
                $output .= '<td style="width: 150px;" >' . $row['email'] . '</td>';
                $output .= '<td style="width: 150px;" >' . $row['phone'] . '</td>';
                $output .= '<td class="text-center" style="width: 250px;">
            <button class="btn btn-info btn-sm pdf-generate" invoice_id="' . $row['id'] . '" style="padding: 4px 6px; font-size: 12px;">
              <i class="fa fa-file" aria-hidden="true" style="width: 16px; height: 16px;"></i>
            </button>
            <button class="btn btn-primary btn-sm email_send" email_id="' . $row['id'] . '" client_email="' . $row['email'] . '" style="padding: 4px 6px; font-size: 12px;">
              <i class="fa fa-envelope" aria-hidden="true" style="width: 16px; height: 16px;"></i>
            </button>
                            
            <button class="btn btn-secondary btn-sm edit" edit_id="' . $row['id'] . '" style="padding: 4px 6px; font-size: 12px;">
              <i class="fa fa-pencil" aria-hidden="true" style="width: 16px; height: 16px;"></i>
            </button>
            <button class="btn btn-danger btn-sm delete" delete_id="' . $row['id'] . '" style="padding: 4px 6px; font-size: 12px;">
               <i class="fa fa-trash" aria-hidden="true" style="width: 16px; height: 16px;"></i>
            </button>
            </td>';
                $output .= '</tr>';
            }
        } else {
            $output .= '<tr><td colspan="10" class="text-center text-danger  font-weight-bold" style="font-size: 16px; background-color: rgba(255, 0, 0, 0.1);">No Data Found</td></tr>';
        }
        $output .= '</tbody></table></div>';
        $pagination = $this->main->pagination($page_no, $total_records, $page_limit);
        echo json_encode(['data' => $output, 'pagination' => $pagination['pagination'], 'total_records' => $total_records, 'total_pages' => $pagination['total_page']]);
    }

    public function delete()
    {
        $id = $this->input->post('delete_id');
        $result = $this->Invoice_Model->delete($id);
        echo $result;
    }

    public function edit()
    {
        $edit_id = $this->input->post('edit_id');
        $result = $this->Invoice_Model->getDataForInvoice($edit_id);
        
        // Initialize 'items' as an empty array
        $result['items'] = [];
        $item_names = explode(', ', $result['item_names']);
        $quantities = explode(', ', $result['quantities']);
        $item_prices = explode(', ', $result['item_prices']);
        $item_ids = explode(', ', $result['item_ids']);
        for ($i = 0; $i < count($item_names); $i++) {
            $result['items'][] = [
                'item_id' => $item_ids[$i],
                'itemname' => $item_names[$i],
                'quantity' => $quantities[$i],
                'price' => $item_prices[$i],
                'total_price' => $quantities[$i] * $item_prices[$i]
            ];
        }
        unset($result['item_names']);
        unset($result['quantities']);
        unset($result['item_prices']);
        unset($result['item_ids']);
        echo json_encode(['data' => $result, 'table' => 'invoice_master']);
    }

  public function pdf_generate() {
    $this->load->library('pdfgenerator');
    $invoice_id = $this->input->post('invoice_id');

    // Fetch data for invoice
    $data = $this->Invoice_Model->getDataForInvoice($invoice_id);

    $numberToword = $this->pdfgenerator->numberToWords($data['total_amount']);
    $data['numberToword'] = $numberToword;

    // Load the invoice PDF view as a string
    $html = $this->load->view('invoice/invoice_pdf', ['data' => $data], TRUE);
    $mpdf = new \Mpdf\Mpdf();
    $mpdf->WriteHTML($html);

    // Define invoice directory
    $invoice_folder = FCPATH . 'invoice_pdf/';

    // Create folder if not exists
    if (!is_dir($invoice_folder)) {
        mkdir($invoice_folder, 0777, true);
    }

    $file_name = $invoice_id . '.pdf';
    $file_path = $invoice_folder . $file_name;

    // Save PDF
    $mpdf->Output($file_path, 'F'); 
    echo base_url('invoice_pdf/' . $file_name);
}




   public function send_invoice_email() {
    $this->load->library('email');
    $invoice_id = $this->input->post('invoice_id');
    $client_email = $this->input->post('client_email');
    $message = $this->input->post('message');
    $file_path = FCPATH . 'invoice_pdf/' . $invoice_id . '.pdf';
   
    
    if (!file_exists($file_path)) {
        echo json_encode(["status" => "error", "message" => "Invoice PDF not found."]);
        return;
    }

    // Email Configuration
    $config = [
        'protocol'    => 'smtp',
        'smtp_host'   => 'smtp.gmail.com',
        'smtp_user'   => 'vishalvishwakarma8009@gmail.com',
        'smtp_pass'   => 'kpvurrdmaxniutgq', // Use App Password
        'smtp_port'   => 587,
        'smtp_crypto' => 'tls', // Enable STARTTLS
        'mailtype'    => 'html',
        'charset'     => 'utf-8',
        'newline'     => "\r\n",
        'wordwrap'    => TRUE,
    ];

    $this->email->initialize($config);
    $this->email->from('vishalvishwakarma8009@gmail.com', 'Your Company');

    // Add recipients
    $this->email->to($client_email);

    $this->email->subject('Invoice #' . $invoice_id);

    // Email message
    $emailMessage = "<p>Hello,</p><p>" . nl2br($message) . "</p><p>Please find your invoice attached.</p>";
    $this->email->message($emailMessage);
    $this->email->attach($file_path);

    // Send Email
    if ($this->email->send()) {
        echo json_encode(["status" => "success", "message" => "Email sent successfully!"]);
    } else {
        echo json_encode(["status" => "error", "message" => $this->email->print_debugger()]);
    }
}
  
}
