<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Login extends CI_Controller {
    public function __construct()
    {
        parent::__construct();
        $this->load->model('Login_Model');
    }
    public function index()
    {
        $this->load->view('login/index');
        
    }
    public function loginSuccess() {
        $rules = [
            ['field' => 'email', 'rules' => 'required|trim|valid_email'],
            ['field' => 'password', 'rules' => 'required|trim']
        ];
        try {
            $this->form_validation->set_rules($rules);
            if ($this->form_validation->run()) {
                $post = $this->input->post();
                
                $result = $this->Login_Model->checkLoginDetail($post);
                if (!empty($result) && isset($result['status'])) {

                    if ($result['status'] == 0) {
                        $this->response_msg->apiResponse(false, 'Your Status is Inactive. Please Contact Admin.', null, 403);
                    } elseif ($result['status'] == 1) {
                        $sessionData['USER'] = [
                            'user_id' => $result['id'],
                            'email'   => $result['email'],
                            'name'    => $result['name'],
                            'image'   => $result['image']
                        ];
                        // add remember me option
                        if (isset($post['remember']) && $post['remember'] == 'on') {
                            $cookie1 = [
                                'name'   => 'email',
                                'value'  => $result['email'],
                                'expire' => time() + (60 * 60 * 24 * 30), 
                                'secure' => true
                            ];
                            $cookie2 = [
                                'name'   => 'password',
                                'value'  => $post['password'],
                                'expire' => time() + (60 * 60 * 24 * 30), 
                                'secure' => true
                            ];
                            set_cookie($cookie1);
                            set_cookie($cookie2);
                        }else{
                            delete_cookie('email');
                            delete_cookie('password');
                        }
                        $this->session->set_userdata($sessionData);
                        $this->response_msg->apiResponse(true, 'Login successfully', null, 200);
                    }
                } else {
                    $this->response_msg->apiResponse(false, 'Invalid email or password', null, 401);
                }
            } else {
                $this->response_msg->apiResponse(false, validation_errors(), null, 422);
            }
        } catch (Exception $e) {
            $this->response_msg->apiResponse(false, $e->getMessage(), null, 500);
        }
    }

public function logout() {
    try {
        
        if ($this->session->userdata('USER')) {
            $this->session->unset_userdata('USER'); 
            $this->session->sess_destroy(); 
        }
        $this->session->set_flashdata('success', 'Logged out successfully.');
        redirect('login');
        exit;
    } catch (Exception $e) {
        log_message('error', 'Logout Error: ' . $e->getMessage()); // Log the error
        $this->response_msg->apiResponse(false, 'Something went wrong. Please try again.', null, 500);
    }
}



// forgot password function
public function forgot_password() {
        $this->load->view('login/forgot_password'); 
    }



 public function send_reset_link() {
        $this->form_validation->set_rules('email', 'Email', 'required|valid_email');

        if ($this->form_validation->run() == FALSE) {
            $this->load->view('login/forgot_password'); 
        } else {
            $email = $this->input->post('email');
            $user = $this->Login_Model->get_user_by_email($email);

            if ($user) {
                $token = bin2hex(random_bytes(50)); // Generate token
                $expiry = date('Y-m-d H:i:s', strtotime('+1 hour')); // Expire in 1 hour
                
                // Save token & expiry in DB
                $this->Login_Model->store_reset_token($email, $token, $expiry);
                
                // Send Email with Reset Link
                $reset_link = base_url("login/reset_password/$token");
                $message = "Click the following link to reset your password: <a href='$reset_link'>$reset_link</a>";
                $this->send_email($email, "Password Reset Request", $message);

                $this->session->set_flashdata('message', 'Reset link sent! Check your email.');
                redirect('login/forgot_password');
            } else {
                $this->session->set_flashdata('error', 'Email not found!');
                redirect('login/forgot_password');
            }
        }
    }


     public function reset_password($token) {
        $user = $this->Login_Model->get_user_by_token($token);

        if (!$user || strtotime($user->reset_expiry) < time()) {
            $this->session->set_flashdata('error', 'Invalid or expired token.');
            redirect('login/forgot_password');
        } else {
            $data['token'] = $token;
            $this->load->view('login/reset_password', $data);
        }
    }



     public function update_password() {
        $this->form_validation->set_rules('password', 'Password', 'required|min_length[6]');
        $this->form_validation->set_rules('confirm_password', 'Confirm Password', 'required|matches[password]');

        if ($this->form_validation->run() == FALSE) {
            $this->load->view('login/reset_password'); 
        } else {
            $token = $this->input->post('token');
            $user = $this->Login_Model->get_user_by_token($token);

            if ($user && strtotime($user->reset_expiry) >= time()) {
                $new_password = md5($this->input->post('password'));
                $this->Login_Model->update_password($user->email, $new_password); 
                // Clear reset token
                $this->Login_Model->clear_reset_token($user->email);
                $this->session->set_flashdata('message', 'Password updated! You can now log in.');
                redirect('login');
            } else {
                $this->session->set_flashdata('error', 'Invalid or expired token.');
                redirect('login/forgot_password');
            }
        }
    }



     private function send_email($to, $subject, $message) {
       $this->load->library('email');

    // Email Configuration
    $config = [
        'protocol'    => 'smtp',
        'smtp_host'   => 'smtp.gmail.com',
        'smtp_user'   => 'vishalvishwakarma8009@gmail.com',
        'smtp_pass'   => 'kpvurrdmaxniutgq', // Use App Password
        'smtp_port'   => 587,
        'smtp_crypto' => 'tls', // Enable STARTTLS
        'mailtype'    => 'html',
        'charset'     => 'utf-8',
        'newline'     => "\r\n",
        'wordwrap'    => TRUE,
    ];

    $this->email->initialize($config);
    $this->email->from('vishalvishwakarma8009@gmail.com', 'San Softwares');
    // Add recipients
    $this->email->to($to);
    $this->email->subject($subject);
    // Email message
    $this->email->message($message);
    // Send Email
    if ($this->email->send()) {
        return true;
    } else {
        return false;
    }
}
}
