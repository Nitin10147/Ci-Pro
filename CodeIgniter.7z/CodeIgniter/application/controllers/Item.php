<?php 

class Item extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('Item_Model');
    }

    public function index() {
        $this->load->view('item/index');
    }

    public function addUpdate()
    {
        // Check if the request method is POST
      

        $post = $this->input->post();
        $table_name = $post['table'];
    
        $this->load->library('FormValidator');
        $validation_result = $this->formvalidator->validateForm($post, $table_name);
    
        if (!$validation_result['status']) {
            $errors = $validation_result['errors'];
            $response = isset($errors['email']) || isset($errors['phone']) || isset($errors['item_name']) 
                ? ["duplication_error" => true, "errors" => $errors] 
                : ["error" => false, "errors" => $errors];
            echo json_encode($response);
            return;
        }
    
        // Handle file upload
        $data = $post;
        if (!empty($_FILES['image']['name'])) {
            $upload_result = $this->handleFileUpload();
            if ($upload_result['error']) {
                echo json_encode($upload_result);
                return;
            }
            $data['image'] = $upload_result['file_name'];
        }
        $result = $this->Item_Model->addUpdate($data);
        echo json_encode($result);
    }
    
    private function handleFileUpload()
    {
        $config['upload_path'] = './uploads/item/';
        $config['allowed_types'] = 'jpg|png|gif|jpeg';
        $config['max_size'] = 2048; 
        $config['encrypt_name'] = true; 
    
        if (!is_dir($config['upload_path'])) {
            mkdir($config['upload_path'], 0777, true);
        }
    
        $this->load->library('upload', $config);
    
        if (!$this->upload->do_upload('image')) {
            return ['error' => true, 'message' => $this->upload->display_errors()];
        }
    
        $upload_data = $this->upload->data();
        return ['error' => false, 'file_name' => $upload_data['file_name']];
    }

    public function fetch()
    {
        
        $page_limit = $this->input->post('page_limit') !== null && $this->input->post('page_limit') !== "undefined" ? (int) $this->input->post('page_limit') : 5;
        // print_r($page_limit);
        $page_no = $this->input->post('page') !== null && $this->input->post('page') !== "undefined" ? (int) $this->input->post('page') : 1;
        $sort_column1 = $this->input->post('column') ?? 'status';
        $sort_column2 = $this->input->post('column') ?? 'id';
        $sort_order = $this->input->post('order') ?? 'DESC';
        $offset = ($page_no - 1) * $page_limit;
        // print_r($this->input->post());
        $name = !empty($this->input->post('searchname')) ? trim($this->input->post('searchname')) : "";
        $queryData = $this->Item_Model->fetch($sort_column1, $sort_column2, $sort_order, $page_limit, $offset,$name);
        $result = $queryData['data'];
        $total_records = $queryData['count'];
        // print_r($result);
        $columns = ['id', 'item_name', 'description','price','image', 'status'];
        $output = '<div class="table-wrap">
        <table class="table table-bordered" style="width: 100%; min-width: 900px; border-collapse: collapse;">
            <thead class="table-secondary">
                <tr>
                    <th scope="col" class="text-center" style="width: 50px;">Sr.No</th>';
                    foreach ($columns as $column) {
                        $new_sort_order = 'ASC';
                        $sort_icons = '<i class="fa fa-sort-amount-desc" aria-hidden="true"></i>';
                        
                        $new_sort_order = ($sort_column2 == $column && $sort_order == 'ASC') ? 'DESC' : 'ASC';
                        $sort_icons = ($sort_column2 == $column && $sort_order == 'ASC') ? '<i class="fa fa-sort-alpha-asc" aria-hidden="true"></i>' : '<i class="fa fa-sort-alpha-desc" aria-hidden="true"></i>';
                        if($column == 'image') {
                            $output .= '<th scope="col" class="text-center" style="width: 150px;">Image</th>';
                            continue;
                        }else if($column == 'item_name') {
                            $output .= '<th scope="col" class="text-center" style="width: 150px;">
                            <a class="column_sort text-black" href="#" data-column="' . $column . '" data-order="' . $new_sort_order . '" style="align-items: center; gap: 5px;">
                                <span>Item Name</span>
                                ' . $sort_icons . '
                            </a>
                        </th>';
                        continue;
                        }
                        $output .= '<th scope="col" class="text-center" style="width: 150px;">
                            <a class="column_sort text-black" href="#" data-column="' . $column . '" data-order="' . $new_sort_order . '" style="align-items: center; gap: 5px;">
                                <span>' . ucfirst($column) . '</span>
                                ' . $sort_icons . '
                            </a>
                        </th>';
                    }
        $output .= '<th scope="col" class="text-center" style="width: 150px;">Action</th></tr></thead><tbody>';
       
        if (!empty($result)) {
            $s_no = $offset + 1;
            foreach ($result as $row) {
                $statusClass = $row['status'] == 1 ? '#157347' : '#BB2D3B';
                $statusText = $row['status'] == 1 ? 'Active' : 'Inactive';
                $image = $row['image'] ? $row['image'] : 'productDummy.png';
                $output .= '<tr>';
                $output .= '<td class="text-center">' . $s_no++ . '</td>';
                $output .= '<td style="width: 150px;" >' . $row['id'] . '</td>';
                $output .= '<td style="width: 150px;" >' . $row['item_name'] . '</td>';
                $output .= '<td style="width: 150px;" >' . $row['description'] . '</td>';
                $output .= '<td style="width: 150px;" >' . $row['price'] . '</td>';
                $output .= '<td style="width: 150px;" class="text-center "><img class="item_image" src="' . base_url() . 'uploads/item/' . $image . '" style="width:50px; height:30px; cursor: pointer;" alt="Image" ></td>';
                $output .= '<td style="width: 150px;">
                <span class="text-white" 
                      style="display: inline-block; width: 62px; height: 22px;  border-radius: 5px; background-color:' . $statusClass . '; text-align: center; line-height: 20px;">
                    ' . $statusText . '
                </span>
            </td>';
            
                            $output .= '<td class="text-center" style="width: 120px;">
            <button class="btn btn-secondary btn-sm edit" edit_id="' . $row['id'] . '" style="padding: 4px 6px; font-size: 12px;">
              <i class="fa fa-pencil" aria-hidden="true" style="width: 16px; height: 16px;"></i>
            </button>
            <button class="btn btn-danger btn-sm delete" delete_id="' . $row['id'] . '" style="padding: 4px 6px; font-size: 12px;">
               <i class="fa fa-trash" aria-hidden="true" style="width: 16px; height: 16px;"></i>
            </button>
            </td>';
            
                            $output .= '</tr>';
                        }
                    } else {
                        $output .= '<tr><td colspan="9" style="font-size: 16px; background-color: rgba(255, 0, 0, 0.1); class="text-center text-danger bg-secondary font-weight-bold">No Data Found</td></tr>';
                    }
        $output .= '</tbody></table></div>';
        $pagination = $this->main->pagination($page_no, $total_records , $page_limit);
        echo json_encode(['data' => $output, 'pagination' => $pagination['pagination'],'total_records' => $total_records ,'total_pages' => $pagination['total_page']]);
    }
    
    public function edit()
    { 
       try{
        $id = $this->input->post('edit_id');
        $result = $this->Item_Model->edit($id);
        echo json_encode($result);
       }catch(Exception $e){
        log_message('error', 'Error in handle Edit: ' . $e->getMessage());
        echo json_encode(['error' => true, 'message' => 'An unexpected error occurred while editing user data. Please try again later.']);
       }
    }
    public function delete()
    {
        try{
        $id = $this->input->post('delete_id');
        $result = $this->Item_Model->delete($id);
        echo $result;
        }catch(Exception $e){
            log_message('error', 'Error in handle Delete: ' . $e->getMessage());
            echo json_encode(['error' => true, 'message' => 'An unexpected error occurred while deleting user data. Please try again later.']);
        }
    }

    
}



?>