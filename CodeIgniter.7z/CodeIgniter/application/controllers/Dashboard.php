<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends CI_Controller {
    public function __construct()
    {
        parent::__construct();
        $this->load->model('Dashboard_Model');
 
    }

    public function index()
    {
        $data['dashboard_data'] = $this->Dashboard_Model->get_data();
        $this->load->view('dashboard/index', $data);
    }

    

   

}


?>