<?php 
$currentPage = $this->uri->segment(1);
$dashboardActive = '';
$clientActive = '';
$userActive = '';
$itemActive = '';
$invoiceActive = '';
if($currentPage == 'dashboard'){
    $dashboardActive = 'active';
}
else if($currentPage == 'user'){
    $userActive = 'active';
}else if($currentPage == 'client'){
    $clientActive = 'active';
}else if($currentPage == 'item'){
    $itemActive = 'active';
}else if($currentPage == 'invoice'){
    $invoiceActive = 'active';
}



?>



<div class="col-md-3 left_col">
        <div class="left_col scroll-view">
          <div class="navbar nav_title" style="border: 0;">
            <a href="index.html" class="site_title"><i class="fa fa-paw"></i> <span>Your Logo</span></a>
          </div>
          <div class="clearfix"></div>
          <br />
          <!-- sidebar menu -->
          <div id="sidebar-menu" class="main_menu_side hidden-print main_menu">
            <div class="menu_section">
              <ul class="nav side-menu">
                <li class="<?php echo $dashboardActive; ?>"><a href="<?php echo base_url(); ?>dashboard"><i class="fa fa-tachometer"></i> Dashboard </a>
                </li>
                <li class="<?php echo $userActive; ?>"><a href="<?php echo base_url(); ?>user"><i class="fa fa-users"></i> User Master </a>
                </li>
                <li class="<?php echo $clientActive; ?>"><a href="<?php echo base_url(); ?>client"><i class="fa fa-desktop"></i> Client Master </a>
                </li>
                <li class="<?php echo $itemActive; ?>"><a href="<?php echo base_url(); ?>item"><i class="fa fa-inbox"></i> Item Master </a>
                </li>
                <li class="<?php echo $invoiceActive; ?>"><a href="<?php echo base_url(); ?>invoice"><i class="fa fa-file-o"></i> Invoice Master</a>
                </li>
              </ul>
            </div>
          </div>
          <!-- /sidebar menu -->
          <!-- /menu footer buttons -->
          <div class="sidebar-footer hidden-small d-flex justify-content-center">

            <a width="100%" data-toggle="tooltip" data-placement="top" title="Logout" href="<?php echo base_url(); ?>login/logout" method="post">
              <span class="glyphicon glyphicon-off" aria-hidden="true"></span>
            </a>
          </div>
          <!-- /menu footer buttons -->
        </div>
      </div>
      <!-- top navigation -->
      <div class="top_nav">
        <div class="nav_menu">
          <div class="nav toggle">
            <a id="menu_toggle"><i class="fa fa-bars"></i></a>
          </div>
          <nav class="nav navbar-nav">
            <ul class=" navbar-right">
              <li class="nav-item dropdown open" style="padding-left: 15px;">
                <a href="javascript:;" class="user-profile dropdown-toggle" aria-haspopup="true" id="navbarDropdown" data-toggle="dropdown" aria-expanded="false">
                  <img src="<?php echo base_url();?>uploads/user/<?php echo $this->session->userdata('USER')['image'] ?>" alt=""><?php echo $this->session->userdata('USER')['name'] ?>
                </a>
                <div class="dropdown-menu dropdown-usermenu pull-right" aria-labelledby="navbarDropdown">
                  <a method="post" class="dropdown-item" href="<?php echo base_url(); ?>login/logout"><i class="fa fa-sign-out pull-right"></i> Log Out</a>
                </div>
              </li>
            </ul>
          </nav>
        </div>
      </div>