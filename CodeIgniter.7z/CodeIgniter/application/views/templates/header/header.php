
<link href="<?php echo base_url('assets/vendors/bootstrap/dist/css/bootstrap.min.css'); ?>" rel="stylesheet" />
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" />
<link href="<?php echo base_url('assets/vendors/font-awesome/css/font-awesome.min.css'); ?>" rel="stylesheet" />
<link rel="stylesheet" href="<?php echo base_url('assets/vendors/bootstrap-progressbar/css/bootstrap-progressbar-3.3.4.min.css'); ?>" />
<link id="pagestyle" href="<?php echo base_url('assets/build/css/custom.min.css'); ?>" rel="stylesheet" />
<link href="<?php echo base_url('assets/build/css/autoComplete.css'); ?>" rel="stylesheet" />



