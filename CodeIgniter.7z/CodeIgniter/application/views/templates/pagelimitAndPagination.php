<div class="card viewCard shadow-sm mt-5">
    <div class="d-flex justify-content-between align-items-end mb-3 mt-3">
        <div>
            <label for="rowId" class="form-label text-secondary ml-3">Select no. of rows</label>
            <select class="form-select-sm page_limit" id="page_limit">
                <option value="5">5</option>
                <option value="10">10</option>
                <option value="15">15</option>
                <option value="20">20</option>
            </select>
        </div>
        <div class="dynamicPagination mr-3">
           
        </div>
        <!-- pagination  -->
    </div>
    <div id="tableList" class="table-responsive card-body"></div>
    <!-- Dynamic table and pagination end  -->
    <div class="card-footer mt-5 d-flex justify-content-start align-items-center">
        <label for="totalPage" class="form-label text-secondary ml-3">Total Pages:</label>
        <div id="totalPage" class="totalPage ml-2 pb-2"></div>
        <label for="totalRecord" class="form-label text-secondary ml-3">Total Records:</label>
        <div id="totalRecord" class="totalRecord ml-2 pb-2"></div>
    </div>
</div>