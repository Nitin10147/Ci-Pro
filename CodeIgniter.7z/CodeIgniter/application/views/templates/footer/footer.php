

<script src="<?php echo base_url('assets/vendors/jquery/dist/jquery.min.js'); ?>"></script>
<script src="<?php echo base_url('assets/vendors/bootstrap/dist/js/bootstrap.bundle.min.js'); ?>"></script>
<script src="<?php echo base_url('assets/vendors/bootstrap-progressbar/bootstrap-progressbar.min.js'); ?>"></script>
<script src="<?php echo base_url('assets/build/js/custom.min.js'); ?>"></script>
<script src="<?php echo base_url('assets/build/js/autoComplete.js'); ?>"></script>
<script src="<?php echo base_url('assets/js/sweetAlert.js'); ?>"></script>
<script src="<?php echo base_url('assets/js/allMaster.js'); ?>"></script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>





