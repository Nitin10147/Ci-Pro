<!DOCTYPE html>
<html lang="en">
<?php
$this->load->view('templates/head')
?>

<body class="nav-md">
    <div class="container body">
        <div class="main_container">
            <?php
            $this->load->view('templates/navbarAndsidebar');
            ?>
            <div class="right_col" role="main">
                <div class=" ">
                    <div class="page-title">
                        <div class="clearfix"></div>
                        <div class="row">
                            <div class="col-md-12 col-sm-12 ">
                                <div class="x_panel">
                                    <ul class="nav nav-tabs" id="myTab" role="tablist">
                                        <li class="nav-item" role="presentation">
                                            <button class="nav-link active" id="home-tab" data-bs-toggle="tab" data-bs-target="#home-tab-pane" type="button" role="tab" aria-controls="home-tab-pane" aria-selected="true">All Client</button>
                                        </li>
                                        <li class="nav-item" role="presentation">
                                            <button class="nav-link" id="profile-tab" data-bs-toggle="tab" data-bs-target="#profile-tab-pane" type="button" role="tab" aria-controls="profile-tab-pane" aria-selected="false">Add Client</button>
                                        </li>
                                    </ul>
                                    <?php $this->load->view('templates/header/bootstrapToast'); ?>
                                    <div class="tab-content" id="myTabContent">
                                        <div class="tab-pane fade show active" id="home-tab-pane" role="tabpanel" aria-labelledby="home-tab" tabindex="0">
                                            <div class="user-form ">
                                                <div class="card shadow-sm mt-4">
                                                    <form id="searchForm" class="card-body search-form searchForm" method="POST">
                                                        <div class="row g-3">
                                                            <div class="col-12 col-sm-6 col-md-3 ">
                                                                <input type="text" name="searchname" id="client-master-name" class="form-control form-control-sm search-name" placeholder="Name" value="" maxlength="40" autocomplete="off">

                                                            </div>
                                                            <div class="col-12 col-sm-6 col-md-3 ">
                                                                <input type="text" name="searchemail" id="client-master-email" class="form-control form-control-sm" placeholder="Enter Email" maxlength="40" value="" autocomplete="off">
                                                            </div>
                                                            <div class="col-12 col-sm-6 col-md-3 ">
                                                                <input type="text" name="searchphone" id="client-master-phone" maxlength="10" class="form-control form-control-sm" placeholder="Enter Phone Number" value="" autocomplete="off">
                                                            </div>
                                                            <div class="col-12 col-sm-6 col-md-3 ">
                                                                <input type="text" name="searchaddress" id="client-master-address" maxlength="40" class="form-control form-control-sm" placeholder="Enter Address" value="" autocomplete="off">
                                                            </div>
                                                            <div class=" col-12 search-btn d-flex justify-content-end align-items-center">
                                                                <div class="middle"><button id="search" type="submit" class="btn btn-sm btn-success search grp"><i class="fa fa-search"></i> Search</button>
                                                                    <button id="reset" type="reset" class="btn btn-sm btn-secondary reset grp"><i class="fa fa-refresh"></i> Reset</button>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </form>
                                                </div>
                                                <?php $this->load->view('templates/pagelimitAndPagination.php')  ?>
                                            </div>

                                        </div>
                                        <div class="tab-pane fade" id="profile-tab-pane" role="tabpanel" aria-labelledby="profile-tab" tabindex="0">
                                            <div class="user-form card shadow-sm mt-4">
                                                <form method="POST" id="addDataForm" enctype="multipart/form-data" name="usermasterForm" class="form card-body">
                                                    <input type="text" name="id" id="fieldId" value="">
                                                    <input type="hidden" name='table' value="client_master">
                                                    <div class="row g-3">
                                                        <div class="col-12 col-sm-6 col-md-3">
                                                            <label for="name" class="form-label">Name <span class="text-danger">*</span></label>
                                                            <input type="text" name="name" id="name" class="form-control form-control-sm search-name" value="" minlength="3" maxlength="40" autocomplete="off" required>
                                                            <div class="text-danger err" id="nameErr"></div>
                                                        </div>
                                                        <div class="col-12 col-sm-6 col-md-3">
                                                            <label for="email" class="form-label">Email <span class="text-danger">*</span></label>
                                                            <input type="email" name="email" id="email" class="form-control form-control-sm" value="" maxlength="24" autocomplete="off" required>
                                                            <div class="text-danger err" id="emailErr"></div>
                                                        </div>
                                                        <div class="col-12 col-sm-6 col-md-3">
                                                            <label for="phone" class="form-label">Phone Number <span class="text-danger">*</span></label>
                                                            <input type="text" name="phone" id="phone" maxlength="10" class="form-control form-control-sm" value="" autocomplete="off" required>
                                                            <div class="text-danger err" id="phoneErr"></div>
                                                        </div>
                                                        <div class="col-12 col-sm-6 col-md-3">
                                                            <label for="state" class="form-label">State <span class="text-danger">*</span></label>
                                                            <select name="state" id="state" class="form-select form-select-sm state" required>
                                                                <option value="">Select State</option>
                                                            </select>
                                                        </div>
                                                        <div class="col-12 col-sm-6 col-md-3">
                                                            <label for="city" class="form-label">City <span class="text-danger">*</span></label>
                                                            <select name="city" id="city" class="form-select form-select-sm city" required>
                                                                <option class="Scity" value="">Select City</option>
                                                            </select>
                                                        </div>
                                                        <div class="col-12 col-sm-6 col-md-3 ">
                                                            <label for="address" class="form-label">Address <span class="text-danger">*</span></label>
                                                            <input type="text" name="address" id="address" class="form-control form-control-sm" maxlength="40" value="" autocomplete="off" required>
                                                            <span class="text-danger error-space err" id="addressErr"></span>
                                                        </div>
                                                        <div class="col-12 col-sm-6 col-md-3 ">
                                                            <label for="pincode" class="form-label">Pincode <span class="text-danger">*</span></label>
                                                            <input type="text" name="pincode" id="pincode" class="form-control form-control-sm" value="" autocomplete="off" maxlength="6" required>
                                                            <span class="text-danger err" id="pincodeErr"></span>
                                                        </div>
                                                        <div class="col-12 col-sm-6 col-md-3" id="statusDiv"><label for="status" class="form-label">Status</label>
                                                            <select name="status" id="status" class="form-select form-select-sm">
                                                                <option value="1" selected>Active</option>
                                                                <option value="0">Inactive</option>
                                                            </select>
                                                        </div>
                                                    </div>
                                                    <div class='d-flex justify-content-end mt-3'>
                                                        <button id='addDataFormBtn' class="btn btn-sm btn-success grp submit"><span class="update-icon"><i class="fa fa-send"></i></span><span class="update-text"> Submit</span></i></button>
                                                        <button type="reset" class="btn btn-sm btn-secondary reset grp"><i class="fa fa-refresh"> Reset</i></button>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- jQuery -->
            <?php $this->load->view('templates/footer/footer'); ?>
            <?php
            $this->load->view('client/script')
            ?>
</body>

</html>