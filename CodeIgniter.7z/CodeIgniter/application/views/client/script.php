<script>
                $(document).ready(function() {
                    loadState();
                    $(".state").on("change", function() {
                        var state = $(this).val();
                        if (state) {
                            loadDistrict(state);
                        } else {
                            $(".city").html('<option value="">Select City</option>');
                        }
                    });


                    function loadState() {
                        $.ajax({
                            url: "<?php echo base_url(); ?>client/getAddress",
                            type: "POST",
                            data: {
                                type: "state"
                            },
                            success: function(response) {
                                $(".state").html(
                                    '<option id="sState" value="">Select State</option>' + response
                                );
                            },
                        });
                    }
                });

                function loadDistrict(state) {
                    $.ajax({
                        url: "<?php echo base_url(); ?>client/getAddress",
                        type: "POST",
                        data: {
                            type: "city",
                            state: state
                        },
                        success: function(response) {
                            $(".city").html(
                                '<option id="sCity" value="">Select City</option>' + response
                            );
                        },
                    });
                }
            </script>