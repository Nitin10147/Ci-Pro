<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Login | Account Access</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css" rel="stylesheet">
  <style>
    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    }
    
    body {
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    
    .container {
      width: 520px;
      background-color: white;
      border-radius: 12px;
      box-shadow: 0 15px 30px rgba(0, 0, 0, 0.2);
      padding: 40px;
      animation: fadeIn 0.5s ease-in-out;
    }
    
    @keyframes fadeIn {
      from { opacity: 0; transform: translateY(20px); }
      to { opacity: 1; transform: translateY(0); }
    }
    
    h1 {
      color: #333;
      text-align: center;
      margin-bottom: 30px;
      font-weight: 600;
    }
    
    .form-group {
      margin-bottom: 20px;
      position: relative;
    }
    
    label {
      display: block;
      margin-bottom: 8px;
      color: #555;
      font-weight: 500;
    }
    
    input[type="email"],
    input[type="password"],
    input[type="text"] {
      width: 100%;
      padding: 12px 15px;
      border: 1px solid #ddd;
      border-radius: 6px;
      font-size: 16px;
      transition: all 0.3s;
    }
    
    input[type="email"]:focus,
    input[type="password"]:focus,
    input[type="text"]:focus {
      border-color: #6c63ff;
      outline: none;
      box-shadow: 0 0 0 3px rgba(108, 99, 255, 0.2);
    }
    
    .password-container {
      position: relative;
    }
    
    .toggle-password {
      position: absolute;
      right: 12px;
      top: 50%;
      transform: translateY(-50%);
      cursor: pointer;
      color: #555;
      transition: all 0.3s;
    }
    
    .toggle-password:hover {
      color: #6c63ff;
    }
    
    .error {
      color: #e74c3c;
      font-size: 14px;
      margin-top: 5px;
      display: none;
    }
    
    .remember-forgot {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 20px;
    }
    
    .checkbox-container {
      display: flex;
      align-items: center;
    }
    
    .checkbox-container input {
      margin-right: 8px;
    }
    
    .forgot {
      color: #6c63ff;
      text-decoration: none;
      font-size: 14px;
    }
    
    .forgot:hover {
      text-decoration: underline;
    }
    
    .captcha-container {
      display: flex;
      flex-direction: column;
      margin-bottom: 20px;
    }
    
    .captcha {
      background-color: #f7f7f7;
      border-radius: 6px;
      padding: 15px;
      text-align: center;
      font-weight: bold;
      letter-spacing: 8px;
      font-size: 20px;
      position: relative;
      overflow: hidden;
      user-select: none;
      margin-bottom: 10px;
    }
    
    .captcha::before {
      content: "";
      position: absolute;
      left: 0;
      top: 0;
      width: 100%;
      height: 100%;
      background: linear-gradient(45deg, 
        rgba(255,255,255,0) 45%, 
        rgba(255,255,255,0.5) 50%, 
        rgba(255,255,255,0) 55%);
      background-size: 200% 200%;
      animation: shine 3s infinite;
    }
    
    @keyframes shine {
      0% { background-position: 200% 0; }
      100% { background-position: -200% 0; }
    }
    
    .captcha-input {
      width: 100%;
      padding: 12px 15px;
      border: 1px solid #ddd;
      border-radius: 6px;
      font-size: 16px;
    }
    
    .refresh-captcha {
      color: #6c63ff;
      text-decoration: none;
      font-size: 14px;
      align-self: flex-end;
      margin-top: 5px;
      cursor: pointer;
    }
    
    .refresh-captcha:hover {
      text-decoration: underline;
    }
    
    .btn {
      width: 100%;
      background: linear-gradient(to right, #6c63ff, #9b66f9);
      color: white;
      border: none;
      padding: 15px;
      border-radius: 6px;
      font-size: 16px;
      cursor: pointer;
      transition: all 0.3s;
      font-weight: 600;
      box-shadow: 0 4px 6px rgba(107, 99, 255, 0.2);
    }
    
    .btn:hover {
      transform: translateY(-2px);
      box-shadow: 0 7px 14px rgba(107, 99, 255, 0.25);
    }
    
    .btn:active {
      transform: translateY(0);
    }
    
    .signup-link {
      text-align: center;
      margin-top: 20px;
      color: #555;
      font-size: 14px;
    }
    
    .signup-link a {
      color: #6c63ff;
      text-decoration: none;
      font-weight: 600;
    }
    
    .signup-link a:hover {
      text-decoration: underline;
    }
    
    .shake {
      animation: shake 0.5s;
    }
    
    @keyframes shake {
      0%, 100% { transform: translateX(0); }
      10%, 30%, 50%, 70%, 90% { transform: translateX(-5px); }
      20%, 40%, 60%, 80% { transform: translateX(5px); }
    }
    
    /* Error styling for invalid inputs */
    input.invalid {
      border-color: #e74c3c;
      background-color: rgba(231, 76, 60, 0.05);
    }
    
    input.invalid + .error {
      display: block;
    }
  </style>
</head>
<body>
  <div class="container">
    <h1>Welcome Back</h1>
      <?php if ($this->session->flashdata('message')): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <?= $this->session->flashdata('message') ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>
                 <?php if ($this->session->flashdata('error')): ?>
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <?= $this->session->flashdata('error') ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>
    <form id="loginForm" novalidate>
      <div class="form-group">
        <label for="email">Email Address</label>
        <input type="email" id="email" name="email" placeholder="Enter your email" value="<?php echo get_cookie('email'); ?>" required>
        <div class="error" id="emailError">Please enter a valid email address</div>
      </div>
      
      <div class="form-group">
        <label for="password">Password</label>
        <div class="password-container">
          <input type="password" id="password" name="password" placeholder="Enter your password" value="<?php echo get_cookie('password'); ?>" required>
          <i class="toggle-password fa-solid fa-eye" id="togglePassword"></i>
        </div>
        <div class="error" id="passwordError">Password must be at least 6 characters</div>
      </div>
      
      <div class="captcha-container">
        <label for="captcha">Enter Captcha</label>
        <div class="captcha" id="captchaText"></div>
        <input type="text" id="captchaInput" class="captcha-input" placeholder="Enter the code above">
        <div class="error" id="captchaError">Captcha does not match</div>
        <span class="refresh-captcha" id="refreshCaptcha">Refresh Captcha</span>
      </div>
      
      <div class="remember-forgot">
        <div class="checkbox-container">
          <input type="checkbox" id="remember" <?php echo get_cookie('email') ? 'checked' : ''; ?> name="remember">
          <label for="remember">Remember me</label>
        </div>
        <a href="<?= base_url('login/forgot_password') ?>" class="forgot" id="forgotPassword">Forgot Password?</a>
      </div>
      
      <button type="submit" class="btn">Login</button>
    </form>
    
   <div style="color:red ; text-align:center; margin-top:20px; border:1px solid red;border-radius:5px; font-size:20px ;height:40px; background-color:rgba(255, 0, 0, 0.1); display: none; padding:4px" id="loginError" ></div>
  </div>
   
   <?php $this->load->view('login/script'); ?>
</body>
</html>