<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forgot Password</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #e8f4ff;
            background-image: linear-gradient(135deg, #e8f4ff 0%, #d5e9f9 100%);
            height: 100vh;
            margin: 0;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .container {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100%;
        }
        .card {
            border: none;
            border-radius: 12px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
            max-width: 420px;
            width: 100%;
            background-color: #ffffff;
        }
        .card-header {
            background: linear-gradient(135deg, #4b6cb7 0%, #182848 100%);
            color: white;
            text-align: center;
            border-radius: 12px 12px 0 0 !important;
            padding: 25px;
            border: none;
        }
        .card-title {
            margin-bottom: 5px;
            font-weight: 600;
            font-size: 1.8rem;
        }
        .card-body {
            padding: 40px;
        }
        .form-floating .form-control {
            height: 60px;
            border-radius: 8px;
        }
        .form-floating .form-control:focus {
            box-shadow: 0 0 0 3px rgba(75, 108, 183, 0.25);
            border-color: #4b6cb7;
        }
        .btn-primary {
            background: linear-gradient(135deg, #4b6cb7 0%, #182848 100%);
            border: none;
            padding: 14px;
            font-weight: 500;
            letter-spacing: 0.5px;
            width: 100%;
            border-radius: 8px;
            transition: all 0.3s ease;
        }
        .btn-primary:hover {
            background: linear-gradient(135deg, #3b5ca7 0%, #0b1838 100%);
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
        }
        .alert {
            border-radius: 8px;
            margin-bottom: 25px;
        }
        .back-link {
            font-size: 0.9rem;
            text-align: center;
            display: block;
            margin-top: 25px;
            color: #4b6cb7;
        }
        .back-link:hover {
            color: #182848;
        }
        .icon-lock {
            font-size: 3.5rem;
            margin-bottom: 15px;
            background: -webkit-linear-gradient(#ffffff, #e0e0e0);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="card">
            <div class="card-header">
                <i class="fas fa-lock icon-lock"></i>
                <h3 class="card-title">Forgot Password</h3>
                <p class="mb-0">Enter your email to receive a reset link</p>
            </div>
            <div class="card-body">
                <?php if ($this->session->flashdata('message')): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <?= $this->session->flashdata('message') ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>
                
                <?php if ($this->session->flashdata('error')): ?>
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <?= $this->session->flashdata('error') ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>
                
                <form action="<?= base_url('login/send_reset_link') ?>" method="post">
                    <div class="form-floating mb-4">
                        <input type="email" class="form-control" id="email" name="email" placeholder="name@example.com" required>
                        <label for="email">Email address</label>
                    </div>
                    <button type="submit" class="btn btn-primary btn-lg">
                        <i class="fas fa-paper-plane me-2"></i>Send Reset Link
                    </button>
                </form>     
                <a href="<?= base_url('login') ?>" class="back-link text-decoration-none">
                    <i class="fas fa-arrow-left me-1"></i>Back to Login
                </a>
            </div>
        </div>
    </div>
    <?php $this->load->view('login/script'); ?>
</body>
</html>