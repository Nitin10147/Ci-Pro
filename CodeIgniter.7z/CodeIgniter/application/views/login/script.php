
<script src="<?php echo base_url('assets/vendors/jquery/dist/jquery.min.js'); ?>"></script>
<script>
 $(document).ready(function () {
    // Password visibility toggle
    $('.toggle-password').on('click', function () {
        const targetId = $(this).attr('data-target');
        const $inputField = $('#' + targetId);
        if ($inputField.attr('type') === 'password') {
            $inputField.attr('type', 'text');
            $(this).removeClass('fa-eye').addClass('fa-eye-slash');
        } else {
            $inputField.attr('type', 'password');
            $(this).removeClass('fa-eye-slash').addClass('fa-eye');
        }
    });
    $('#password').on('input', function () {
        const value = $(this).val();
        let strength = 0;
        if (value.length >= 8) strength += 25;
        if (/[A-Z]/.test(value)) strength += 25;
        if (/[0-9]/.test(value)) strength += 25;
        if (/[^A-Za-z0-9]/.test(value)) strength += 25;
        $('.password-strength').css('width', strength + '%');
        if (strength <= 25) {
            $('.password-strength').css('background-color', '#dc3545'); 
        } else if (strength <= 50) {
            $('.password-strength').css('background-color', '#ffc107'); 
        } else if (strength <= 75) {
            $('.password-strength').css('background-color', '#0dcaf0');
        } else {
            $('.password-strength').css('background-color', '#198754'); 
        }
    });

    // Password match validation
    $('#resetForm').on('submit', function (event) {
        if ($('#password').val() !== $('#confirm_password').val()) {
            event.preventDefault();
            $('#confirm_password').addClass('is-invalid');
            $('#confirm_password_error').text('Passwords do not match');
        }
    });
});




function generateCaptcha() {
      const chars = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
      let captcha = '';
      for (let i = 0; i < 6; i++) {
        captcha += chars.charAt(Math.floor(Math.random() * chars.length));
      }
      document.getElementById('captchaText').innerText = captcha;
      return captcha;
    }
    
    let currentCaptcha = generateCaptcha();
    const loginForm = document.getElementById('loginForm');
    const emailInput = document.getElementById('email');
    const passwordInput = document.getElementById('password');
    const captchaInput = document.getElementById('captchaInput');
    const refreshCaptchaBtn = document.getElementById('refreshCaptcha');
    const forgotPasswordLink = document.getElementById('forgotPassword');
    const togglePassword = document.getElementById('togglePassword');
    
    // Toggle password visibility
    togglePassword.addEventListener('click', function() {
      const type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
      passwordInput.setAttribute('type', type);
      
      // Toggle the eye icon
      this.classList.toggle('fa-eye');
      this.classList.toggle('fa-eye-slash');
    });
    
    // Refresh captcha when clicked
    refreshCaptchaBtn.addEventListener('click', function() {
      currentCaptcha = generateCaptcha();
      captchaInput.value = '';
      captchaInput.classList.remove('invalid');
      document.getElementById('captchaError').style.display = 'none';
    });

    
    // Validate email format
    function validateEmail(email) {
      const re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
      return re.test(String(email).toLowerCase());
    }
    
    // Validate form on submit
    loginForm.addEventListener('submit', function(e) {
      e.preventDefault();
      
      let isValid = true;
      
      // Reset error states
      emailInput.classList.remove('invalid');
      passwordInput.classList.remove('invalid');
      captchaInput.classList.remove('invalid');
      document.getElementById('emailError').style.display = 'none';
      document.getElementById('passwordError').style.display = 'none';
      document.getElementById('captchaError').style.display = 'none';
      
      // Validate email
      if (!validateEmail(emailInput.value)) {
        emailInput.classList.add('invalid');
        document.getElementById('emailError').style.display = 'block';
        isValid = false;
      }
      
      // Validate password
      if (passwordInput.value.length < 6) {
        passwordInput.classList.add('invalid');
        document.getElementById('passwordError').style.display = 'block';
        isValid = false;
      }
      
      // Validate captcha
      if (captchaInput.value.toUpperCase() !== currentCaptcha) {
        captchaInput.classList.add('invalid');
        document.getElementById('captchaError').style.display = 'block';
        currentCaptcha = generateCaptcha();
        captchaInput.value = '';
        isValid = false;
      }
      
      // If valid, submit the form (in a real app, you'd send to server)
      if (isValid) {
        let formData = new FormData(loginForm);
        const baseURL = window.location.href;
        $.ajax({
          url: baseURL + "/loginSuccess",
          type: "POST",
          data: formData,
          processData: false,
          contentType: false,
          dataType: "json",
          success: function (data) {
            if (data.status == 1) {
              window.location.href = "<?php echo base_url(); ?>dashboard";
            } else {
              $("#loginError").show();
              $("#loginError").html(data.message);
            }
          }
        }
        );
      } else {
        const container = document.querySelector('.container');
        container.classList.add('shake');
        setTimeout(() => {
          container.classList.remove('shake');
        }, 500);
      }
    });
    
    // Clear error message when input changes
    emailInput.addEventListener('input', function() {
      this.classList.remove('invalid');
      document.getElementById('emailError').style.display = 'none';
    });
    
    passwordInput.addEventListener('input', function() {
      this.classList.remove('invalid');
      document.getElementById('passwordError').style.display = 'none';
    });
    
    captchaInput.addEventListener('input', function() {
      this.classList.remove('invalid');
      document.getElementById('captchaError').style.display = 'none';
    });
</script>