<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reset Password</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #e8f4ff;
            background-image: linear-gradient(135deg, #e8f4ff 0%, #d5e9f9 100%);
            height: 100vh;
            margin: 0;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .container {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100%;
        }
        .card {
            border: none;
            border-radius: 12px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
            max-width: 450px;
            width: 100%;
            background-color: #ffffff;
        }
        .card-header {
            background: linear-gradient(135deg, #4b6cb7 0%, #182848 100%);
            color: white;
            text-align: center;
            border-radius: 12px 12px 0 0 !important;
            padding: 25px;
            border: none;
        }
        .card-title {
            margin-bottom: 5px;
            font-weight: 600;
            font-size: 1.8rem;
        }
        .card-body {
            padding: 40px;
        }
        .form-floating .form-control {
            height: 60px;
            border-radius: 8px;
        }
        .form-floating .form-control:focus {
            box-shadow: 0 0 0 3px rgba(75, 108, 183, 0.25);
            border-color: #4b6cb7;
        }
        .btn-primary {
            background: linear-gradient(135deg, #4b6cb7 0%, #182848 100%);
            border: none;
            padding: 14px;
            font-weight: 500;
            letter-spacing: 0.5px;
            width: 100%;
            border-radius: 8px;
            transition: all 0.3s ease;
            margin-top: 10px;
        }
        .btn-primary:hover {
            background: linear-gradient(135deg, #3b5ca7 0%, #0b1838 100%);
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
        }
        .alert {
            border-radius: 8px;
            margin-bottom: 25px;
        }
        .icon-key {
            font-size: 3.5rem;
            margin-bottom: 15px;
            background: -webkit-linear-gradient(#ffffff, #e0e0e0);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }
        .password-info {
            font-size: 0.8rem;
            color: #6c757d;
            margin-top: 5px;
        }
        .password-strength {
            height: 5px;
            margin-top: 10px;
            margin-bottom: 20px;
            border-radius: 3px;
            background-color: #e9ecef;
        }
        .password-container {
            position: relative;
        }
        .toggle-password {
            position: absolute;
            right: 15px;
            top: 18px;
            cursor: pointer;
            color: #6c757d;
            z-index: 10;
        }
        .toggle-password:hover {
            color: #4b6cb7;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="card">
            <div class="card-header">
                <i class="fas fa-key icon-key"></i>
                <h3 class="card-title">Reset Password</h3>
                <p class="mb-0">Create a new secure password</p>
            </div>
            <div class="card-body">
                <?php if ($this->session->flashdata('message')): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <?= $this->session->flashdata('message') ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>
                
                <?php if ($this->session->flashdata('error')): ?>
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <?= $this->session->flashdata('error') ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>
                
                <form action="<?= base_url('login/update_password') ?>" method="post" id="resetForm">
                    <input type="hidden" name="token" value="<?= $token ?>">
                    
                    <div class="form-floating mb-3 password-container">
                        <input type="password" class="form-control" id="password" name="password" placeholder="New Password" required>
                        <i class="toggle-password fas fa-eye" data-target="password"></i>
                        <label for="password">New Password</label>
                    </div>
                    <p class="password-info">Password must be at least 8 characters with letters and numbers</p>
                    <div class="password-strength"></div>
                    
                    <div class="form-floating mb-4 password-container">
                        <input type="password" class="form-control" id="confirm_password" name="confirm_password" placeholder="Confirm Password" required>
                        <i class="toggle-password fas fa-eye" data-target="confirm_password"></i>
                        <label for="confirm_password">Confirm Password</label>
                    </div>
                    
                    <button type="submit" class="btn btn-primary btn-lg">
                        <i class="fas fa-check-circle me-2"></i>Update Password
                    </button>
                </form>
            </div>
        </div>
    </div>
    <?php $this->load->view('login/script'); ?>
</body>
</html>