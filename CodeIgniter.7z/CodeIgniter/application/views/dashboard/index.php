<!DOCTYPE html>
<html lang="en">
<?php 
$this->load->view('templates/head') ;

?>


<body class="nav-md">
  <div class="container body">
    <div class="main_container">
      <?php
      $this->load->view('templates/navbarAndsidebar');
      ?>
      <div class="right_col" role="main">
        <!-- top tiles -->
       <div class="container py-4">
    <div class=" mb-4">
      <div class="">
        <div class="row">
          <!-- User Master Tile -->
          <div class="col-md-6 col-lg-3 mb-4">
            <div class="card h-100 border-0 shadow-sm">
              <div class="card-body">
                <div class="d-flex align-items-center mb-2">
                  <i class="fa fa-users text-primary me-2"></i>
                  <span class="text-muted">User Master</span>
                </div>
                <h2 class="display-6 text-primary mb-2">
    <?php 
    if (!empty($dashboard_data)) {
        echo $dashboard_data[0]['users'];
    } else {
        echo '0';
    }
    ?>
</h2>

                <hr>
                <a href="<?php echo base_url('user') ?>" class="btn btn-sm btn-outline-primary w-100">
                  <i class="fa fa-cog me-1"></i> Manage Users
                </a>
              </div>
            </div>
          </div>
          
          <!-- Client Master Tile -->
          <div class="col-md-6 col-lg-3 mb-4">
            <div class="card h-100 border-0 shadow-sm">
              <div class="card-body">
                <div class="d-flex align-items-center mb-2">
                  <i class="fa fa-building text-purple me-2"></i>
                  <span class="text-muted">Client Master</span>
                </div>
                <h2 class="display-6 text-purple mb-2"> <?php 
    if (!empty($dashboard_data)) {
        echo $dashboard_data[0]['clients'];
    } else {
        echo '0';
    }
    ?></h2>
             
                <hr>
                <a href="<?php echo base_url('client') ?>" class="btn btn-sm btn-outline-purple w-100">
                  <i class="fa fa-cog me-1"></i> Manage Clients
                </a>
              </div>
            </div>
          </div>
          
          <!-- Item Master Tile -->
          <div class="col-md-6 col-lg-3 mb-4">
            <div class="card h-100 border-0 shadow-sm">
              <div class="card-body">
                <div class="d-flex align-items-center mb-2">
                  <i class="fa fa-cubes text-warning me-2"></i>
                  <span class="text-muted">Item Master</span>
                </div>
                <h2 class="display-6 text-warning mb-2"> <?php 
    if (!empty($dashboard_data)) {
        echo $dashboard_data[0]['items'];
    } else {
        echo '0';
    }
    ?></h2>
                
                <hr>
                <a href="<?php echo base_url('item') ?>" class="btn btn-sm btn-outline-warning w-100">
                  <i class="fa fa-cog me-1"></i> Manage Items
                </a>
              </div>
            </div>
          </div>
          
          <!-- Invoice Master Tile -->
          <div class="col-md-6 col-lg-3 mb-4">
            <div class="card h-100 border-0 shadow-sm">
              <div class="card-body">
                <div class="d-flex align-items-center mb-2">
                  <i class="fa fa-file-invoice text-success me-2"></i>
                  <span class="text-muted">Invoice Master</span>
                </div>
                <h2 class="display-6 text-success mb-2"> <?php 
    if (!empty($dashboard_data)) {
        echo " ₹". $dashboard_data[0]['invoice_total_amount'];
    } else {
        echo '₹ 0.00';
    }
    ?></h2>
                <hr>
                <a href="<?php echo base_url('invoice') ?>" class="btn btn-sm btn-outline-success w-100">
                  <i class="fa fa-cog me-1"></i> Manage Invoices
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
      </div>
    </div>
<?php  
$this->load->view('templates/footer/footer'); 
?>
</body>

</html>