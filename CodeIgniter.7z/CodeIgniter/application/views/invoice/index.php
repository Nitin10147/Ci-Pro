<!DOCTYPE html>
<html lang="en">

<?php

$this->load->view('templates/head')

?>
<body class="nav-md">
    <div class="container body">
        <div class="main_container">
            <?php
            $this->load->view('templates/navbarAndsidebar');
            ?>
            <div class="right_col" role="main">
                <div class=" ">
                    <div class="page-title">
                        <div class="clearfix"></div>
                        <div class="row">
                            <div class="col-md-12 col-sm-12 ">
                                <div class="x_panel">
                                    <ul class="nav nav-tabs" id="myTab" role="tablist">
                                        <li class="nav-item" role="presentation">
                                            <button class="nav-link active" id="home-tab" data-bs-toggle="tab" data-bs-target="#home-tab-pane" type="button" role="tab" aria-controls="home-tab-pane" aria-selected="true">All Invoice</button>
                                        </li>
                                        <li class="nav-item" role="presentation">
                                            <button class="nav-link Invoice-text" id="profile-tab" data-bs-toggle="tab" data-bs-target="#profile-tab-pane" type="button" role="tab" aria-controls="profile-tab-pane" aria-selected="false">Add Invoice</button>
                                        </li>
                                    </ul>
                                    <?php $this->load->view('templates/header/bootstrapToast'); ?>
                                    <div class="tab-content" id="myTabContent">
                                        <div class="tab-pane fade show active" id="home-tab-pane" role="tabpanel" aria-labelledby="home-tab" tabindex="0">
                                            <div class="user-form ">
                                                <div class="card shadow-sm mt-4">
                                                    <form id="searchForm" class="card-body search-form searchForm" method="POST">
                                                        <div class="row g-3">
                                                            <div class="col-12 col-sm-6 col-md-4 ">
                                                                <input type="text" name="search_invoice_no" id="invoice-master-invoice-no" class="form-control form-control-sm" placeholder="Invoice Number" value="" maxlength="10" autocomplete="off">
                                                            </div>
                                                            <div class="col-12 col-sm-6 col-md-4 ">
                                                                <input type="text" name="search_name" id="invoice-master-name" class="form-control form-control-sm search-name" placeholder="Name" value="" maxlength="30" autocomplete="off">
                                                            </div>
                                                            <div class="col-12 col-sm-6 col-md-4">
                                                                <input type="email" name="search_email" id="invoice-master-email" class="form-control form-control-sm" placeholder="Email" value="" maxlength="40" autocomplete="off">
                                                            </div>
                                                            <div class="col-12 col-sm-6 col-md-4">
                                                                <input type="text" name="search_phone" id="invoice-master-phone" class="form-control form-control-sm number" placeholder="Phone Number" value="" maxlength="10" autocomplete="off">
                                                            </div>
                                                            <div class="col-12 col-sm-6 col-md-4">
                                                                <div class="row align-items-center g-2 w-100">
                                                                    <div class="col-auto">
                                                                        <input type="date" id="date-from" name="date_from" class="form-control form-control-sm">
                                                                    </div>
                                                                    <div class="col-auto">
                                                                        <span>To</span>
                                                                    </div>
                                                                    <div class="col-auto">
                                                                        <input type="date" id="date-to" name="date_to" class="form-control form-control-sm">
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class=" col-12 col-sm-6 col-md-4 search-btn d-flex justify-content-end align-items-center">
                                                                <div class="middle"><button id="search" type="submit" class="btn btn-sm btn-success search grp"><i class="fa fa-search"></i> Search</button>
                                                                    <button id="reset" type="reset" class="btn btn-sm btn-secondary reset grp"><i class="fa fa-refresh"></i> Reset</button>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </form>
                                                </div>
                                                <?php $this->load->view('templates/pagelimitAndPagination.php')  ?>

                                                <!-- Bootstrap Modal -->
<!-- Email Modal -->
<div class="modal fade" id="emailModal" tabindex="-1" aria-labelledby="emailModalLabel" aria-modal="true" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Send Invoice via Email</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <label for="clientEmail">Client Email:</label>
                <input type="email" name="clientEmail" class="form-control" id="clientEmail" style='background-color: #e9ecef;'>
                <label for="emailMessage" class="mt-3">Message:</label>
                <textarea class="form-control" id="emailMessage" rows="4" placeholder="Enter your message"></textarea>

                <!-- Hidden Invoice ID -->
                <input type="hidden" id="invoiceId">

                <div id="emailStatus" class="mt-2"></div> 
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary" id="sendEmail">
                    <span id="sendEmailText">Send Email</span>
                    <span id="emailLoader" class="spinner-border spinner-border-sm" style="display: none;"></span>
                </button>
            </div>
        </div>
    </div>
</div>


                                            </div>
                                           
                                        </div>
                                        <div class="tab-pane fade" id="profile-tab-pane" role="tabpanel" aria-labelledby="profile-tab" tabindex="0">
                                            <div class="user-form card shadow-sm mt-4">
                                                <form method="POST" id="addDataForm" enctype="multipart/form-data" class="form card-body">
                                                    <input type="hidden" name="id" id="fieldId" autocomplete="off" value="">
                                                    <input type="hidden" name="client_id" id="client_id" value="" autocomplete="off">
                                                    <input type="hidden" name='table' value="invoice_master" >
                                                    <div class="card pb-3">
                                                        <div class="card-body">
                                                            <div class="row g-3">
                                                                <div class="col-12 col-sm-6 col-md-3">
                                                                    <label for="invoice_no" class="form-label">Invoice No. <span class="text-danger"> *</span></label>
                                                                    <input type="number" name="invoice_no" id="invoice_no" class="form-control form-control-sm number invoice_no" pattern="/^-?\d+\.?\d*$/" onKeyPress="if(this.value.length==10) return false;" placeholder="" value="" maxlength="20" autocomplete="off" required>
                                                                </div>
                                                                <div class="col-12 col-sm-6 col-md-3">
                                                                    <label for="invoice_date" class="form-label">Invoice Date <span class="text-danger"> *</span></label>
                                                                    <input type="date" name="invoice_date" id="invoice_date" class="form-control form-control-sm" value="" maxlength="24" autocomplete="off" required>
                                                                </div>
                                                            </div>
                                                            <div class="row g-3 mt-3">
                                                                <input type="hidden" name="client_id" id="client_Id">
                                                                <div class="col-12 col-sm-6 col-md-3">
                                                                    <label for="name" class="form-label">Client Name <span class="text-danger"> *</span></label>
                                                                    <input type="text" name="client_name" id="clientNameId" class="search-name form-control form-control-sm" value="" minlength="3" maxlength="40" autocomplete="off" required>
                                                                    <small class="text-danger err" id='client_nameErr'></small>
                                                                </div>
                                                                <div class="col-12 col-sm-6 col-md-3">
                                                                    <label for="phone" class="form-label">Phone<span class="text-danger"> *</span></label>
                                                                    <input type="text"  id="clientPhoneId" name="client_phone" class="form-control form-control-sm" value="" style="background-color: #e9ecef;" maxlength="10" readonly autocomplete="off" required>
                                                                </div>
                                                                <div class="col-12 col-sm-6 col-md-3">
                                                                    <label for="email" class="form-label">Email<span class="text-danger"> *</span></label>
                                                                    <input type="text" id="clientEmailId" name="client_email" class="form-control form-control-sm" value="" style="background-color: #e9ecef;" maxlength="24" readonly autocomplete="off" required>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class='card mt-4 pt-2 table-div'>
                                                        <div class="card-body ">
                                                            <table class="table table-bordered ">
                                                                <thead class="table-secondary">
                                                                    <tr>
                                                                        <th>Item Name</th>
                                                                        <th>Item Price (₹) </th>
                                                                        <th>Quantity</th>
                                                                        <th>Amount (₹) </th>
                                                                        <th>Action</th>
                                                                    </tr>
                                                                </thead>
                                                                <tbody class="itemTable">
                                                                    <tr class="tableClone">  
                                                                        <td><input type="hidden" class="item_id" name="item_id[]"><input type="text" name="item_name[]" class="form-control form-control-sm itemNameAddId" value="" autocomplete="off" required><small id="item_nameErr" class="text-danger err"></small></td>
                                                                        <td><input type="text" name="price[]" class="form-control form-control-sm itemPriceAddId" value="" autocomplete="off" required><small id="item_priceErr" class="text-danger err"></small></td>
                                                                        <td><input type="text" name="quantity[]" class="form-control form-control-sm quantityAddId" value="" autocomplete="off" required><small id="item_quantityErr" class="text-danger err"></small></td>
                                                                        <td><input type="text" name="amount[]" class="form-control form-control-sm itemAmountAddId" value="" autocomplete="off" required><small id="item_amountErr" class="text-danger err"></small></td>
                                                                        <td class="text-center"><button type="button" class="btn btn-danger deleteRow btn-sm"><i class="fa fa-trash"></i></button></td>
                                                                    </tr>
                                                                </tbody>
                                                            </table>
                                                        </div>
                                                    </div>
                                                    <div class="d-flex justify-content-between mt-3">
                                                    <div class="ml-3">
                                                        <button type="button" id="addRow" class="btn btn-sm btn-primary grp"><i class="fa fa-plus"></i> Add Row</button>
                                                    </div>
                                                    <div class="mr-3">
                                                        <div class='' style="width: 230px; color:black">
                                                            <label class="form-label">Total Amount<span class="text-danger"> *</span></label>
                                                            <input type="text" name="total_amount" id="totalAmount" class="form-control form-control-sm total-amount textAlignRight" style="background-color: #e9ecef;" maxlength="24" autocomplete="off" value="0.00" readonly required>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class='d-flex justify-content-end mt-3 mb-3 mr-3'>
                                                <button id='addDataFormBtn' class="btn btn-sm btn-success grp submit"><span class="update-icon"><i class="fa fa-send"></i></span><span class="update-text"> Submit</span></i></button>
                                                <button type="reset" class="btn btn-sm btn-secondary reset grp"><i class="fa fa-refresh"> Reset</i></button>
                                                </div>
                                                </form>
                                               
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- jQuery -->
            <?php
            $this->load->view('templates/footer/footer'); 
            $this->load->view('invoice/script');
            ?>
</body>

</html>