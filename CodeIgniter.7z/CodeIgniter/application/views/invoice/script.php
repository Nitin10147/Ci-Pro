<script>
  $(document).ready(function() {
            // Function to add a new row
            $('#addRow').click(function() {
                var newRow = $('.tableClone').first().clone(); 
                newRow.find('input').val(''); 
                $('.itemTable').append(newRow); 
            });

            // Function to delete a row
            $(document).on('click', '.deleteRow', function() {
                if ($('.itemTable tr').length > 1) { 
                    $(this).closest('tr').remove(); 
                } 
            });
        });

		


    let clientAutoComplete = [];
    $("#clientNameId").autocomplete({
        source: function(request, response) {
            let value = request.term;
            $.ajax({
                url: urlMaker() + "/client_autocomplete",
                type: "POST",
                data: {
                    client_name: value
                },
                dataType: "json",
                success: function(data) {
                    clientAutoComplete = [];
                    let myArr = data['data'];
                    for (let i = 0; i < myArr.length; i++) {
                        clientAutoComplete.push({
                            label: myArr[i].name,
                            value: myArr[i].name,
                            phone: myArr[i].phone,
                            email: myArr[i].email,
                            id: myArr[i].id,
                        });
                    }
                    response(clientAutoComplete);
                },
            });
        },
        select: function(event, ui) {
            $("#clientPhoneId").val(ui.item.phone);
            $("#clientEmailId").val(ui.item.email);
            $("#client_Id").val(ui.item.id);
        },
    });

   
    $("#clientNameId").on("input", function() {
        if ($(this).val() === "") {
            $("#clientPhoneId").val("");
            $("#clientEmailId").val("");
            $("#client_Id").val("");
        }
    });


let itemAutoComplete = [];
function getitems(e) {
	$(".itemNameAddId").autocomplete({
		source: function (request, response) {
			let value = request.term;
			let idArr = $(e).parents(".tableClone").find(".item_id").val();
			let newSet = new Set(idArr);
			idArr = [...newSet];
			console.log(idArr);
			$.ajax({
				url: urlMaker() + "/item_autocomplete",
				type: "POST",
				data: { item_name: value, arrId: idArr },
				dataType: "json",
				success: function (data) {
					itemAutoComplete = [];
					let myArr = data["data"];
					for (let i = 0; i < myArr.length; i++) {
						itemAutoComplete.push({
							label: myArr[i].item_name,
							value: myArr[i].item_name,
							price: myArr[i].price,
							id: myArr[i].id,
						});
						response(itemAutoComplete);
					}
				},
			});
		},
		select: function (event, ui) {
			$(this)
				.parents(".tableClone")
				.find(".itemPriceAddId")
				.val(ui.item.price);
			$(this).parents(".tableClone").find(".item_id").val(ui.item.id);
			$(this).parents(".tableClone").find(".quantityAddId").val(1);
			$(this).parents(".tableClone").find(".quantityAddId").trigger("input");
		},
	});
}


$(document).on("keyup change input paste ", ".itemNameAddId", function (e) {
	getitems(e);
});


$(document).on("input", ".itemNameAddId", function () {
    if ($(this).val() === "") {
        $(this).parents(".tableClone").find(".item_id").val("");
        $(this).parents(".tableClone").find(".itemPriceAddId").val("");
        $(this).parents(".tableClone").find(".quantityAddId").val("");
        $(this).parents(".tableClone").find(".itemAmountAddId").val("");
        calculateTotalAmount();
    }
})




// Total amount of each item
$(document).on("input", ".quantityAddId", function () {
	let price = $(this).parents(".tableClone").find(".itemPriceAddId").val();
	let amount = $(this)
		.parents(".tableClone")
		.find(".itemAmountAddId")
		.val(parseFloat($(this).val() * price).toFixed(2));
	// Update total amount dynamically whenever the quantity is updated
	calculateTotalAmount();
});


function calculateTotalAmount() {
	let totalAmount = 0;
	$(".itemAmountAddId").each(function () {
		let amount = parseFloat($(this).val()) || 0; // Parse and default to 0 if empty
		totalAmount += amount;
	});

	console.log(totalAmount);

	// Update totalAmount field
	$("#totalAmount").val(totalAmount.toFixed(2));
}



// Generate invoice number 

function generateInvoiceNo() {
	$.ajax({
		url: urlMaker() + "/generateInvoiceNo",
		type: "POST",
		dataType: "json",
		success: function (data) {
			data = data.data;
			let invoice_number =  data;
			$("#invoice_no").val(invoice_number);
		},
	});
}





function resetInvoiceForm() {
	const today = new Date();
    const formattedDate = today.toISOString().split('T')[0];
    $('#invoice_date').val(formattedDate);
	generateInvoiceNo();
}


//at the time of reset only one row will be there
$(document).on("click", ".reset, #profile-tab", function (e) {
	$('.itemTable tr:not(:first)').remove();
	resetInvoiceForm();
});





$(document).on("click", ".pdf-generate", function() {
    const id = $(this).attr("invoice_id");
    const button = $(this); 
    button.attr("disabled", true);
    $.ajax({
        url: urlMaker() + "/pdf_generate",
        type: "POST",
        data: { invoice_id: id },
        success: function(response) {
            button.attr("disabled", false);
            if (response.includes("invoice_pdf/")) {
                window.open(response, "_blank");
            } else {
                alert("Error generating PDF. Please try again.");
            }
        },
        error: function() {
            button.attr("disabled", false);
            alert("Failed to generate PDF. Check server logs.");
        }
    });
});



$(document).ready(function () {
    // Show modal and set pre-filled client email
    $(document).on("click", ".email_send", function () {
        let emailId = $(this).attr("email_id");
        let clientEmail = $(this).attr("client_email");
        $("#invoiceId").val(emailId);
        $("#clientEmail").val(clientEmail);
        $("#emailModal").modal("show");
        $("#emailMessage").val("Hello Dear Client we are sending you invoice:");
        $.ajax({
        url: urlMaker() + "/pdf_generate",
        type: "POST",
        data: { invoice_id: emailId },
        success: function(response) {
          console.log(response);
        },
        error: function() {
           console.log("Failed to generate PDF. Check server logs.");
        }
    });
    });

    // Handle email sending
    $("#sendEmail").click(function () {
        let invoiceId = $("#invoiceId").val();
        let message = $("#emailMessage").val();
        let clientEmail = $("#clientEmail").val();
        // Show loading indicator
        $("#sendEmail").attr("disabled", true);
        $("#sendEmailText").text("Sending...");
        $("#emailLoader").show();

        $.ajax({
            url: "send_invoice_email",
            type: "POST",
            data: {
                invoice_id: invoiceId,
                client_email: clientEmail,
                message: message
            },
            success: function (response) {
                let res = JSON.parse(response);
                if (res.status === "success") {
                    $("#emailStatus").html('<div class="alert alert-success">' + res.message + '</div>');
                } else {
                    $("#emailStatus").html('<div class="alert alert-danger">' + res.message + '</div>');
                }
                // Reset button
                $("#sendEmail").attr("disabled", false);
                $("#sendEmailText").text("Send Email");
                $("#emailLoader").hide();
                setTimeout(() => {
                    $("#emailModal").modal("hide");
                }, 2000);
            },
            error: function () {
                $("#emailStatus").html('<div class="alert alert-danger">Error sending email.</div>');
                $("#sendEmail").attr("disabled", false);
                $("#sendEmailText").text("Send Email");
                $("#emailLoader").hide();
            }
        });
    });
});













</script>