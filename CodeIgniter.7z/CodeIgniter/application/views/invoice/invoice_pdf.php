<?php
$invoice_no = $data['invoice_no'];
$invoice_date = date('d/m/Y', strtotime($data['invoice_date']));
$client_name = $data['client_name'];
$client_email = $data['client_email'];
$client_phone = $data['client_phone'];
$address = $data['address'];
$item_names = explode(',', $data['item_names']);
$quantities = explode(',', $data['quantities']);
$item_prices = explode(',', $data['item_prices']);
$total_amount = $data['total_amount'];

$numberToword = $data['numberToword'];

?>
<html>

<head>
    <meta charset="UTF-8">
    <title>SanSoftware Invoice</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            font-size: 12px;
            color: #2c3e50;

            padding: 20px;
        }

        .invoice-box {
            width: 98%;
            border: 1px solid #ddd;
            padding: 20px;
            border-radius: 10px;

        }

        .header {
            text-align: center;
            margin-bottom: 20px;
        }

        .company-info,
        .invoice-details {
            width: 100%;
            margin-bottom: 20px;
        }

        .company-info td,
        .invoice-details td {
            vertical-align: top;
            padding: 5px;
        }

        .table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        .table th,
        .table td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }

        .table th {
            background-color: #f8f9fa;
        }

        .total-box {
            width: 100%;
            padding: 10px;
            border-top: 2px solid #2c3e50;
            background: #f8f9fa;
            margin-top: 10px;
        }

        .amount-in-words {
            font-style: italic;
            color: #4e6f8f;
            margin-top: 10px;
        }
    </style>
</head>

<body>
 <div class="invoice-box">
        <div class="header">
            <img src="http://localhost/codeigniter/assets/img/sansoftwares_logo.png" alt="SanSoftware Logo" width="200">
        </div>
        <table class="company-info">
            <tr>
                <td>
                    <strong>SanSoftware Inc.</strong><br>
                    3232, Gurugram<br>
                    Tel: 1234567880<br>
                    Email: billing@sansoftware.com
                </td>
                <td style="text-align: right;">
                    <strong>INVOICE</strong><br>
                    Invoice #: <?php echo $invoice_no; ?><br>
                    Date: <?php echo $invoice_date; ?><br>
                </td>
            </tr>
        </table>
        <table class="invoice-details">
            <tr>
                <td>
                    <strong>Client Details:</strong><br>
                    Client Name: <?php echo $client_name; ?><br>
                    Client Address: <?php echo $address; ?><br>
                    Mobile No.: <?php echo $client_phone; ?><br>
                    Email: <?php echo $client_email; ?><br>

                </td>
            </tr>
        </table>
        <table class="table">
            <thead>
                <tr>
                    <th width="50%">Item Name</th>
                    <th width="15%" style="text-align: center;">Quantity</th>
                    <th width="15%" style="text-align: right;">Unit Price</th>
                    <th width="20%" style="text-align: right;">Total Price</th>
                </tr>
            </thead>
            <tbody>
                <?php
                for ($i = 0; $i < count($item_names); $i++) {
                    $item_name = $item_names[$i];
                    $quantity = $quantities[$i];
                    $unit_price = $item_prices[$i];
                    $total_price = $quantity * $unit_price;
                    echo '<tr>
                        <td>' . $item_name . '</td>
                        <td style="text-align: center;">' . $quantity . '</td>
                        <td style="text-align: right;">' . number_format($unit_price, 2) . '</td>
                        <td style="text-align: right;">' . number_format($total_price, 2) . '</td>
                    </tr>';
                }
                ?>
                <tr>
                    <td colspan="3" style="text-align: right;"><strong>Total Amount:</strong></td>
                    <td style="text-align: right;"><strong>Rs. <?php echo number_format($total_amount, 2); ?></strong></td>
                </tr>
            </tbody>
        </table>
        <div class="total-box">
            <div class="amount-in-words">
                <strong>Amount in Words:</strong> 
                <?php echo ucfirst($numberToword); ?> Rupees Only
               
            </div>
        </div>
    </div>
</body>

</html>