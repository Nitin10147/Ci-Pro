<!DOCTYPE html>
<html lang="en">

<?php

$this->load->view('templates/head')

?>

<body class="nav-md">
  <div class="container body">
    <div class="main_container">
      <?php
      $this->load->view('templates/navbarAndsidebar');
      ?>
      <div class="right_col" role="main">
        <div class=" ">
          <div class="page-title">
            <div class="clearfix"></div>
            <div class="row">
  <div class="col-12">
    <div class="x_panel">
      <!-- Responsive Tab Navigation -->
      <ul class="nav nav-tabs" id="myTab" role="tablist">
        <li class="nav-item" role="presentation">
          <button class="nav-link active" id="home-tab" data-bs-toggle="tab" data-bs-target="#home-tab-pane" type="button" role="tab" aria-controls="home-tab-pane" aria-selected="true">All User</button>
        </li>
        <li class="nav-item" role="presentation">
          <button class="nav-link User-text" id="profile-tab" data-bs-toggle="tab" data-bs-target="#profile-tab-pane" type="button" role="tab" aria-controls="profile-tab-pane" aria-selected="false">Add User</button>
        </li>
      </ul>
      
      <?php $this->load->view('templates/header/bootstrapToast'); ?>
      
      <div class="tab-content" id="myTabContent">
        <!-- All Users Tab -->
        <div class="tab-pane fade show active" id="home-tab-pane" role="tabpanel" aria-labelledby="home-tab" tabindex="0">
          <div class="user-form">
            <div class="card shadow-sm mt-4">
              <form id="searchForm" class="card-body search-form searchForm" method="POST">
                <div class="row g-3">
                  <div class="col-12 col-sm-6 col-md-4 col-lg-3">
                    <input type="text" name="searchname" id="u-master-name" class="form-control form-control-sm search-name" placeholder="Name" value="" maxlength="40" autocomplete="off">
                  </div>
                  <div class="col-12 col-sm-6 col-md-4 col-lg-3">
                    <input type="text" name="searchemail" id="u-master-email" class="form-control form-control-sm" placeholder="Enter Email" maxlength="40" value="" autocomplete="off">
                  </div>
                  <div class="col-12 col-sm-6 col-md-4 col-lg-3">
                    <input type="text" name="searchphone" id="u-master-phone" maxlength="10" class="form-control form-control-sm" placeholder="Enter Phone Number" value="" autocomplete="off">
                  </div>
                  <div class="col-12 col-sm-6 col-md-12 col-lg-3 search-btn">
                    <div class="d-flex gap-2">
                      <button id="search" type="submit" data-url="/controller/usermaster.php" class="btn btn-sm btn-success search grp flex-fill">
                        <i class="fa fa-search"></i> Search
                      </button>
                      <button id="reset" type="reset" class="btn btn-sm btn-secondary reset grp flex-fill">
                        <i class="fa fa-refresh"></i> Reset
                      </button>
                    </div>
                  </div>
                </div>
              </form>
            </div>
            <?php $this->load->view('templates/pagelimitAndPagination.php') ?>
          </div>
        </div>
        
        <!-- Add User Tab -->
        <div class="tab-pane fade" id="profile-tab-pane" role="tabpanel" aria-labelledby="profile-tab" tabindex="0">
          <div class="user-form card shadow-sm mt-4">
            <form method="POST" id="addDataForm" enctype="multipart/form-data" name="usermasterForm" class="form card-body">
              <input type="hidden" name="id" id="fieldId" value="" autocomplete="off">
              <input type="hidden" name='table' value="user_master">
              
              <div class="row g-3">
                <!-- Name field -->
                <div class="col-12 col-sm-6 col-md-4 col-lg-3">
                  <label for="name" class="form-label">Name <span class="text-danger">*</span></label>
                  <input type="text" name="name" id="name" class="form-control form-control-sm search-name" autocomplete="off" value="" minlength="3" maxlength="40" required>
                  <div class="text-danger err" id="nameErr"></div>
                </div>
                
                <!-- Email field -->
                <div class="col-12 col-sm-6 col-md-4 col-lg-3">
                  <label for="email" class="form-label">Email <span class="text-danger">*</span></label>
                  <input type="email" name="email" id="email" class="form-control form-control-sm" value="" autocomplete="off" maxlength="24" required>
                  <div class="text-danger err" id="emailErr"></div>
                </div>
                
                <!-- Phone field -->
                <div class="col-12 col-sm-6 col-md-4 col-lg-3">
                  <label for="phone" class="form-label">Phone Number <span class="text-danger">*</span></label>
                  <input type="text" name="phone" id="phone" maxlength="10" class="form-control form-control-sm" autocomplete="off" value="" required>
                  <div class="text-danger err" id="phoneErr"></div>
                </div>
                
                <!-- Password field -->
                <div class="col-12 col-sm-6 col-md-4 col-lg-3">
                  <label for="password" class="form-label">Password <span class="text-danger">*</span></label>
                  <input type="password" name="password" id="password" class="form-control form-control-sm update-password" autocomplete="current-password" maxlength="20" value="" required>
                  <div class="text-danger err" id="passwordErr"></div>
                </div>
                
                <!-- Image upload field -->
                <div class="col-12 col-sm-6 col-md-4 col-lg-3 imageDiv" id="imageDiv">
                  <label for="image" class="form-label">Upload Image</label>
                  <input type="file" name="image" id="image" class="form-control form-control-sm image" accept="image/*" placeholder="Upload Image" value="">
                  
                  <div id="loadImg" class="mt-2" style="cursor: pointer; display: none;">
                    <div class="d-flex align-items-center">
                      <img id="preview" src="" alt="Previous Image" class="img-fluid me-2" style="width: 60px; height: 60px; border: 2px solid #a8a8a8; border-radius: 50%;">
                      <a id="removeImage" name="removeImage" class="btn btn-sm btn-outline-danger">
                        <i class="fa fa-trash"></i>
                      </a>
                    </div>
                  </div>
                </div>
                
                <!-- Status field -->
                <div class="col-12 col-sm-6 col-md-4 col-lg-3" id="statusDiv">
                  <label for="status" class="form-label">Status <span class="text-danger">*</span></label>
                  <select name="status" id="status" class="form-select form-select-sm">
                    <option value="1" selected>Active</option>
                    <option value="0">Inactive</option>
                  </select>
                </div>
              </div>
              
              <!-- Form buttons -->
              <div class="d-flex flex-wrap justify-content-end gap-2 mt-3">
                <button type="reset" class="btn btn-secondary btn-sm reset grp">
                  <i class="fa fa-refresh"></i> Reset
                </button>
                <button id="addDataFormBtn" class="btn btn-sm btn-success grp submit">
                  <span class="update-icon"><i class="fa fa-save"></i></span>
                  <span class="update-text"> Save</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
      <?php $this->load->view('templates/footer/footer'); ?>
</body>

</html>