<!DOCTYPE html>
<html lang="en">
<?php 
$this->load->view('templates/head')
?>
<body class="nav-md">
    <div class="container body">
        <div class="main_container">
            <?php
            $this->load->view('templates/navbarAndsidebar');
            ?>
            <div class="right_col" role="main">
                <div class=" ">
                    <div class="page-title">
                        <div class="clearfix"></div>
                        <div class="row">
                            <div class="col-md-12 col-sm-12 ">
                                <div class="x_panel">
                                    <ul class="nav nav-tabs" id="myTab" role="tablist">
                                        <li class="nav-item" role="presentation">
                                            <button class="nav-link active" id="home-tab" data-bs-toggle="tab" data-bs-target="#home-tab-pane" type="button" role="tab" aria-controls="home-tab-pane" aria-selected="true">All User</button>
                                        </li>
                                        <li class="nav-item" role="presentation">
                                            <button class="nav-link" id="profile-tab" data-bs-toggle="tab" data-bs-target="#profile-tab-pane" type="button" role="tab" aria-controls="profile-tab-pane" aria-selected="false">Add User</button>
                                        </li>
                                    </ul>
                                    <?php $this->load->view('templates/header/bootstrapToast'); ?>
                                    <div class="tab-content" id="myTabContent">
                                        <div class="tab-pane fade show active" id="home-tab-pane" role="tabpanel" aria-labelledby="home-tab" tabindex="0">
                                            <!-- The modal for image preview -->
<div class="modal fade" id="imagePreviewModal" tabindex="-1" role="dialog" aria-labelledby="imagePreviewModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="imagePreviewModalLabel">Image Preview</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body text-center">
        <img src="" class="img-fluid" alt="Preview Image">
      </div>
    </div>
  </div>
</div>
                                            <div class="user-form ">
                                                <div class="card shadow-sm mt-4">
                                                    <form id="searchForm" class="card-body search-form searchForm" method="POST">
                                                        <div class="row g-3">
                                                            <div class="col-12 col-sm-6 col-md-3 ">
                                                                <input type="text" name="searchname" id="u-master-name" class="form-control form-control-sm search-name" placeholder="Name" value="" maxlength="40" autocomplete="off">
                                                            </div>
                                                            <div class=" col-12 col-sm-6 col-md-3 search-btn d-flex justify-content-end align-items-center">
                                                                <div class="middle"><button id="search" type="submit" data-url="/controller/usermaster.php" class="btn btn-sm btn-success search grp"><i class="fa fa-search"></i> Search</button>
                                                                    <button id="reset" type="reset" class="btn btn-sm btn-secondary reset grp"><i class="fa fa-refresh"></i> Reset</button>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </form>
                                                </div>
                                                <?php   $this->load->view('templates/pagelimitAndPagination.php')  ?>
                                            </div>
                                            
                                        </div>
                                        <div class="tab-pane fade" id="profile-tab-pane" role="tabpanel" aria-labelledby="profile-tab" tabindex="0">
                                            <div class="user-form card shadow-sm mt-4">
                                                <form method="POST" id="addDataForm" enctype="multipart/form-data" name="itemMasterForm" class="form card-body">
                                                    <input type="hidden" name="id" id="fieldId" value="">
                                                    <input type="hidden" name='table' value="item_master">
                                                    <div class="row g-3">
                                                        <div class="col-12 col-sm-6 col-md-3">
                                                            <label for="name" class="form-label">Item Name <span class="text-danger">*</span></label>
                                                            <input type="text" name="item_name" id="item_name" class="form-control search-name form-control-sm" value="" minlength="3" maxlength="40" autocomplete="off" required>
                                                            <div class="text-danger err error-space" id="item_nameErr"></div>
                                                        </div>
                                                        <div class="col-12 col-sm-6 col-md-3">
                                                            <label for="description" class="form-label">Description <span class="text-danger">*</span></label>
                                                            <input type="text" name="description" id="description" class="form-control form-control-sm" value="" maxlength="150" autocomplete="off" required>
                                                            <span class="text-danger err error-space" id="descriptionErr"></span>
                                                        </div>
                                                        <div class="col-12 col-sm-6 col-md-3">
                                                            <label for="price" class="form-label">Price <span class="text-danger"> *</span></label>
                                                            <input type="text" name="price" id="price" class="form-control form-control-sm textAlignRight quantity salary" maxlength="10" value="" placeholder="0.00" autocomplete="off" required>
                                                            <span class="text-danger err error-space" id="priceErr"></span>
                                                        </div>
                                                        <div class="col-12 col-sm-6 col-md-3" id="statusDiv"><label for="status" class="form-label">Status<span class="text-danger"> *</span></label>
                                                            <select name="status" id="status" class="form-select form-select-sm">

                                                                <option value="1" selected>Active</option>
                                                                <option value="0">Inactive</option>
                                                            </select>
                                                        </div>

                                                        <div class="col-12 col-sm-6 col-md-3 mt-4 imageDiv" id="imageDiv">
                                                            <label for="image" class="form-label">Upload Image</label>
                                                            <input type="file" name="image" id="image" class="form-control form-control-sm image" accept="image/*" placeholder="Upload Image" value="">

                                                            <span id="loadImg" style="cursor: pointer; display: none; margin-top: 30px;">
                                                                <a id="removeImage" name="removeImage" style="cursor: pointer; margin-left: 10px;">
                                                                    <img src="<?php echo base_url(); ?>assets/img/delete1.png" alt="Delete" style="width: 20px; height: 20px; border-radius: 50%;">
                                                                </a>
                                                                <img id="preview" src="" alt="Previous Image" class="img-fluid" style="width: 80px; height: 80px; border-radius: 50%; display: block; margin-top: 5px;">
                                                            </span>
                                                        </div>

                                                    </div>
                                                    <div class='d-flex justify-content-end mt-3'>
                                                        <button id='addDataFormBtn' class="btn btn-sm btn-success grp submit"><span class="update-icon"><i class="fa fa-send"></i></span><span class="update-text"> Save</span></i></button>
                                                        <button type="reset" class="btn btn-secondary btn-sm reset grp"><i class="fa fa-refresh"> Reset</i></button>
                                                    </div>
                                            </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- jQuery -->
        <?php $this->load->view('templates/footer/footer'); ?>
</body>

</html>