<?php
defined('BASEPATH') or exit('No direct script access allowed');

class FormValidator
{

    protected $CI;

    public function __construct()
    {
        $this->CI = &get_instance();
        $this->CI->load->library('form_validation');
        $this->CI->load->helper('uniqueness_helper');
    }

    public function validateForm($post, $table_name)
    {
        try {
            $is_unique_email = "";
            $is_unique_phone = "";
            $is_unique_item = "";

            // Check uniqueness
            if (isset($table_name) && isset($post['email']) && isset($post['phone'])) {
                $is_unique_email = uniqueHelper('email', $table_name, $post['email'], 'id', $post['id']);
                $is_unique_phone = uniqueHelper('phone', $table_name, $post['phone'], 'id', $post['id']);
            }

            if (isset($table_name) && isset($post['item_name'])) {
                $is_unique_item = uniqueHelper('item_name', $table_name, $post['item_name'], 'id', $post['id']);
            }

            $fields = [
                ['field' => 'name', 'label' => 'Name', 'rules' => 'required|trim|min_length[3]|regex_match[/^[a-zA-Z ]+$/]'],
                [
                    'field' => 'email',
                    'label' => 'Email',
                    'rules' => 'required|trim|valid_emails' . $is_unique_email,
                    "errors" => [
                        'is_unique' => 'The %s is already exist.',
                    ],
                ],
                [
                    'field' => 'phone',
                    'label' => 'Phone number',
                    'rules' => 'required|trim|exact_length[10]|numeric' . $is_unique_phone,
                    "errors" => [
                        'is_unique' => 'The %s is already exist.',
                    ]
                ],
                ['field' => 'pincode', 'label' => 'Pincode', 'rules' => 'required|trim|max_length[6]|numeric'],
                ['field' => 'state', 'label' => 'State', 'rules' => 'required|trim|numeric'],
                ['field' => 'district', 'label' => 'District', 'rules' => 'required|trim|numeric'],
                ['field' => 'address', 'label' => 'Address', 'rules' => 'required|trim'],
                [
                    'field' => 'item_name',
                    'label' => 'Item name',
                    'rules' => 'required|trim|min_length[2]|regex_match[/^[a-zA-Z- ]+$/]' . $is_unique_item,
                    "errors" => [
                        'is_unique' => 'The %s is already exist.',
                    ]
                ],
                ['field' => 'description', 'label' => 'Description', 'rules' => 'required|trim|min_length[3]'],
                ['field' => 'price', 'label' => 'Price', 'rules' => 'required|trim|numeric'],
            ];

            // Filter only fields present in POST
            $fields_to_validate = array_filter($fields, function ($field) use ($post) {
                return array_key_exists($field['field'], $post);
            });

            $this->CI->form_validation->set_rules($fields_to_validate);

            if ($this->CI->form_validation->run() === FALSE) {
                return ['status' => false, 'errors' => $this->CI->form_validation->error_array()];
            }
            return ['status' => true];
        } catch (Exception $e) {
            return ['status' => false, 'errors' => $e->getMessage()];
        }
    }


    public function validateInvoiceForm($post, $table_name)
    {
        try {
            if (isset($table_name) && isset($post['invoice_no'])) {
                $is_unique_invoice_number = uniqueHelper('invoice_no', $table_name, $post['invoice_no'], 'id', $post['id']);
            }
            $fields = [
                [
                    'field' => 'invoice_no',
                    'label' => 'Invoice number',
                    'rules' => 'required|trim|numeric' . $is_unique_invoice_number,
                    "errors" => [
                        'is_unique' => 'The %s is already exist.',
                    ]
                ],
                ['field' => 'total_amount', 'label' => 'Total amount', 'rules' => 'required|trim|numeric'],
                ['field' => 'date', 'label' => 'Date', 'rules' => 'required|trim|numeric'],
                ['field' => 'client_name', 'label' => 'Client Name', 'rules' => 'required|trim|min_length[2]|regex_match[/^[a-zA-Z- ]+$/]']
            ];
            $fields_to_validate = array_filter($fields, function ($field) use ($post) {
                return array_key_exists($field['field'], $post);
            });
            $this->CI->form_validation->set_rules($fields_to_validate);
            if ($this->CI->form_validation->run() === FALSE) {
                return ['status' => false, 'errors' => $this->CI->form_validation->error_array()];
            }
            return ['status' => true];
        } catch (Exception $e) {
            return ['status' => false, 'errors' => $e->getMessage()];
        }
    }
}
