<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Response_msg {

    public function apiResponse($status, $message, $data = null, $code = 200) {

        $response = [
            'status' => $status,
            'message' => $message,
            'data' => $data,
            'code' => $code
        ];
        echo json_encode($response);
        exit;
        
    }


}