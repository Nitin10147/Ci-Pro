<?php

class PdfGenerator
{

    public function __construct()
    {
        $this->CI =& get_instance();
    }


    // pdf generate function using mpdf
    
    function numberToWords($number)
    {
        if (!is_numeric($number)) {
            return "Invalid number";
        }
        if ($number < 0) {
            return "minus " . $this->numberToWords(abs($number));
        }
        $parts = explode('.', $number);
        $integerPart = $parts[0];
        $decimalPart = isset($parts[1]) ? $parts[1] : '';
        $integerWords = $this->convertIntegerToWords($integerPart);
        $decimalWords = '';
        if (!empty($decimalPart) && $decimalPart > 0) {
            $decimalWords = ' point ' . $this->convertDecimalToWords($decimalPart);
        }
        return trim($integerWords . $decimalWords);
    }

    function convertIntegerToWords($number)
    {
        $units = array("", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine");
        $teens = array("ten", "eleven", "twelve", "thirteen", "fourteen", "fifteen", "sixteen", "seventeen", "eighteen", "nineteen");
        $tens = array("", "ten", "twenty", "thirty", "forty", "fifty", "sixty", "seventy", "eighty", "ninety");
        if ($number == 0) {
            return "zero";
        }
        $words = "";
        if ($number >= 10000000) {
            $crore = intval($number / 10000000);
            $words .= $this->convertIntegerToWords($crore) . " crore ";
            $number %= 10000000;
        }
        if ($number >= 100000) {
            $lakh = intval($number / 100000);
            $words .= $this->convertIntegerToWords($lakh) . " lakh ";
            $number %= 100000;
        }

        if ($number >= 1000) {
            $thousand = intval($number / 1000);
            $words .= $this->convertIntegerToWords($thousand) . " thousand ";
            $number %= 1000;
        }

        if ($number >= 100) {
            $hundred = intval($number / 100);
            $words .= $units[$hundred] . " hundred ";
            $number %= 100;
        }

        if ($number >= 20) {
            $words .= $tens[intval($number / 10)] . " ";
            $number %= 10;
        } elseif ($number >= 10) {
            $words .= $teens[$number - 10] . " ";
            $number = 0;
        }

        if ($number > 0) {
            $words .= $units[$number] . " ";
        }

        return trim($words);
    }

    function convertDecimalToWords($decimalPart)
    {
        $units = array("zero", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine");
        $words = "";
        for ($i = 0; $i < strlen($decimalPart); $i++) {
            $digit = $decimalPart[$i];
            if (is_numeric($digit)) {
                $words .= $units[intval($digit)] . " ";
            }
        }

        return trim($words);
    }
}

?>
