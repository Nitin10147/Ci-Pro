function capitalizeFirstLetter(str) {
	return str.charAt(0).toUpperCase() + str.slice(1);
}

function editTabChange() {
	let change = $("#profile-tab")[0];
	let tab = new bootstrap.Tab(change);
	tab.show();
	$(".User-text").text("Edit User");
	$(".Client-text").text("Edit Client");
	$(".Item-text").text("Edit Item");
	$(".Invoice-text").text("Edit Invoice");
	$(".update-text").text("Update");
	$(".update-icon").html('<i class="fa fa-pencil"></i> ');
}

function addTabChange() {
	$("#loadImg").hide();
	let change = $("#home-tab")[0];
	$("#addDataForm").trigger("reset");
	let tab = new bootstrap.Tab(change);
	tab.show();
	$(".update-icon").html('<i class="fa fa-send"></i> ');
	$(".update-text").text("Save");
	$("#update-password")
		.removeAttr("id")
		.attr("required", "required")
		.attr("id", "password");
	$("#addDataForm").trigger("reset");
	$(".User-text").text("Add User");
	$(".Client-text").text("Add Client");
	$(".Item-text").text("Add Item");
	$(".Invoice-text").text("Add Invoice");
}

$("#phone, #user-master-phone, #pincode,.number").on("input", function () {
	this.value = this.value.replace(/[^0-9]/g, "");
});

$(".search-name").on("input", function () {
	this.value = this.value.replace(/[^a-zA-Z ]/g, "");
});

function validateField(field) {
	const fieldName = $(field).attr("name");
	const fieldType = $(field).attr("type");
	const fieldRequired = $(field).attr("required");
	const fieldId = $(field).attr("id");
	const fieldValue = $(field).val().trim();
	const errorSpan = fieldName.split("[")[0] + "Err";
	// alert(errorSpan + " " + fieldId + " " + fieldName);

	// For Email Validation
	if (fieldType === "email") {
		if (fieldValue === "") {
			$("#" + errorSpan).html(
				`${capitalizeFirstLetter(fieldName)} is required`
			);
			return false;
		} else if (
			!/^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,8}$/.test(fieldValue)
		) {
			$("#" + errorSpan).html("Please enter a valid email address");
			return false;
		} else {
			$("#" + errorSpan).html("");
			return true;
		}
	}
	if (fieldName == "description") {
		if (!/[a-zA-Z0-9,\.\_]{3,40}$/.test(fieldValue)) {
			$("#" + errorSpan).html(
				`${
					capitalizeFirstLetter(fieldName).split("[")[0]
				} must be between 3 to 40 characters`
			);
			return false;
		} else {
			$("#" + errorSpan).html("");
			return true;
		}
	}
	// For Name Validation
	if (fieldName == "name" || fieldName == "item_name") {
		if (fieldValue === "") {
			$("#" + errorSpan).html(
				`${capitalizeFirstLetter(fieldName.split("[")[0])} is required`
			);
			return false;
		} else if (!/^[a-zA-Z\s]{3,40}$/.test(fieldValue)) {
			$("#" + errorSpan).html(
				`${
					capitalizeFirstLetter(fieldName).split("[")[0]
				} must be between 3 to 40 characters`
			);
			return false;
		} else {
			$("#" + errorSpan).html("");
			return true;
		}
	}
	// For Password Validation
	if (fieldId === "password") {
		if (fieldValue === "") {
			$("#" + errorSpan).text(
				`${capitalizeFirstLetter(fieldName)} is required`
			);
			return false;
		} else if (!/^.{6,}$/.test(fieldValue)) {
			$("#" + errorSpan).text(
				`${capitalizeFirstLetter(fieldName)} have minimum 6 characters.`
			);
			return false;
		} else if (!/(?=.*[A-Z])/.test(fieldValue)) {
			$("#" + errorSpan).text(
				`${capitalizeFirstLetter(fieldName)} Atleast one uppercase letter.`
			);
			return false;
		} else if (!/(?=.*\d)/.test(fieldValue)) {
			$("#" + errorSpan).text(`Password Atleast one digit`);
			return false;
		} else if (!/(?=.*[@#-^$!%*?&])/.test(fieldValue)) {
			$("#" + errorSpan).text(`Password have atleast one special character`);
			return false;
		} else {
			$("#" + errorSpan).text("");
			return true;
		}
	}

	// Update Password Validation
	if (fieldId === "update-password") {
		if (fieldValue === "") {
			$("#" + errorSpan).text("");
			return true;
		} else if (!/^.{6,}$/.test(fieldValue)) {
			$("#" + errorSpan).text(
				`${capitalizeFirstLetter(fieldName)} have minimum 6 characters.`
			);
			return false;
		} else if (!/(?=.*[A-Z])/.test(fieldValue)) {
			$("#" + errorSpan).text(
				`${capitalizeFirstLetter(fieldName)} Atleast one uppercase letter.`
			);
			return false;
		} else if (!/(?=.*\d)/.test(fieldValue)) {
			$("#" + errorSpan).text(`Password Atleast one digit`);
			return false;
		} else if (!/(?=.*[@$!%*?&])/.test(fieldValue)) {
			$("#" + errorSpan).text(`Password have atleast one special character`);
			return false;
		} else {
			$("#" + errorSpan).text("");
			return true;
		}
	}

	// For  Phone Number Validation
	if (fieldName === "phone") {
		if (fieldValue === "") {
			$("#" + errorSpan).html(
				`${capitalizeFirstLetter(fieldName)} is required`
			);
			return false;
		} else if (!/^\d{10}$/.test(fieldValue)) {
			$("#" + errorSpan).html(
				`${capitalizeFirstLetter(fieldName)} must be 10 digits`
			);
			return false;
		} else if (fieldValue === "0000000000") {
			$("#" + errorSpan).html(
				`${capitalizeFirstLetter(fieldName)} must be 10 digits`
			);
			return false;
		} else {
			$("#" + errorSpan).html("");
			return true;
		}
	}
	// For Pincode Validation

	if (fieldName === "pincode") {
		if (fieldValue === "") {
			$("#" + errorSpan).html(
				`${capitalizeFirstLetter(fieldName)} is required`
			);
			return false;
		} else if (!/^\d{6}$/.test(fieldValue)) {
			$("#" + errorSpan).html(
				`${capitalizeFirstLetter(fieldName)} must be 6 digits`
			);
			return false;
		} else {
			$("#" + errorSpan).html("");
			return true;
		}
	}

	// For Address Validation
	if (fieldName === "address") {
		if (fieldValue === "") {
			$("#" + errorSpan).html(
				`${capitalizeFirstLetter(fieldName)} is required`
			);
			return false;
		} else if (!/^.{3,}$/.test(fieldValue)) {
			$("#" + errorSpan).html(
				`${capitalizeFirstLetter(fieldName)} must be between 3 to 40 characters`
			);
			return false;
		} else {
			$("#" + errorSpan).html("");
			return true;
		}
	}

	// For Required Fields validation
	if (fieldRequired && fieldValue === "") {
		$("#" + errorSpan).html(
			`${capitalizeFirstLetter(fieldName.split("[")[0])} is required`
		);
		return false;
	} else {
		$("#" + errorSpan).html("");
		return true;
	}
}

$("input").on("change paste keyup ", function () {
	validateField(this);
});

/// function for making url

function urlMaker() {
	const baseURL = window.location.href;
	return baseURL.split("?")[0];
}

$("#addDataFormBtn").on("click", function (e) {
	e.preventDefault();
	const form = document.getElementById("addDataForm");
	const url = urlMaker();
	const formData = new FormData(form);
	var actionType = $("#fieldId").val() ? "update" : "add";
	formData.append("type", actionType);
	// CONSOLE ALL KEY AND VALUE
	let isValid = true;
	$(form)
		.find("input")
		.each(function () {
			if (!validateField(this)) {
				isValid = false;
			}
		});
	if (isValid) {
		AllFormSubmit(formData, url);
	}
});

function AllFormSubmit(formData, url) {
	$.ajax({
		url: url + "/addUpdate",
		type: "POST",
		data: formData,
		processData: false,
		contentType: false,
		dataType: "json",
		success: function (response) {
			if (response.status) {
				addTabChange();
				$("#search").trigger("click");
				const toastMessage = $("#toastMessage");
				$(toastMessage).text(response.message);
				const successToast = new bootstrap.Toast(
					document.getElementById("successToast"),
					{
						delay: 3000,
					}
				);
				successToast.show();
			} else if (response.duplication_error == true) {
				let errorMessage = "";
				if (response.errors.email) {
					errorMessage += response.errors.email + "\n";
				}
				if (response.errors.phone) {
					errorMessage += response.errors.phone + "\n";
				}
				if (response.errors.item_name) {
					errorMessage += response.errors.item_name + "\n";
				}if (response.errors.invoice_no) {
					errorMessage += response.errors.invoice_no + "\n";
					
				}
				swal.fire({
					title: "Error!",
					text: errorMessage,
					icon: "error",
					confirmButtonText: "Ok",
				});
			} else {
				swal.fire({
					title: "Error!",
					text: response.message,
					icon: "error",
					confirmButtonText: "Ok",
				});
			}
		},
	});
}

/// URL MAKER for pagination

function reloadTable() {
	const page_limit = $("#page_limit").val();
	const url = urlMaker();
	const page_no = $(".active-pagination").attr("id") ?? 1;
	loadMasters(page_no, page_limit, url);
}

$(document).on("click", ".pagination_link", function () {
	var page_no = $(this).attr("id");
	var page_limit = $("#page_limit").val();
	const url = urlMaker();
	loadMasters(page_no, page_limit, url);
});

$(document).on("change", ".page_limit", function (e) {
	const url = urlMaker();
	var page_limit = $(this).val();
	loadMasters(1, page_limit, url);
});

$(document).on("click", ".column_sort", function (e) {
	e.preventDefault();
	const column = $(this).attr("data-column") ?? "id";
	const order = $(this).attr("data-order") ?? "desc";
	const url = urlMaker();
	const page_limit = $("#page_limit").val();
	const page_no = $(".active-pagination").attr("id") ?? 1;
	loadMasters(page_no, page_limit, url, column, order);
});
$("#search").on("click", function (e) {
	e.preventDefault();
	let form = $("#searchForm")[0];
	const page_limit = $("#page_limit").val();
	const url = urlMaker();
	if (form) {
		let formData = new FormData(form);
		formData.append("page_limit", page_limit);
		loadMasters(1, page_limit, url, undefined, undefined, formData);
	} else {
		console.error("Form element not found!");
	}
});

function loadMasters(
	page,
	page_limit,
	url,
	column = "id",
	order = "desc",
	formData = null
) {
	if (!formData) {
		formData = new FormData($("#searchForm")[0]);
	}
	formData.append("page", page);
	formData.append("page_limit", page_limit);
	formData.append("column", column);
	formData.append("order", order);
	$.ajax({
		url: url + "/fetch",
		method: "POST",
		data: formData,
		processData: false,
		contentType: false,
		dataType: "json",
		success: function (data) {
			if (data.error) {
				swal.fire({
					title: "Error!",
					text: data.message,
					icon: "error",
					confirmButtonText: "Ok",
				});
			}
			$("#tableList").html(data.data);
			$(".dynamicPagination").html(data.pagination);
			$("#totalRecord").html(data.total_records);
			$("#totalPage").html(data.total_pages);
		},
	});
}

$(document).ready(function () {
	reloadTable();
});

$(".reset").on("click", function (e) {
	$(".err").html("");
	$("input").val("");
	reloadTable();
});

// Delete Master

function deleteAllMasterData(id, submitUrl) {
	$.ajax({
		url: submitUrl,
		type: "POST",
		data: { type: "DELETE", id: id },
		dataType: "json",
		success: function (response) {
			// console.log(response);
			if (response.same_user === "failed") {
				Swal.fire({
					title: "Error!",
					text: "You can't delete yourself",
					icon: "error",
					confirmButtonText: "Ok",
				});
			} else if (response.status === "success") {
				Swal.fire({
					title: "Success!",
					text: `Data deleted successfully`,
					icon: "success",
					confirmButtonText: "Ok",
				});
			} else if (response.status === "fail") {
				Swal.fire({
					title: "Error!",
					text: "You can't delete this data",
					icon: "error",
					confirmButtonText: "Ok",
				});
			} else if (response.error) {
				Swal.fire({
					title: "Error!",
					text: response.message,
					icon: "error",
					confirmButtonText: "Ok",
				});
			}
			reloadTable();
		},
	});
}

$(document).on("click", ".delete", function () {
	const deleteid = $(this).attr("delete_id");
	// alert(deleteid);
	const url = urlMaker();

	const swalWithBootstrapButtons = Swal.mixin({
		customClass: {
			confirmButton: "btn btn-success",
			cancelButton: "btn btn-danger",
		},
		buttonsStyling: false,
	});
	swalWithBootstrapButtons
		.fire({
			title: "Are you sure?",
			text: "You won't be able to revert this!",
			icon: "warning",
			showCancelButton: true,
			confirmButtonText: "Yes, delete it!",
			cancelButtonText: "No, cancel!",
			reverseButtons: true,
		})
		.then((result) => {
			if (result.isConfirmed) {
				$.ajax({
					url: url + "/delete",
					type: "POST",
					data: { delete_id: deleteid },
					dataType: "json",
					success: function (data) {
						if (data.status) {
							swalWithBootstrapButtons.fire({
								title: "Deleted!",
								text: data.message,
								icon: "success",
							});
							$("#search").trigger("click");
						} else {
							swalWithBootstrapButtons.fire({
								title: "Cancelled",
								text: "You cannot delete!",
								icon: "error",
							});
						}
					},
					error: function () {
						swalWithBootstrapButtons.fire({
							title: "Cancelled",
							text: "You cannot delete!",
							icon: "error",
						});
					},
				});
			} else if (result.dismiss === Swal.DismissReason.cancel) {
				swalWithBootstrapButtons.fire({
					title: "Cancelled",
					text: "Your data is safe :)",
					icon: "error",
				});
			}
		});
});

$(document).on("click", "#home-tab", function () {
	addTabChange();
});

$(document).on("click", ".edit", function () {
	$("#password").removeAttr("required").removeAttr("id");
	$(".update-password").attr("id", "update-password");
});

$(document).on("click", ".edit", function () {
	const editid = $(this).attr("edit_id");
	const url = urlMaker();
	editTabChange();
	$.ajax({
		url: url + "/edit",
		type: "POST",
		data: { edit_id: editid },
		dataType: "json",
		success: function (response) {
			if (response.error) {
				Swal.fire({
					title: "Error!",
					text: response.message,
					icon: "error",
					confirmButtonText: "Ok",
				});
			}
			if (response.table === "invoice_master") {
				let data = response["data"];
        console.log(data);
				$("#fieldId").val(data.id);
				$("#invoice_date").val(data.invoice_date);
        $("#client_Id").val(data.client_id);
        console.log(data.client_id);
				$("#invoice_no").val(data.invoice_no);
				$("#clientNameId").val(data.client_name);
				$("#clientEmailId").val(data.client_email);
				$("#clientPhoneId").val(data.client_phone);
				$("#totalAmount").val(data.total_amount);
				const items = data.items;
                $('.itemTable tr:not(:first)').remove();
                for (let i = 0; i < items.length; i++) {
                    
                    const row = $(".tableClone").last();
                    row.find(".itemNameAddId").val(items[i].itemname);
                    row.find(".quantityAddId").val(items[i].quantity);
                    row.find(".itemPriceAddId").val(items[i].price);
                    row.find(".itemAmountAddId").val(items[i].total_price);
                    row.find(".item_id").val(items[i].item_id);
                    $("#addRow").trigger("click");
                }
                $(".tableClone").last().find(".deleteRow").trigger("click");

			} else {
				var data = response[0];
				$("#status")
					.find("option[value=" + data["status"] + "]")
					.attr("selected", "selected");
				try {
					for (var key in data) {
						console.log(key);
						if (key === "state") {
							$("#state").val(data[key]);
							$("#state").trigger("change");
						} else if (key === "city") {
							setTimeout(() => {
								$("#city")
									.find("option[value=" + data["city"] + "]")
									.attr("selected", "selected");
							}, 100);
						} else if (key === "image") {
							if (data[key] === "" || data[key] === null) {
								$("#").hide();
							}
							$("#loadImg").show();
							let filePath =
								"http://localhost/CodeIgniter/uploads/user/" + data[key];
							$("#preview").attr("src", filePath);
							console.log(data[key]);
						} else if (data.hasOwnProperty(key)) {
							$("input[name='" + key + "']").val(data[key]);
						}
					}
				} catch (e) {
					console.log("Error in autofill", e);
					return;
				}
			}
		},
	});
});



// Perview Image item master

    $("#image").change(function() {
                $("#loadImg").show();
                const fileName = URL.createObjectURL(this.files[0]);
                $("#preview").attr("src", fileName);
            });
            $("#removeImage").on("click", function() {
                $("#loadImg").hide();
                $("#preview").attr("src", "");
                $(".image").val("");
            });

            $(document).on("click", ".item_image", function() {
  var imgSrc = $(this).attr('src');
  $("#imagePreviewModal .modal-body img").attr("src", imgSrc);
  $("#imagePreviewModal").modal('show');
});


  $(".close, .modal").on("click", function () {
        $("#imagePreviewModal").modal("hide");
    });