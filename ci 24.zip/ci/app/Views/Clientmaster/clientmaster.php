<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>Dashboard - SB Admin</title>
    <?= link_tag(base_url('assets/Lib/bootstrap-5.0.2-dist/css/bootstrap.css')); ?>
    <?= link_tag(base_url('assets/css/style.css')); ?>
    <?= script_tag(base_url('assets/js/jquery.js')); ?>
    <?= link_tag(base_url('assets/css/form.css')); ?>
    <script src="https://use.fontawesome.com/releases/v6.3.0/js/all.js" crossorigin="anonymous"></script>
</head>

<body class="sb-nav-fixed">

    <?= view('SideBar.Navbar/navbar') ?>
    <div id="layoutSidenav">
        <?= view('SideBar.Navbar/sidebar') ?>
        <div id="layoutSidenav_content">
            <main>

                <ul class="nav nav-tabs" id="myTab" role="tablist">
                    <li class="nav-item" role="presentation">
                        <button class="nav-link active" id="home-tab" data-bs-toggle="tab"
                            data-bs-target="#home-tab-pane" type="button" role="tab" aria-controls="home-tab-pane"
                            aria-selected="true">All Client</button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="profile-tab" data-bs-toggle="tab"
                            data-bs-target="#profile-tab-pane" type="button" role="tab" aria-controls="profile-tab-pane"
                            aria-selected="false">Add Clients</button>
                    </li>
                </ul>


                <div class="tab-content" id="myTabContent">
                    <div class="tab-pane fade show active" id="home-tab-pane" role="tabpanel" aria-labelledby="home-tab"
                        tabindex="0">
                        <div class="container mt-1">


                            <button class="btn " type="button" id="togglerButton">
                                ▼ &nbsp Search Form
                            </button>

                            <!-- Collapsible Container (Search Form) -->
                            <div id="searchBarContainer" class="collapse">
                                <form action="">
                                    <input type="text" id="Namesearch" class="form-control search" placeholder=" Name ">
                                    <input type="text" id="Emailsearch" class="form-control search" placeholder="Email">
                                    <input type="text" id="Phonesearch" class="form-control search"
                                        placeholder="Phone Number">
                                    <button type="button" id="searchButton" class="btn btn-primary button-90 "
                                        id="submit" style="margin-right: 10px">Search</button></span>
                                    <button type="reset" class="btn btn-secondary button-80"
                                        onclick="loadTable(table, columns, 1, '', '', 'asc', 5, '#client-table-container');">Reset</button>

                                </form>
                            </div>


                            <div class="d-flex flex-row  flex-row-reverse">
                                <select id="page_limit"
                                    style="width: 55px; margin-top: 20px; margin-right: 20px; display: inline-block">
                                    <option value="5" selected>5</option>
                                    <option value="10">10</option>
                                    <option value="15">15</option>
                                    <option value="20">20</option>
                                    <option value="25">25</option>
                                    <option value="30">30</option>
                                </select>
                            </div>


                            <div id="client-table-container">
                            </div>
                        </div>

                    </div>
                    <div class="tab-pane fade" id="profile-tab-pane" role="tabpanel" aria-labelledby="profile-tab"
                        tabindex="0">


                        <form class="row g-4 m-3" id="clientmaster" method="POST">
                            <div class="col-md-3">
                                <label for="fname" class="form-label">First Name</label>
                                <input type="text" name='fName' class="form-control" id="fname"
                                    placeholder="Enter your first name" maxlength="20" autofocus>
                                <span id='fname-error' class="error empty-space"></span>

                            </div>
                            <div class="col-md-3">
                                <label for="lname" class="form-label">Last Name</label>
                                <input type="text" name='lName' class="form-control" id="lname"
                                    placeholder="Enter your last name" maxlength="20">
                                <span id='lname-error' class="error empty-space"></span>
                            </div>
                            <div class="col-md-3">
                                <label for="inputEmail4" class="form-label">Email</label>
                                <input type="email" name="email" class="form-control" id="inputEmail4"
                                    placeholder="Enter your email" maxlength="30">
                                <span id='email-error' class="error empty-space"></span>
                            </div>
                            <div class="col-md-3">
                                <label for="phone" class="form-label">Phone</label>
                                <input type="text" name="phone" class="form-control" id="phone"
                                    placeholder="Enter your phone number" maxlength="10">
                                <span id='phone-error' class="error empty-space"></span>
                            </div>
                            <div class="col-md-3">
                                <label for="inputAddress" class="form-label">Address</label>
                                <input type="text" name="address" class="form-control" id="inputAddress"
                                    placeholder="Enter your address" maxlength="50">
                                <span id='address-error' class="error empty-space"></span>
                            </div>
                            <div class="col-md-3">
                                <label for="inputState" class="form-label">State</label>
                                <select id="inputState" name="state" class="form-select ">

                                    <option selected>Choose...</option>


                                </select>
                            </div>

                            <!-- City Select -->
                            <div class="col-md-3" id="city-container" style=>
                                <label for="inputCity" class="form-label">City</label>
                                <select id="inputCity" name="city" class="form-select">
                                    <option name="city" selected>Choose...</option>
                                </select>
                            </div>

                            <div class="col-md-3">
                                <label for="inputZip" class="form-label">Zip</label>
                                <input type="text" name="zip" class="form-control" id="inputZip"
                                    placeholder="Enter your zip code" maxlength="6">
                                <span id='zip-error' class="error empty-space"></span>
                            </div>
                            <div class="col-12 text-end">
                                <span class='usubmit'><button type="submit" class="btn btn-primary button-90 "
                                        id="submit">Submit</button></span>
                                <button type="reset" class="btn btn-secondary button-80 reset">Reset</button>
                            </div>
                        </form>
                    </div>
                </div>

            </main>


        </div>
    </div>
    <?= script_tag(base_url('assets/Lib/bootstrap-5.0.2-dist/js/bootstrap.bundle.js')); ?>
    <?= script_tag(base_url('assets/js/Dashboard.js')); ?>

</body>

</html>