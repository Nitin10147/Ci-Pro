<?php

helper('filesystem'); 

function upload_file($file)
{
    $uploadPath =  $uploadPath = FCPATH . 'public/uploads/images/';
    $maxSize = 1024 * 1024;
    $allowedTypes = ['image/png', 'image/jpg', 'image/jpeg'];

    if (!in_array($file->getMimeType(), $allowedTypes)) {
        return [ 'status' => false ,'error' => 'Invalid file type'];
    }

    if ($file->getSize() > $maxSize) {
        return ['status' => false , 'error' => 'File is too large. Max size allowed is 1MB.'];
    }

    $newName = $file->getRandomName();

    if (!is_dir($uploadPath)) {
        mkdir($uploadPath, 0777, true); 
    }

    if ($file->move($uploadPath, $newName)) {
        return [ 'status' => true ,'filename' => $newName];
    } else {
        return [ 'status' => false ,'error' => $file->getErrorString()];
    }
}

?>
