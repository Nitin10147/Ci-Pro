<?php 

function checkExistence($table, $where, $value) {
    $db = \Config\Database::connect();
    $builder = $db->table($table);
    $builder->where($where, $value);
    // echo $builder->getCompiledSelect();  
    $query = $builder->get();
    return $query->getNumRows();  
}




?>