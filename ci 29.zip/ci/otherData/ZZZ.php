<?php

namespace App\Controllers;

use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponseInterface;
use Psr\Log\LoggerInterface;
use CodeIgniter\Filters\FilterInterface;
// use App\Libraries\Fx;


class City extends BaseController
{

    protected $CityModel=NULL;
	protected $TemplateModel=NULL;
	protected $request;
	protected $session;
	protected $validation;
	// protected $fx;

    public function __construct() {
		$this->CityModel 	= model('App\Models\CityModel', false);
		$this->session		= \Config\Services::session(); 
		$this->validation   = \Config\Services::validation();
		helper('global_helper');
	}


    public function initController(
		RequestInterface $request,
        ResponseInterface $response,
        LoggerInterface $logger
		) {
			parent::initController($request, $response, $logger);
			// $this->request = $request;
			// $this->fx = new Fx();
			
    }

    public function index()
    {
        return view('city/index');
    }

    public function getList()
	{
		$pageNo		= $this->request->getPost('pageNo');
		$recToShow	= $this->request->getPost('recToShow');
		// print_r($pageNo);die;
		$searchdata = $this->request->getPost('search');
		if(!empty($searchdata)) {
			$where = whereString($searchdata,array('*'=>'t1.'),array('city_name'=>'LIKE'));
		} else {
			$where = "1=1";
		}
		

		
	
		$sortString = NULL;
		if ($this->request->getPost('order_by') != '' && $this->request->getPost('sort_by') != '')
			$sortString = $this->request->getPost('order_by') . ' ' . $this->request->getPost('sort_by');
		$dataList	= $this->CityModel->dataList($where, $pageNo, $recToShow, $sortString);
		if($this->userRight->perm->view) {
			$htmlDataListStyle = array(
				'City_id'		=> array(
					'linkString'	=> array(
						'tagVal'	=> "<span style='cursor:pointer' class='text-primary link-str' onclick=\"getEditRec('##city_id##');\">",
						'replaceColumn' => array('city_id'),'endString'=>'</span>'
					)
				),
				'city_name'	=> array(
					'linkString'	=> array(
						'tagVal' => "<span style='cursor:pointer' class='text-primary link-str' onclick=\"getEditRec('##city_id##');\">",
						'replaceColumn' => array('city_id'),
						'endString'=>'</span>'
					)
				)
			);
		}
		$columns = array(
			array('align'=>'left', 'name'=>'city_id'),
			array('align'=>'left', 'name'=>'city_name'),
			array('align'=>'left', 'name'=>'status'),
		);
	
		tableList($dataList->data,$dataList->count,$recToShow,$pageNo,$columns,'city_id',$this->userRight->perm->edit,$this->userRight->perm->delete,$htmlDataListStyle);
	}

    public function addRec(){
		
		if($this->userRight->perm->add!=1)
		{ 
			echo json_encode(array('statuscode' => 401, 'message' => 'access denied!')); return;
		}
		$this->validation->setRules([
			'city_name' => ['required'],
			'status' => ['required']
		]);

		if(!$this->validation->withRequest($this->request)->run($this->request->getPost())){
			echo json_encode(array('statuscode' => 400,'message'=>$this->validation->getErrors()));
		}else{
			$db = $this->CityModel->addData($this->request->getPost());
			if($db==1) {
				echo json_encode(array('statuscode'=>200, 'message'=>'Record added sucessfully.'));
			} elseif($db==0) {
				echo json_encode(array('statuscode'=>422,'message'=>'Details already exist.'));
			} 
			else {
				echo json_encode(array('statuscode'=>404));
			}
		}
    }

	public function getEditRec(){
		$id = $this->request->getPost("id");
		// print_r($this->MenuModel->getData($id));die;
		echo json_encode($this->CityModel->getData($id));
	}
    

	public function deleteRec(){
		
		if($this->userRight->perm->delete!=1)
		{ 
			echo json_encode(array('statuscode' => 401, 'message' => 'access denied!')); return;
		}
		$id		= $this->request->getPost("deleteId");
		$delRes	= $this->CityModel->deleteData($id);
		if($delRes['error']) {
			echo json_encode(array('statuscode'=>400,'error'=>$delRes['message']));
		} else {
			echo json_encode(array('statuscode'=>200,'error'=>$delRes['message']));
		}
	}


	public function editRec(){
		
		if($this->userRight->perm->edit!=1)
		{ 
			echo json_encode(array('statuscode' => 401, 'message' => 'access denied!')); return;
		}
		$id		= $this->request->getPost("editId");
		$data	= $this->request->getPost();
		// print_r($data);die;
		unset($data['editId']);

		$this->validation->setRules([
			'city_name' => ['required'],
			'status' => ['required'],
		]);

		if(!$this->validation->withRequest($this->request)->run($this->request->getPost())){
			echo json_encode(array('statuscode' => 400,'message'=>$this->validation->getErrors()));
		}else{
				$db = $this->CityModel->updateData($data, $id);
				if ($db == 1) {
					echo json_encode(array('statuscode' => 200));
				} elseif ($db == 0) {
					echo json_encode(array('statuscode' => 422));
				} else {
					echo json_encode(array('statuscode' => 404));
				}
			}
		} 

}
