<nav class="sb-topnav navbar navbar-expand">
    <?php $session = \Config\Services::session(); ?>
    <a class="navbar-brand ps-3" href="<?= base_url('dashboard') ?>"><img src="<?= base_url('assets/images/logo.png'); ?>" alt="Logo"></a>
    <button class="btn btn-link order-1 order-lg-0 me-4 me-lg-0 m-4" id="sidebarToggle" href="#!"><i class="fas fa-bars"></i></button>

    <ul class="navbar-nav d-none d-md-inline-block ms-auto me-0 me-md-3 my-2 my-md-0">
        <li class="nav-item dropdown">
            <a class=" " id="navbarDropdown" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                <img src="<?= base_url('public/uploads/images/' . $session->get('profile_pic')); ?>" class="avatar img-fluid" alt="User Avatar">
            </a>

            <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                <li class="dropdown-item" id="profile" href="#"><i class="fa-solid fa-circle-user"></i> Profile</li>
                <li><hr class="dropdown-divider" /></li>
                <li class="logoutAll dropdown-item"><i class="fa-solid fa-right-from-bracket"></i> Logout</li>
            </ul>
        </li>
    </ul>
</nav>

<script>
    $('#profile').on('click', function () {
        var userId = '<?= $session->get('user_id'); ?>';
        var username = '<?= $session->get('username'); ?>';
        var email = '<?= $session->get('email'); ?>';
        var profileImage = '<?= base_url('public/uploads/images/' . $session->get('profile_pic')); ?>';

        Swal.fire({
            title: 'Profile',
            html: `
                <div class="profile-modal">
                    <div class="profile-image-container">
                        <img src="${profileImage}" alt="Profile Image" class="profile-image" />
                    </div>
                    <div class="profile-info">
                        <h4 class="profile-username">${username}</h4>
                        <p class="profile-details"><strong>User ID:</strong> ${userId}</p>
                        <p class="profile-details"><strong>Email:</strong> ${email}</p>
                    </div>
                </div>
            `,
            showCloseButton: true,
            confirmButtonDisabled: true,
            width: 400,
            customClass: {
                popup: 'profile-popup'
            }
        });
    });
</script>



<style>

.profile-popup {
    padding: 20px;
    text-align: center;
}

.profile-modal {
    display: flex;
    flex-direction: column;
    align-items: center;
    font-family: Arial, sans-serif;
    color: #333;
}

.profile-image-container {
    margin-bottom: 15px;
}

.profile-image {
    width: 100px;
    height: 100px;
    border-radius: 50%;
    object-fit: cover;
    border: 3px solid #4CAF50;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1); 
}

.profile-info {
    margin-top: 10px;
}

.profile-username {
    font-size: 1.25rem;
    font-weight: 600;
    color: #2c3e50; 
}

.profile-details {
    font-size: 1rem;
    color: #7f8c8d; /* Lighter text color */
    margin: 5px 0;
}

.profile-details strong {
    color: #34495e; /* Darker color for labels */
}

/* Close button customization */
.swal2-close {
    color: #4CAF50; /* Green close button */
    font-size: 18px;
    font-weight: bold;
}


.navbar {
        background-repeat: no-repeat;
        background-size: cover;
    }

    #sidebarToggle {
        color: white;
        background-color: #0063f7;
        padding: 3px 9px;
        border-radius: 7px;
        box-shadow: rgba(17, 17, 26, 0.1) 0px 0px 16px;
    }

    .dropdown-menu svg {
        font-size: 17px;
        margin-right: 15px;
    }

    .avatar {
        border-radius: 100%;
    }
</style>