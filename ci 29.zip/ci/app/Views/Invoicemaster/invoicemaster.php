<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>Dashboard - SB Admin</title>
    <?= link_tag(base_url('assets/Lib/bootstrap-5.0.2-dist/css/bootstrap.css')); ?>
    <?= link_tag(base_url('assets/css/style.css')); ?>
    <?= script_tag(base_url('assets/js/jquery.js')); ?>
    <?= link_tag(base_url('assets/css/form.css')); ?>
    <script src="https://use.fontawesome.com/releases/v6.3.0/js/all.js" crossorigin="anonymous"></script>
    <script src="https://code.jquery.com/ui/1.14.1/jquery-ui.min.js"></script>
    <link rel="stylesheet" href="https://code.jquery.com/ui/1.14.1/themes/base/jquery-ui.css">
</head>

<body class="sb-nav-fixed">

    <?= view('SideBar.Navbar/navbar') ?>
    <div id="layoutSidenav">
        <?= view('SideBar.Navbar/sidebar') ?>
        <div id="layoutSidenav_content">
            <main>
                <!-- ================================================================================================== -->
                <!-- Modal -->
                <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel"
                    aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel">Send Email</h5>
                            </div>
                            <div class="modal-body">
                                <form id="sendMailForm">
                                    <div class="form-group">
                                        <label for="first-name">Name</label>
                                        <input type="text" class="form-control" id="first-name" readonly>
                                    </div>
                                    <div class="form-group">
                                        <label for="email">Email</label>
                                        <input type="email" class="form-control" id="email">
                                    </div>
                                    <div class="form-group">
                                        <label for="message">Message</label>
                                        <textarea class="form-control" id="message" rows="4"></textarea>
                                    </div>
                                </form>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                <button type="button" class="btn btn-primary" id="send-btn">Send</button>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- ========================================================================================================== -->


                <ul class="nav nav-tabs" id="myTab" role="tablist">
                    <li class="nav-item" role="presentation">
                        <button class="nav-link active" id="home-tab" data-bs-toggle="tab"
                            data-bs-target="#home-tab-pane" type="button" role="tab" aria-controls="home-tab-pane"
                            aria-selected="true">All Invoice</button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="profile-tab" data-bs-toggle="tab"
                            data-bs-target="#profile-tab-pane" type="button" role="tab" aria-controls="profile-tab-pane"
                            aria-selected="false">Add Invoice</button>
                    </li>
                </ul>

                <div class="tab-content" id="myTabContent">
                    <div class="tab-pane fade show active" id="home-tab-pane" role="tabpanel" aria-labelledby="home-tab"
                        tabindex="0">
                        <!-- Table for Profile Tab -->

                        <button class="btn " type="button" id="togglerButton">
                            ▼ &nbsp Search Form
                        </button>


                        <div id="searchBarContainer" class="collapse">
                            <?php
                            $data = [
                                ['name' => 'search_invoice_no', 'label' => 'Invoice Number', 'placeholder' => 'Enter Invoice Number', 'type' => 'text'],
                                ['name' => 'search_name', 'label' => 'Client_Name', 'placeholder' => 'Enter Client Name', 'type' => 'text'],
                                ['name' => 'search_email', 'label' => 'Email', 'placeholder' => 'Enter email', 'type' => 'text', 'class' => 'searchEmailField'],
                                ['name' => 'search_phone', 'label' => 'Mobile Number', 'placeholder' => 'Enter Mobile Number', 'type' => 'text'],
                                ['name' => 'date_from', 'label' => 'Invoice Date From','type' => 'date'],
                                ['name' => 'date_to', 'label' => 'Invoice Date To','type' => 'date'],

                            ];
                            generateSearchFields($data);
                            ?>
                        </div>
                        <div class="d-flex justify-content-between align-items-center">
                            <!-- Left Side: Search and Message -->
                            <div class="d-flex align-items-center">
                                <select id="page_limit" class="p-2 page_limit">
                                    <option value="5" selected>5</option>
                                    <option value="10">10</option>
                                    <option value="15">15</option>
                                    <option value="20">20</option>
                                    <option value="25">25</option>
                                    <option value="30">30</option>
                                </select>

                                <!-- <div id="mess" class="ms-2">
                                    <img src="<?= base_url('assets/images/mess.gif'); ?>" alt="" srcset=""
                                        style="width: 80px">
                                </div> -->

                                <div class="mess-container">
                                    <div class="record-box">
                                        Total Records: <span id="totalRecord" class="records"></span>
                                    </div>
                                    <div class="record-box">
                                        Total Pages: <span id="totalPage" class="records"></span>
                                    </div>
                                </div>

                            </div>

                            <div id="containerPage" class="d-flex align-items-center"></div>
                        </div>


                        <div id="tableDiv" class="table-responsive card-body"></div>


                    </div>

                    <div class="tab-pane fade" id="profile-tab-pane" role="tabpanel" aria-labelledby="profile-tab"
                        tabindex="0">
                        <!-- ====================================================================== -->
                        <!-- Form for Home Tab -->
                        <form method="POST" id="invoiceMasterForm" enctype="multipart/form-data"
                            name="invoiceMasterForm" class="form">
                            <input type="hidden" name="id" id="invoiceId" value="">
                            <input type="hidden" name="client_id" id="client_id" value="">

                            <div class="card pb-3">
                                <div class="card-body">
                                    <div class="row g-3">
                                        <div class="col-12 col-sm-6 col-md-3 ">
                                            <label for="invoice_no" class="form-label">Invoice No. <span
                                                    class="text-danger">*</span></label>
                                            <input type="number" name="invoice_no" id="invoice_no"
                                                class="form-control form-control-sm invoice_no" placeholder="Name"
                                                value="" maxlength="40" autocomplete="off" required>
                                        </div>
                                        <div class="col-12 col-sm-6 col-md-3">
                                            <label for="invoice_date" class="form-label">Invoice Date <span
                                                    class="text-danger">*</span></label>
                                            <input type="date" name="invoice_date" id="invoice_date"
                                                class="form-control form-control-sm" value="" maxlength="24"
                                                autocomplete="off" required>
                                        </div>
                                        <div class="col-12 col-sm-6 col-md-3">
                                            <label for="name" class="form-label">Client Name <span
                                                    class="text-danger">*</span></label>
                                            <input type="text" name="name" id="name"
                                                class="search-name form-control form-control-sm" value="" minlength="3"
                                                maxlength="40" autocomplete="off" required>
                                            <div id="client-name" class='client-name'></div>
                                        </div>
                                        <div class="col-12 col-sm-6 col-md-3">
                                            <label for="phone" class="form-label">Phone<span
                                                    class="text-danger">*</span></label>
                                            <input type="text" name="phone" id="phone"
                                                class="form-control form-control-sm" value="" maxlength="10" readonly
                                                autocomplete="off" required>
                                        </div>
                                        <div class="col-12 col-sm-6 col-md-3">
                                            <label for="email" class="form-label">Email<span
                                                    class="text-danger">*</span></label>
                                            <input type="text" name="email" id="invoice_email"
                                                class="form-control form-control-sm" value="" maxlength="70" readonly
                                                required>
                                        </div>
                                    </div>
                                </div>
                                <div class="">
                                    <div class="">
                                        <div class="card cardDiv overflow-auto mt-3">
                                            <div class="card-body">
                                                <div id="item-container" class="">
                                                    <div class="row g-3 mt-1 item-row" id="item-row">
                                                        <div class="col-10 col-sm-6 col-md-2">
                                                            <label class="form-label"></label>
                                                            <input type="text" name="itemname[]" id="itemname"
                                                                class="form-control form-control-sm search-name itemname"
                                                                placeholder="Enter Item Name" maxlength="24"
                                                                autocomplete="off" required>
                                                            <div id="item-name" class='item-name'></div>
                                                        </div>
                                                        <input type="hidden" name="item_id[]" id="item_id" value="">
                                                        <div class="col-10 col-sm-6 col-md-2">
                                                            <label class="form-label"></label>
                                                            <input type="text" name="price[]" id="price"
                                                                class="form-control form-control-sm textAlignRight salary price"
                                                                placeholder="Enter Item Price" maxlength="24"
                                                                autocomplete="off" readonly required>
                                                        </div>
                                                        <div class="col-10 col-sm-6 col-md-2">
                                                            <label class="form-label"></label>
                                                            <input type="text" name="quantity[]" id="quantity"
                                                                class="form-control form-control-sm number textAlignRight quantity"
                                                                placeholder="Enter Item Quantity" maxlength="7"
                                                                autocomplete="off" required>
                                                        </div>
                                                        <div class="col-10 col-sm-6 col-md-3 d-flex align-items-end">
                                                            <div class="w-100">
                                                                <label class="form-label"></label>
                                                                <input type="text" name="amount[]" id="amount"
                                                                    class="form-control form-control-sm textAlignRight amount"
                                                                    placeholder="Item Amount" maxlength="24"
                                                                    autocomplete="off" readonly required>
                                                            </div>

                                                            <div
                                                                class="col-10 col-sm-6 col-md-4 d-flex align-items-end">
                                                                <!-- <button type="button" class=" btn-item  add-item" onclick="addRow()">
                                                    <img src="./assets/images/add.svg" alt="" srcset="" class="icon">
                                                </button> -->
                                                                <button type="button" class="btn  btn-item  remove-btn "
                                                                    onclick="removeRow(this)" id="">
                                                                    <!-- <img src="./assets/images/trash.svg" alt=""
                                                                        srcset="" class="icon"> -->
                                                                    🗑️
                                                                </button>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class='d-flex justify-content-start mt-3'></div>
                                                <button type="button" class=" btn-item  " id="add-item"
                                                    onclick="addRow()">
                                                    Add item
                                                </button>
                                            </div>
                                            <!--  Buttons  -->
                                            <div class='d-flex justify-content-end mt-3'>
                                                <button type="submit" id='invoice_submit'
                                                    class="button-90 btn submit "><span class="update-icon"><i
                                                            class="bi bi-send"></i></span><span class="update-text">
                                                        Submit</span></i></button>
                                                <button type="reset"
                                                    class=" button-80 btn   btn-secondary reset grp"><i>
                                                        Reset</i></button>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="d-flex justify-content-end mt-2">
                                        <div class='' style="width: 230px; color:black; margin-right: 10px;">
                                            <label class="form-label">Total Amount</label>
                                            <input type="text" name="total_amount" id="total_amount"
                                                class="form-control form-control-sm total-amount textAlignRight mr-2"
                                                maxlength="24" autocomplete="off" value="0.00" readonly required>
                                        </div>
                                    </div>
                                </div>
                        </form>
                    </div>
                </div>





                <!-- =================================================================================================== -->
            </main>

        </div>
    </div>


    <script>
    function addRow() {
        let container = document.getElementById('item-container');
        let newRow = document.querySelector('.item-row').cloneNode(true);
        newRow.querySelectorAll('input').forEach(input => input.value = '');
        container.appendChild(newRow);
    }

    function removeRow(button) {
        let rows = document.querySelectorAll('.item-row');
        if (rows.length > 1) {
            button.closest('.item-row').remove();
        }
        total_amount();

        var id = $('.remove-btn').attr('id');
        itemadded.pop(id);
        console.log(itemadded);
    }


    function total_amount() {
        let total = 0;
        $('.amount').each(function() {
            total += parseFloat($(this).val()) || 0;
        });
        $('#total_amount').val(total.toFixed(2));
    }

    $(document).on('keyup change', '.quantity', function() {
        let $row = $(this).closest('.item-row');
        let price = $row.find(".price").val() || 0;
        let quantity = $row.find("#quantity").val() || 1;
        let amount = parseFloat(price * quantity);
        $row.find(".amount").val(amount.toFixed(2));
        total_amount();
    });

    $(document).on('keyup', '.quantity', function() {
        let quantity = $(this).val();
        if (quantity < 0 || quantity === '' || isNaN(quantity) || quantity === '0') {
            $(this).val(1);
        }
        total_amount();
    });

    $(document).on("click", ".pdf-generate", function() {
        const id = $(this).attr("invoice_id");
        const button = $(this);
        button.attr("disabled", true);
        $.ajax({
            url: urlMaker() + "/pdfGenerate",
            type: "POST",
            data: {
                invoice_id: id
            },
            success: function(response) {
                button.attr("disabled", false);
                if (response.includes("invoice_pdf/")) {
                    window.open(response, "_blank");
                } else {
                    alert("Error generating PDF. Please try again.");
                }
            },
            error: function() {
                button.attr("disabled", false);
                alert("Failed to generate PDF. Check server logs.");
            }
        });
    });

    $(document).on("click", ".email", function() {
        var id = $(this).data("id");
        var email = $(this).data("email");
        var url = urlMaker();
        $.ajax({
            url: url + "/sendmail",
            type: "POST",
            data: {
                email: email
            },
            success: function(response) {
                if (response.status) {
                    Swal.fire({
                        title: response.message,
                        icon: "success",
                        draggable: true,
                    });
                } else {
                    console.log("Failed to fetch data");
                }
            },
            error: function(xhr, status, error) {
                alert("Error: " + error);
            },
        });
    });


    $("#profile-tab").click(function() {
        var url = urlMaker();
        const today = new Date();
        const formattedDate = today.toISOString().split('T')[0];
        $('#invoice_date').val(formattedDate);
        $.ajax({
            url: url + "/invoiceNumber",
            type: "POST",
            success: function(response) {
                if (response.status) {
                    $("#invoice_no").val(Number(response.result) + 1);
                } else {
                    console.log("Failed to fetch data");
                }
            },
            error: function(xhr, status, error) {
                alert("Error: " + error);
            },
        });
    });


    $(document).ready(function() {
        var url = urlMaker();
        $('#name').autocomplete({
            source: function(request, response) {
                $.ajax({
                    url: url + "/clientdetail",
                    type: 'POST',
                    data: {
                        type: "clientdetail",
                        name: request.term
                    },
                    dataType: 'json',
                    success: function(data) {
                        response(data);
                    }
                });
            },
            select: function(event, ui) {
                let selectedName = ui.item.value;
                let selectedPhone = ui.item.phone;
                let selectedEmail = ui.item.email;
                let selectedId = ui.item.id;

                $("#client_id").val(selectedId);
                $("#invoice_email").val(selectedEmail);
                $("#phone").val(selectedPhone);
                $("#name").val(selectedName);

                return false;
            }
        });
    });
    let itemadded = [];
    $(document).on('keyup change', '#itemname', function() {
        var url = urlMaker();
        let $row = $(this).closest('.item-row');
        let itemname = $(this).val();

        $('#item-row').each(function() {
            let item_id = $(this).find("#item_id").val();
        });

        if (itemname === '') {
            $row.find(".item-name").fadeOut();
        } else {

            $(this).autocomplete({
                source: function(request, response) {
                    $.ajax({
                        url: url + "/itemdetail",
                        type: 'POST',
                        data: {
                            type: "itemDetail",
                            itemname: itemname,
                            itemPresent: itemadded
                        },
                        dataType: 'json',
                        success: function(data) {
                            if (data.type == 'autoComplete') {
                                response(data.suggestions);
                            }
                        },
                        error: function(xhr, status, error) {
                            console.error('AJAX Error:', error);
                        }
                    });
                },
                select: function(event, ui) {
                    let selectedPrice = ui.item.price;
                    let selectedId = ui.item.id;

                    $row.find("#item_id").val(selectedId);
                    $('.remove-btn').attr('id', selectedId);
                    $(".price").val(selectedPrice);
                    $row.find('#quantity').val(1);
                    let quantity = $row.find("#quantity").val() || 0;
                    let amount = parseFloat(selectedPrice * quantity);
                    $(".amount").val(amount);
                    total_amount();

                    itemadded.push(selectedId);



                },
                open: function() {
                    $row.find(".item-name").fadeIn();
                },
                close: function() {
                    $row.find(".item-name").fadeOut();
                }
            });
        }
        // console.log(itemadded);
    });
    </script>

































    <?= script_tag(base_url('assets/Lib/sweetalert.min.js')); ?>
    <?= script_tag(base_url('assets/Lib/bootstrap-5.0.2-dist/js/bootstrap.bundle.js')); ?>
    <?= script_tag(base_url('assets/js/Dashboard.js')); ?>
    <?= script_tag(base_url('assets/js/Masters.js')); ?>
    <?= script_tag(base_url('assets/Lib/fontawesome.js')); ?>


</body>

</html>