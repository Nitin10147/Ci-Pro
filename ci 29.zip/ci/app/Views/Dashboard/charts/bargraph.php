<div id="myChart" style="width:100%; height:100%;"></div>
<script src="https://www.gstatic.com/charts/loader.js"></script>
<script>
  var chartData = [];
  google.charts.load('current', {
    packages: ['corechart'],
    callback: function() {
      $.ajax({
        url: '<?= base_url('dashboard/getClientInvoiceCounts'); ?>',
        method: 'GET',
        dataType: 'json',
        success: function(response) {
          console.log(response);
          chartData.push(['item', 'Sales']);
          response.forEach(function(item) {
            const salesCount = parseInt(item.counts, 10);
            if (!isNaN(salesCount)) {
              chartData.push([item.itemname, salesCount]);
            }
          });
          drawChart(); 
        },
        error: function(xhr, status, error) {
          console.error("Error fetching data: ", error);
        }
      });
    }
  });


  function drawChart() {
    if (chartData.length > 0) {
      var data = google.visualization.arrayToDataTable(chartData);

      const options = {
        title: 'Total Sales Per Item',
      };

      const chart = new google.visualization.BarChart(document.getElementById('myChart'));
      chart.draw(data, options);
    }
  }
</script>
</body>
</html>
