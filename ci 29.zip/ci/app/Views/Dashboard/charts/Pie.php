
  <canvas id="myDonutChart" width="60%" height="60%"></canvas>
  <script>
  
    var ctx = document.getElementById('myDonutChart').getContext('2d');
     myDonutChart = new Chart(ctx, {
      type: 'doughnut',
      data: {
        datasets: [{
          data: [],  
          backgroundColor: ['#7CB9E8','#5c46ab', '#66669a', '#1a1241', '#bcd2d0', '#7CB9E8', '#00308F'], 
          borderWidth: 1,
        }],
        labels: []  
      }
    });

    $.ajax({
      url: '<?= base_url('dashboard/getClientInvoiceCounts'); ?>',
      method: 'GET',
      dataType: 'json',
      success: function(data) {
        var labels = [];
        var dataValues = [];

        data.forEach(function(item) {
          labels.push(item.cname);  
          dataValues.push(item.counts);  
        });

     
        myDonutChart.data.labels = labels;
        myDonutChart.data.datasets[0].data = dataValues;
        myDonutChart.update();
      },
      error: function(xhr, status, error) {
        // console.error("Error fetching data: ", error);
      }
    });
  </script>

</body>
</html>
