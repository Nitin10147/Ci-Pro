<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use CodeIgniter\HTTP\ResponseInterface;
use App\Libraries\formvalidation;

class UsermasterController extends BaseController
{


    public function index()
    {
        return view('Usermaster/usermaster');
    }

    public function addupdate()
    {


        $data = $this->request->getPost();
        $table = $data['table'] ?? 'usermaster';
        $formValidation = new Formvalidation();
        $data = $this->request->getPost();
        $result = $formValidation->validate($data, $table);

        if ($result !== true) {
            return $this->response->setJSON(
                [
                    'status' => false,
                    'error' => $result
                ]
            );
        } else {

            if (isset($data['password'])) {
                $data['password'] = md5(trim($data['password']));
            }

            if ($this->session->has('user_id') && $data['req_type'] == 'update') {
                $data['modified_by'] = $this->session->get('user_id');
                $data['modified_date'] = date('Y-m-d H:i:s');
            } else if ($this->session->has('user_id') && $data['req_type'] == 'add') {
                $data['created_by'] = $this->session->get('user_id');
            }

            // =========================image Upload ==============================
            helper('upload');
            $file = $this->request->getFile('image');
            // print_r($file);
            if ($file->isValid() && !$file->hasMoved()) {
                $result = upload_file($file);
                if (isset($result['filename'])) {
                    $data['profile_pic'] = $result['filename'];
                } else {
                    return $this->response->setJSON(
                        [
                            'status' => false,
                            'error' => $result['error']
                        ]
                    );
                }

            }
            $userModel = new \App\Models\Usermaster();
            $result = $userModel->addUpdate($data);
            return $this->response->setJSON($result);
        }


    }


    public function delete()
    {

        $id = $this->request->getPost('id');
        $userModel = new \App\Models\Usermaster();
        $result = $userModel->deleteuser($id);
        return $this->response->setJSON($result);

    }


    public function edit()
    {
        $id = $this->request->getPost('id');
        $userModel = new \App\Models\Usermaster();
        $result = $userModel->getuserData($id);
        return $this->response->setJSON($result);
    }


    public function view()
    {
        helper('pagination');
        try {
            // Get POST data
            $page_limit = $this->request->getPost('page_limit') ?? 5;
            $page_no = $this->request->getPost('page') ?? 1;
            $sort_column = $this->request->getPost('column') ?? 'status';
            $sort_order = $this->request->getPost('order') ?? 'DESC';
            $offset = ($page_no - 1) * $page_limit;

            // Optional search fields
            $name = !empty($this->request->getPost('searchname')) ? trim($this->request->getPost('searchname')) : "";
            $email = !empty($this->request->getPost('searchemail')) ? trim($this->request->getPost('searchemail')) : "";
            $phone = !empty($this->request->getPost('searchphone')) ? trim($this->request->getPost('searchphone')) : "";

            $userModel = new \App\Models\Usermaster();
            $queryData = $userModel->fetch($sort_column, $sort_order, $page_limit, $offset, $name, $email, $phone);

            $result = $queryData['data'];
            $total_records = $queryData['count'];

            // Prepare the table table
            $columns = ['id', 'first_name', 'last_name', 'email', 'mobile_number'];
            $table = '<div class="table-wrap">
            <table class="table ">
                <thead class="table-secondary">
                    <tr>
                        <th scope="col" class="text-center">Sr.No</th>';

            foreach ($columns as $column) {
                $new_sort_order = $sort_column == $column && $sort_order == 'ASC' ? 'DESC' : 'ASC';
                $sort_icons = $sort_column == $column && $sort_order == 'ASC' ?
                    '<i class="fa fa-sort-alpha-asc" aria-hidden="true"></i>' :
                    '<i class="fa fa-sort-alpha-desc" aria-hidden="true"></i>';

                $table .= '<th scope="col" class="text-center">
                <a class="column_sort text-black" href="#" data-column="' . $column . '" data-order="' . $new_sort_order . '" style="align-items: center; gap: 5px;">
                    <span>' . ucfirst($column) . '</span>
                    ' . $sort_icons . '
                </a>
            </th>';
            }
            $table .= '<th scope="col" class="text-center">ProfilePic</th>';
            $table .= '<th scope="col" class="text-center">Action</th></tr></thead>';

            // Display rows
            if (!empty($result)) {

                $s_no = $offset + 1;
                foreach ($result as $row) {
                    $table .= '<tr>';
                    $table .= '<td class="text-center">' . $s_no++ . '</td>';
                    $table .= '<td>' . $row['id'] . '</td>';
                    $table .= '<td>' . $row['first_name'] . '</td>';
                    $table .= '<td>' . $row['last_name'] . '</td>';
                    $table .= '<td  style = "width : auto ;">' . $row['email'] . '</td>';
                    $table .= '<td>' . $row['mobile_number'] . '</td>';
                    $table .= '<td class="table-img text-center">' .
                        '<img src="' . base_url('public/uploads/images/' . $row['profile_pic']) . '" alt="Profile Picture" class="tableimage">' .
                        '</td>';
                    $table .= '<td class="text-center">
                    <button class="btn  btn-sm edit" data-editid="' . $row['id'] . '">
                        <i class="fa fa-pencil" aria-hidden="true"></i>
                    </button>
                    <button class="btn  btn-sm delete" data-deleteid="' . $row['id'] . '">
                        <i class="fa fa-trash" aria-hidden="true"></i>
                    </button>
                </td>';
                    $table .= '</tr>';
                }
            } else {
                $table .= '<tr><td colspan="9" class="text-center font-weight-bold" style="background-color:rgb(253, 169, 169); color: red;">No Record Found</td></tr>';
            }

            $table .= '</tbody></table></div>';
            $pagination = pagination($page_no, $total_records, $page_limit);

            return $this->response->setJSON([
                'data' => $table,
                'pagination' => $pagination,
                'total_records' => $total_records,
                'total_pages' => ceil($total_records / $page_limit)
            ]);

        } catch (\Exception $e) {
            log_message('error', 'Error in fetch method: ' . $e->getMessage());
            echo json_encode(['error' => true, 'message' => 'An unexpected error occurred while fetching user data. Please try again later.']);
        }
    }

}