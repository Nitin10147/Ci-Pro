<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>Dashboard - SB Admin</title>
    <?= link_tag(base_url('assets/Lib/bootstrap-5.0.2-dist/css/bootstrap.css')); ?>
    <?= link_tag(base_url('assets/css/style.css')); ?>
    <?= script_tag(base_url('assets/js/jquery.js')); ?>
    <?= link_tag(base_url('assets/css/form.css')); ?>
    <script src="https://use.fontawesome.com/releases/v6.3.0/js/all.js" crossorigin="anonymous"></script>
</head>

<body class="sb-nav-fixed">

    <?= view('SideBar.Navbar/navbar') ?>
    <div id="layoutSidenav">
        <?= view('SideBar.Navbar/sidebar') ?>
        <div id="layoutSidenav_content">
            <main>

            </main>

        </div>
    </div>
    <?= script_tag(base_url('assets/Lib/bootstrap-5.0.2-dist/js/bootstrap.bundle.js')); ?>
    <?= script_tag(base_url('assets/js/Dashboard.js')); ?>

</body>

</html>