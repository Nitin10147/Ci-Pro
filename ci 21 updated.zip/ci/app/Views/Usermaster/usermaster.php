<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>Dashboard - SB Admin</title>
    <?= link_tag(base_url('assets/Lib/bootstrap-5.0.2-dist/css/bootstrap.css')); ?>
    <?= link_tag(base_url('assets/css/style.css')); ?>
    <?= link_tag(base_url('assets/css/form.css')); ?>
    <?= script_tag(base_url('assets/js/jquery.js')); ?>

</head>

<body class="sb-nav-fixed">

    <?= view('SideBar.Navbar/navbar') ?>
    <div id="layoutSidenav">
        <?= view('SideBar.Navbar/sidebar') ?>
        <div id="layoutSidenav_content">
            <main>
                <ul class="nav nav-tabs" id="myTab" role="tablist">
                    <li class="nav-item" role="presentation">
                        <button class="nav-link active" id="home-tab" data-bs-toggle="tab"
                            data-bs-target="#home-tab-pane" type="button" role="tab" aria-controls="home-tab-pane"
                            aria-selected="true">All Users</button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="profile-tab" data-bs-toggle="tab"
                            data-bs-target="#profile-tab-pane" type="button" role="tab" aria-controls="profile-tab-pane"
                            aria-selected="false">Add Users</button>
                    </li>
                </ul>

                <div class="tab-content" id="myTabContent">
                    <div class="tab-pane fade show active" id="home-tab-pane" role="tabpanel" aria-labelledby="home-tab"
                        tabindex="0">
                        <!-- =================================================  Table and -->
                        <div class="d-flex justify-content-between align-items-end mb-1 mt-1">
                            <div class="container mt-1 searchcontainer">

                                <button class="btn " type="button" id="togglerButton">
                                    ▼ &nbsp Search Form
                                </button>

                                <div id="searchBarContainer" class="collapse">
                                        <?php
                                        $data = [
                                            ['name' => 'searchname', 'label' => 'Name', 'placeholder' => 'Enter Name', 'type'=>'text'],
                                            ['name' => 'searchemail', 'label' => 'Email', 'placeholder' => 'Enter Email', 'type'=>'email'],
                                            ['name' => 'searchphone', 'label' => 'Phone ', 'placeholder' => 'Enter Phone Number' , 'type'=>'text'],
                                        ];
                                        generateSearchFields($data);
                                        ?>
                                </div>
                            </div>
                        </div>
                        <div class="d-flex flex-row-reverse ">
                            <select id="page_limit" class="p-2 page_limit"
                                style="width: 55px; margin-top: 20px; margin-right: 40px; display: inline-block">
                                <option value="5" selected>5</option>
                                <option value="10">10</option>
                                <option value="15">15</option>
                                <option value="20">20</option>
                                <option value="25">25</option>
                                <option value="30">30</option>
                            </select>
                        </div>

                        <div id="tableDiv" class="table-responsive card-body"></div>
                        <div id="containerPage" style="background-color: #e9ecef; height: 50px;"></div>
                    </div>

                    <!-- ======================================================================================================= -->
                    <div class="tab-pane fade" id="profile-tab-pane" role="tabpanel" aria-labelledby="profile-tab"
                        tabindex="0">
                        <!-- Form for Home Tab -->
                        <form class="row g-4 m-3 AllForm" id="usermaster" method="POST" enctype="multipart/form-data"
                            data-request="">
                            <input type="text" name='table' value="user_master" hidden>
                            <input type="text" name="id" id="fieldId" value="" autocomplete="off" hidden>
                            <div class="col-md-3">
                                <label for="first_name" class="form-label">First Name</label>
                                <input type="text" name="first_name" class="form-control" id="first_name"
                                    placeholder="Enter your first name" maxlength="20" autofocus>
                                <span id='fname-error' class="error empty-space"></span>
                            </div>
                            <div class="col-md-3">
                                <label for="last_name" class="form-label">Last Name</label>
                                <input type="text" name="last_name" class="form-control" id="last_name"
                                    placeholder="Enter your last name" maxlength="20">
                                <span id='lname-error' class="error empty-space"></span>
                            </div>
                            <div class="col-md-3">
                                <label for="email" class="form-label">Email</label>
                                <input type="email" name="email" class="form-control" id="email"
                                    placeholder="Enter your email" maxlength="30">
                                <span id='emailError' class="error empty-space"></span>
                            </div>
                            <div class="col-md-3 passwordfield">
                                <label for="password" class="form-label ">Password</label>
                                <input type="text" name="password" class="form-control " id="password"
                                    placeholder="Enter your password" maxlength="25">
                                <span id="passwordError" class="error empty-space "></span>
                            </div>
                            <div class="col-md-3">
                                <label for="mobile_number" class="form-label">Phone number</label>
                                <input type="text" name="mobile_number" class="form-control" id="mobile_number"
                                    placeholder="Enter your phone number" maxlength="10">

                                <span id='phone-error' class="error empty-space"></span>
                            </div>
                            <!-- Uplaod Image -->
                            <div class="col-md-3 d-flex">
                                <label for="profile-picture" class=" form-label ml-3">Profile Picture:</label>
                                <div class="circle-container ml-3" id="circle-container" onclick="triggerFileInput()">
                                    <img id="profile-image" src="./assets/images/upload.png">
                                </div>

                                <input type="file" id="profile-picture" class="" name="image" accept="image/*"
                                    onchange="loadFile(event)" value="image">
                            </div>

                            <div class="col-12 text-end allbtn">

                                <span class='usubmit'><button type="submit" class="btn btn-primary button-90 "
                                        id="submit">Submit</button></span>

                                <button type="reset" class="btn btn-secondary button-80 reset">Reset</button>
                            </div>

                        </form>
                    </div>
                </div>
            </main>

        </div>
    </div>
    <?= script_tag(base_url('assets/Lib/sweetalert.min.js')); ?>
    <?= script_tag(base_url('assets/Lib/bootstrap-5.0.2-dist/js/bootstrap.bundle.js')); ?>
    <?= script_tag(base_url('assets/js/Dashboard.js')); ?>
    <?= script_tag(base_url('assets/js/Masters.js')); ?>
    <?= script_tag(base_url('assets/Lib/fontawesome.js')); ?>
</body>

</html>