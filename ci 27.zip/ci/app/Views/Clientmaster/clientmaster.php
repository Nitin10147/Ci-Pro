<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>Dashboard - SB Admin</title>
    <?= link_tag(base_url('assets/Lib/bootstrap-5.0.2-dist/css/bootstrap.css')); ?>
    <?= link_tag(base_url('assets/css/style.css')); ?>
    <?= script_tag(base_url('assets/js/jquery.js')); ?>
    <?= link_tag(base_url('assets/css/form.css')); ?>
    <script src="https://use.fontawesome.com/releases/v6.3.0/js/all.js" crossorigin="anonymous"></script>
</head>

<body class="sb-nav-fixed">

    <?= view('SideBar.Navbar/navbar') ?>
    <div id="layoutSidenav">
        <?= view('SideBar.Navbar/sidebar') ?>
        <div id="layoutSidenav_content">
            <main>

                <ul class="nav nav-tabs" id="myTab" role="tablist">
                    <li class="nav-item" role="presentation">
                        <button class="nav-link active" id="home-tab" data-bs-toggle="tab"
                            data-bs-target="#home-tab-pane" type="button" role="tab" aria-controls="home-tab-pane"
                            aria-selected="true">All Client</button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="profile-tab" data-bs-toggle="tab"
                            data-bs-target="#profile-tab-pane" type="button" role="tab" aria-controls="profile-tab-pane"
                            aria-selected="false">Add Clients</button>
                    </li>
                </ul>


                <div class="tab-content" id="myTabContent">
                    <div class="tab-pane fade show active" id="home-tab-pane" role="tabpanel" aria-labelledby="home-tab"
                        tabindex="0">
                        <div class="d-flex justify-content-between align-items-end mb-1 mt-1">
                            <div class="container mt-1 searchcontainer">

                                <button class="btn " type="button" id="togglerButton">
                                    ▼ &nbsp Search Form
                                </button>

                                <div id="searchBarContainer" class="collapse">
                                    <?php
                                    $data = [
                                        ['name' => 'searchclientname', 'label' => 'Client Name', 'placeholder' => 'Enter Name', 'type' => 'text'],
                                        ['name' => 'searchemail', 'label' => 'Email', 'placeholder' => 'Enter Email', 'type' => 'text'],
                                        ['name' => 'searchphone', 'label' => 'Mobile Number', 'placeholder' => 'Enter Mobile Number', 'type' => 'text'],
                                    ];
                                    generateSearchFields($data);
                                    ?>
                                </div>
                            </div>
                        </div>

                        <div class="d-flex justify-content-between align-items-center">
                            <!-- Left Side: Search and Message -->
                            <div class="d-flex align-items-center">
                                <select id="page_limit" class="p-2 page_limit">
                                    <option value="5" selected>5</option>
                                    <option value="10">10</option>
                                    <option value="15">15</option>
                                    <option value="20">20</option>
                                    <option value="25">25</option>
                                    <option value="30">30</option>
                                </select>

                                <!-- <div id="mess" class="ms-2">
                                    <img src="<?= base_url('assets/images/mess.gif'); ?>" alt="" srcset=""
                                        style="width: 80px">
                                </div> -->

                                <div class="mess-container">
                                    <div class="record-box">
                                        Total Records: <span id="totalRecord" class="records">100</span>
                                    </div>
                                    <div class="record-box">
                                        Total Pages: <span id="totalPage" class="records">10</span>
                                    </div>
                                </div>

                            </div>

                            <div id="containerPage" class="d-flex align-items-center"></div>
                        </div>


                        <div id="tableDiv" class="table-responsive card-body"></div>
                    </div>
                    <div class="tab-pane fade" id="profile-tab-pane" role="tabpanel" aria-labelledby="profile-tab"
                        tabindex="0">


                        <form class="row g-4 m-3" id="clientmaster" method="POST">
                            <input type="text" name="id" id="fieldId" value="" autocomplete="off" hidden>
                            <div class="col-md-3">
                                <label for="first_name" class="form-label">First Name</label>
                                <input type="text" name='first_name' class="form-control" id="first_name"
                                    placeholder="Enter your first name" maxlength="20" autofocus>
                                <span id='fname-error' class="error empty-space"></span>

                            </div>
                            <div class="col-md-3">
                                <label for="last_name" class="form-label">Last Name</label>
                                <input type="text" name='last_name' class="form-control" id="last_name"
                                    placeholder="Enter your last name" maxlength="20">
                                <span id='lname-error' class="error empty-space"></span>
                            </div>
                            <div class="col-md-3">
                                <label for="email" class="form-label">Email</label>
                                <input type="email" name="email" class="form-control" id="email"
                                    placeholder="Enter your email" maxlength="30">
                                <span id='emailError' class="error empty-space"></span>
                            </div>
                            <div class="col-md-3">
                                <label for="mobile_number" class="form-label">Phone</label>
                                <input type="text" name="mobile_number" class="form-control" id="mobile_number"
                                    placeholder="Enter your phone number" maxlength="10">
                                <span id='phone-error' class="error empty-space"></span>
                            </div>
                            <div class="col-md-3">
                                <label for="address" class="form-label">Address</label>
                                <input type="text" name="address" class="form-control" id="address"
                                    placeholder="Enter your address" maxlength="50">
                                <span id='address-error' class="error empty-space"></span>
                            </div>
                            <!-- <div class="col-md-3">
                                <label for="inputState" class="form-label">State</label>
                                <select id="inputState" name="state" class="form-select ">

                                    <option selected>Choose...</option>


                                </select>
                            </div>

                            
                            <div class="col-md-3" id="city-container" style=>
                                <label for="inputCity" class="form-label">City</label>
                                <select id="inputCity" name="city" class="form-select">
                                    <option name="city" selected>Choose...</option>
                                </select>
                            </div> -->

                            <div class="col-12 col-sm-6 col-md-3">
                                <label for="state" class="form-label">State <span class="text-danger">*</span></label>
                                <select name="state" id="state" class="form-select form-select-sm state" required>
                                    <option value="">Select State</option>
                                </select>
                            </div>
                            <div class="col-12 col-sm-6 col-md-3">
                                <label for="city" class="form-label">City <span class="text-danger">*</span></label>
                                <select name="city" id="city" class="form-select form-select-sm city" required>
                                    <option class="Scity" value="">Select City</option>
                                </select>
                            </div>

                            <div class="col-md-3">
                                <label for="zip" class="form-label">Zip</label>
                                <input type="text" name="zip" class="form-control" id="zip"
                                    placeholder="Enter your zip code" maxlength="6">
                                <span id='zip-error' class="error empty-space"></span>
                            </div>
                            <div class="col-12 text-end">
                                <span class='usubmit'><button type="submit" class="btn btn-primary button-90 "
                                        id="add">Submit</button></span>
                                <button type="reset" class="btn btn-secondary button-80 reset" id="resetForm">Reset</button>
                            </div>
                        </form>
                    </div>
                </div>

            </main>


        </div>
    </div>
    <?= script_tag(base_url('assets/Lib/sweetalert.min.js')); ?>
    <?= script_tag(base_url('assets/Lib/bootstrap-5.0.2-dist/js/bootstrap.bundle.js')); ?>
    <?= script_tag(base_url('assets/js/Dashboard.js')); ?>
    <?= script_tag(base_url('assets/js/Masters.js')); ?>
    <?= script_tag(base_url('assets/Lib/fontawesome.js')); ?>


    <script>
    $('#home-tab').click(function() {
        $('#profile-tab').text('Add Client');;
    });

    
    $(document).ready(function() {
        loadState();
        $(".state").on("change", function() {
            var state = $(this).val();
            if (state) {
                loadDistrict(state);
            } else {
                $(".city").html('<option value="">Select City</option>');
            }
        });


        function loadState() {
            $.ajax({
                url: "<?php echo base_url(); ?>clientmaster/getAddress",
                type: "POST",
                data: {
                    type: "state"
                },
                success: function(response) {
                    $(".state").html(
                        '<option id="sState" value="">Select State</option>' + response
                    );
                },
            });
        }
    });

    function loadDistrict(state) {
        $.ajax({
            url: "<?php echo base_url(); ?>clientmaster/getAddress",
            type: "POST",
            data: {
                type: "city",
                state: state
            },
            success: function(response) {
                $(".city").html(
                    '<option id="sCity" value="">Select City</option>' + response
                );
            },
        });
    }
    </script>


</body>

</html>