<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>Dashboard - SB Admin</title>
    <?= link_tag(base_url('assets/Lib/bootstrap-5.0.2-dist/css/bootstrap.css')); ?>
    <?= link_tag(base_url('assets/css/style.css')); ?>
    <?= script_tag(base_url('assets/js/jquery.js')); ?>
    <?= link_tag(base_url('assets/css/form.css')); ?>
    <script src="https://use.fontawesome.com/releases/v6.3.0/js/all.js" crossorigin="anonymous"></script>
</head>

<body class="sb-nav-fixed">

    <?= view('SideBar.Navbar/navbar') ?>
    <div id="layoutSidenav">
        <?= view('SideBar.Navbar/sidebar') ?>
        <div id="layoutSidenav_content">
            <main>

                <ul class="nav nav-tabs" id="myTab" role="tablist">
                    <li class="nav-item" role="presentation">
                        <button class="nav-link active" id="home-tab" data-bs-toggle="tab"
                            data-bs-target="#home-tab-pane" type="button" role="tab" aria-controls="home-tab-pane"
                            aria-selected="true">All Items</button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="profile-tab" data-bs-toggle="tab"
                            data-bs-target="#profile-tab-pane" type="button" role="tab" aria-controls="profile-tab-pane"
                            aria-selected="false">Add Items</button>
                    </li>
                </ul>

                <div class="tab-content" id="myTabContent">
                    <div class="tab-pane fade show active" id="home-tab-pane" role="tabpanel" aria-labelledby="home-tab"
                        tabindex="0">
                        <div class="d-flex justify-content-between align-items-end mb-1 mt-1">
                            <div class="container mt-1 searchcontainer">

                                <button class="btn " type="button" id="togglerButton">
                                    ▼ &nbsp Search Form
                                </button>

                                <div id="searchBarContainer" class="collapse">
                                    <?php
                                    $data = [
                                        ['name' => 'searchitemname', 'label' => 'Item Name', 'placeholder' => 'Enter Item Name', 'type' => 'text'],
                                        ['name' => 'searchprice', 'label' => 'Price', 'placeholder' => 'Enter Item Price', 'type' => 'text'],
                                    ];
                                    generateSearchFields($data);
                                    ?>
                                </div>
                            </div>
                        </div>

                        <div class="d-flex justify-content-between align-items-center">
                            <!-- Left Side: Search and Message -->
                            <div class="d-flex align-items-center">
                                <select id="page_limit" class="p-2 page_limit">
                                    <option value="5" selected>5</option>
                                    <option value="10">10</option>
                                    <option value="15">15</option>
                                    <option value="20">20</option>
                                    <option value="25">25</option>
                                    <option value="30">30</option>
                                </select>

                                <!-- <div id="mess" class="ms-2">
                                    <img src="<?= base_url('assets/images/mess.gif'); ?>" alt="" srcset=""
                                        style="width: 80px">
                                </div> -->

                                <div class="mess-container">
                                    <div class="record-box">
                                        Total Records: <span id="totalRecord" class="records">100</span>
                                    </div>
                                    <div class="record-box">
                                        Total Pages: <span id="totalPage" class="records">10</span>
                                    </div>
                                </div>

                            </div>

                            <div id="containerPage" class="d-flex align-items-center"></div>
                        </div>


                        <div id="tableDiv" class="table-responsive card-body"></div>
                    </div>
                    <div class="tab-pane fade" id="profile-tab-pane" role="tabpanel" aria-labelledby="profile-tab"
                        tabindex="0">
                        <form class="row g-4 m-3" id="itemmaster" method="POST">
                        <input type="text" name="id" id="fieldId" value="" autocomplete="off" hidden>

                            <div class="col-md-3">
                                <label for="item_name" class="form-label">Item Name</label>
                                <input type="text" name="item_name" class="form-control" id="item_name"
                                    placeholder="Enter itemname.." maxlength="20" autofocus style="width: 100%;">
                                <span id='itemname-error' class="error empty-space"></span>
                            </div>

                            <div class="col-md-3">
                                <label for="description" class="form-label">Description</label>
                                <input type="text" name="description" class="form-control" id="description"
                                    placeholder="Enter item description.." maxlength="20" style="width: 100%;">
                                <span id='description-error' class="error empty-space"></span>
                            </div>

                            <div class="col-md-3">
                                <label for="price" class="form-label">Price</label>
                                <input type="text" name="price" class="form-control" id="price"
                                    placeholder="Enter item price..." maxlength="10" style="width: 100%;">
                                <span id='price-error' class="error empty-space"></span>
                            </div>

                            <!-- <div class="col-md-3 d-flex">
                                <label for="profile-picture" class="ml-3 form-label" style="margin-right: 10px;">Item
                                    image:</label>
                                <div class="circle-container" id="circle-container" onclick="triggerFileInput()"
                                    style="margin-right: 10px;">
                                    <img id="profile-image" src="./assets/images/upload.png" alt=""
                                        style="width: 50px; height: 50px;">
                                </div>

                                <input type="file" id="profile-picture" name="image" accept="image/*"
                                    onchange="loadFile(event)" style="display: none;">
                            </div> -->

                            <div class="col-md-3 d-flex">
                                <label for="profile-picture" class=" form-label ml-3">Image :</label>
                                <div class="circle-container ml-3" id="circle-container" onclick="triggerFileInput()">
                                    <img id="profile-image" src="./assets/images/upload.png">
                                </div>

                                <input type="file" id="profile-picture" class="" name="image" accept="image/*"
                                    onchange="loadFile(event)" value="image">
                            </div>


                            <div class="col-12 text-end allbtn">
                                <span class='usubmit'>
                                    <button type="submit" class="btn btn-primary button-90" id="add">Submit</button>
                                </span>

                                <button type="reset" class="btn btn-secondary button-80 reset" id="resetForm" >Reset</button>
                            </div>

                        </form>
                    </div>
                </div>
            </main>

        </div>
    </div>
    <?= script_tag(base_url('assets/Lib/sweetalert.min.js')); ?>
    <?= script_tag(base_url('assets/Lib/bootstrap-5.0.2-dist/js/bootstrap.bundle.js')); ?>
    <?= script_tag(base_url('assets/js/Dashboard.js')); ?>
    <?= script_tag(base_url('assets/js/Masters.js')); ?>
    <?= script_tag(base_url('assets/Lib/fontawesome.js')); ?>


    <script>
    $('#home-tab').click(function() {
        $('#profile-tab').text('Add Item');;
    });
    </script>
</body>

</html>