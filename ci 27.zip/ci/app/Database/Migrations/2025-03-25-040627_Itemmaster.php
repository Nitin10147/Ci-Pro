<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class Itemmaster extends Migration
{
    public function up()
    {
        // columns = ["id", "itemname", "description", "price", "created_date", "image"];

        $this->forge->addField(
            [
                'id' => [
                    'type' => 'INT',
                    'constraint' => 11,
                    'unsigned' => true,
                    'auto_increment' => true,
                ],
                'item_name' => [
                    'type' => 'VARCHAR',
                    'constraint' => 20,
                    'null' => false,
                ],
                'description' => [
                    'type' => 'VARCHAR',
                    'constraint' => 50,
                    'null' => false,
                ],
                'price' => [
                    'type' => 'INT',
                    'constraint' => 11,
                    'null' => false,
                ],
                'created_date' => [
                    'type' => 'DateTime',
                    'null' => false,
                ],
                'image' => [
                    'type' => 'VARCHAR',
                    'constraint' => 70,
                    'null' => false,
                ],
            ]
        );
        $this->forge->addKey('id', true);
        $this->forge->addUniqueKey('item_name'); 
        $this->forge->createTable('itemmaster');

    }

    public function down()
    {
        $this->forge->dropTable('itemmaster');
        
    }
}
