<?php
function generateSearchFields($fields) {

    echo '<form action="" id="searchForm" method="POST" class="form-inline d-flex align-items-center flex-wrap">'; 
    
    foreach ($fields as $field) {
        $name = $field['name'];
        $label = isset($field['label']) ? $field['label'] : ucfirst($name);
        $placeholder = isset($field['placeholder']) ? $field['placeholder'] : $label;
        $type = isset($field['type']) ? $field['type'] : 'text';
        $class = isset($field['class']) ? $field['class'] : '';
        $style = isset($field['style']) ? $field['style'] : '';
        $filedtype = isset($field['fieldtype']) ? $field['fieldtype'] : '';
        echo '<div class=" form-group mb-3">';  
       
        if($filedtype == "input"){
            echo '<label for="' . $name . 'search" class="search-label d-block">' . $label . ':</label>';
            echo '<input type="' . $type . '" name="' . $name . '" id="' . $name . 'search" class="form-control search ' . $class . '" placeholder="' . $placeholder . '" style="' . $style . '">';
        }
        else if($filedtype == "select"){ 
            // echo '<label for="' . $name . 'search" class="search-label ">' . $label . ':</label>';
            // echo '<select name="' . $name . '" id="' . $name . 'search" class="form-select search ' . $class . '" style="' . $style . '" ';
            // echo '</select>';
        }
        echo '</div>';
    }

    echo '<div class="d-flex justify-content-center flex-wrap" style="height:30px">';  
    echo '<button type="submit" class="btn btn-primary button-90" id="searchBtn" style="margin-right: 10px">Search</button>';
    echo '<button type="reset" class="btn btn-secondary button-80" id="resetSearch">Reset</button>';
    echo '</div>';
    echo '</form>';
}



?>
