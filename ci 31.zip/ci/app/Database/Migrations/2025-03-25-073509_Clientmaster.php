<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class Clientmaster extends Migration
{
    public function up()
    {
        // col=[id,first_name,last_name,email,phone,state,city,address,zip]

        $this->forge->addField(
            [
                'id' => [
                    'type' => 'INT',
                    'constraint' => 11,
                    'unsigned' => true,
                    'auto_increment' => true,
                ],
                'first_name' => [
                    'type' => 'VARCHAR',
                    'constraint' => 20,
                    'null' => false,
                ],
                'last_name' => [
                    'type' => 'VARCHAR',
                    'constraint' => 20,
                    'null' => false,
                ],
                'email' => [
                    'type' => 'VARCHAR',
                    'constraint' => 30,
                    'null' => false,
                ],
                'mobile_number' => [
                    'type' => 'BIGINT',
                    'constraint' => 13,
                    'null' => false,
                ],
                'address' => [
                    'type' => 'VARCHAR',
                    'constraint' => 30,
                    'null' => false,
                ],  
                'state' => [
                    'type' => 'VARCHAR',
                    'constraint' => 20,
                    'null' => false,
                ],
                'city' => [
                    'type' => 'VARCHAR',
                    'constraint' => 20,
                    'null' => false,
                ],
                'zip' => [
                    'type' => 'INT',
                    'constraint' => 6,
                    'null' => false,
                ],
            ]
        );
        $this->forge->addKey('id', true);
        $this->forge->addUniqueKey('email'); 
        $this->forge->addUniqueKey('mobile_number');
        $this->forge->createTable('clientmaster');

    }

    public function down()
    {
        $this->forge->dropTable('clientmaster');
        
    }
}
