<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

class UsermasterSeeder extends Seeder
{
    public function run()
    { 
        $data=[
            [
                'first_name'=>'admin',
                'last_name'=>'admin',
                'email'=>'demo@gmail.com',
                'password'=>'admin',
                'mobile_number'=>'1234567890',
                'created_by'=>1,        
                'created_date'=>date('Y-m-d H:i:s'),  
                'modified_by'=>1,
                'modified_date'=>date('Y-m-d H:i:s'),
            ],
            [
                'first_name'=>'user',
                'last_name'=>'user',
                'email'=>'xyz@gmail.com',
                'password'=>'user',
                'mobile_number'=>'1234567890',
                'created_by'=>1,
                'created_date'=>date('Y-m-d H:i:s'),
                'modified_by'=>1,
                'modified_date'=>date('Y-m-d H:i:s'),
            ]
            ];
            
            $this->db->table('usermaster')->insertBatch($data);

    }
}
