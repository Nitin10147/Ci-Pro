<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>Dashboard - SB Admin</title>
    <?= link_tag(base_url('assets/Lib/bootstrap-5.0.2-dist/css/bootstrap.min.css')); ?>
    <?= link_tag(base_url('assets/css/style.css')); ?>
    <?= script_tag(base_url('assets/js/jquery.js')); ?>
    <?= link_tag(base_url('assets/css/form.css')); ?>
    <?= link_tag(base_url('assets/css/dashboard.css')); ?>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script src="https://use.fontawesome.com/releases/v6.3.0/js/all.js" crossorigin="anonymous"></script>
</head>

<body class="sb-nav-fixed">

    <?= view('SideBar.Navbar/navbar') ?>
    <div id="layoutSidenav">
        <?= view('SideBar.Navbar/sidebar') ?>
        <div id="layoutSidenav_content">
            <main>
                <?= view('Dashboard/Tiles') ?>
               <div id="chartContainer">
               <div class="col-5 mt-3 text-center" id="pieChart">
                    <h5 class="mt-4" id="PieHeading">Invoice Created by Per Client</h5>
                    <?php include 'charts/Pie.php' ?>
                </div>
                <div class="col-8 col-md-7 ml-3" id="barChart">
                    <?php include 'charts/bargraph.php' ?>
                </div>
               </div>
            </main>

        </div>
    </div>
    <?= script_tag(base_url('assets/Lib/bootstrap-5.0.2-dist/js/bootstrap.bundle.js')); ?>
    <?= script_tag(base_url('assets/js/Dashboard.js')); ?>

</body>

</html>