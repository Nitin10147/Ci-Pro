<?php

namespace App\Libraries;

use CodeIgniter\Database\SQLite3\Table;

class Formvalidation
{
    public function validate($data, $table)
    {
       
        $defaultFields = [
            'first_name' => 'required|trim|min_length[3]|regex_match[/^[a-zA-Z ]+$/]',
            'last_name' => 'required|trim|min_length[3]|regex_match[/^[a-zA-Z ]+$/]',
            'email' => 'valid_email', 
            'mobile_number' => 'required|trim|exact_length[10]|numeric',
            'price' => 'required|trim|numeric',
            'item_name' => 'required|trim|min_length[3]|regex_match[/^[a-zA-Z ]+$/]',
            'address' => 'required|trim|min_length[3]|regex_match[/^[a-zA-Z0-9 ]+$/]',
            'zip' => 'required|trim|exact_length[6]|numeric',
            'state' => 'required',
            'city' => 'required',
            
        ];

        
        $fieldsToValidate = [];
        foreach ($defaultFields as $field => $rule) {
            if (array_key_exists($field, $data)) {
                $fieldsToValidate[$field] = $rule;
            }
        }

        if (empty($fieldsToValidate)) {
            return true;
        }

    
        $validation = \Config\Services::validation();
        $validation->setRules($fieldsToValidate);

        if (!$validation->run($data)) {
            return $validation->getErrors();
        } else {
            return true;
        }
    }
}

