<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use CodeIgniter\HTTP\ResponseInterface;

class DashboardController extends BaseController
{

    public function index()
    {
       
        $db = \Config\Database::connect();
        $query = $db->query("CALL TileData()");
        $result = $query->getResultArray();
        // print_r($result);
        return view('Dashboard/dashboard', ['data' => $result]);
    }

    public function getClientInvoiceCounts()
    {
        try {
            $clientModel = new \App\Models\Clientmaster();
            $data = $clientModel->getClientInvoiceCounts();
            return $this->response->setJSON($data);
        } catch (\Exception $e) {
            return $this->response->setJSON('Database query failed: ' . $e->getMessage());
        }
    }
}


