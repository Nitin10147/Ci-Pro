<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use CodeIgniter\HTTP\ResponseInterface;
use App\Libraries\formvalidation;

class ItemmasterController extends BaseController
{
    public function index()
    {
        return view('Itemmaster/itemmaster');
    }

    public function addupdate()
    {

    
        $data = $this->request->getPost();
        // print_r($data);
        $table = $data['table'] ?? 'itemmaster';
        $formValidation = new Formvalidation();
        $data = $this->request->getPost();
        $result = $formValidation->validate($data, $table);

        if ($result !== true) {
            return $this->response->setJSON(
                [
                    'status' => false,
                    'message' => $result
                ]
            );
        } else {


            helper('checkUniqe');
            $isUnique = checkExistence('itemmaster', 'item_name', $data['item_name']);
            if ($isUnique) {
                return $this->response->setJSON([
                    'status' => false,
                    'message' => "Item already exists!"
                ]);
            }

            helper('upload');
            $file = $this->request->getFile('image');

            if ($file->isValid() && !$file->hasMoved()) {
                $result = upload_file($file);
                if (isset($result['filename'])) {
                    $data['image'] = $result['filename'];
                } else {
                    return $this->response->setJSON([
                        'status' => false,
                        'message' => $result['message']
                    ]);
                }
            }

            $itemModel = new \App\Models\Itemmaster();
            $result = $itemModel->addUpdate($data);
            return $this->response->setJSON($result);
        }

    }

        public function delete()
        {
            $id = $this->request->getPost('id');
            $itemModel = new \App\Models\Itemmaster();
            $result = $itemModel->deleteuser($id);
            return $this->response->setJSON($result);
    
        }
    
    
        public function edit()
        {
            $id = $this->request->getPost('id');
            $itemModel = new \App\Models\Itemmaster();
            $result = $itemModel->getuserData($id);
            return $this->response->setJSON($result);
        }


        public function view()
        {
            helper('pagination');
            try {
                
                $page_limit = $this->request->getPost('page_limit') ?? 5;
                $page_no = $this->request->getPost('page') ?? 1;
                $sort_column = $this->request->getPost('column') ?? 'status';
                $sort_order = $this->request->getPost('order') ?? 'DESC';
                $offset = ($page_no - 1) * $page_limit;
    
                $itemname = !empty($this->request->getPost('searchitemname')) ? trim($this->request->getPost('searchitemname')) : "";
                $price = !empty($this->request->getPost('searchprice')) ? trim($this->request->getPost('searchprice')) : "";
            
                $userModel = new \App\Models\Itemmaster();
                $queryData = $userModel->fetch($sort_column, $sort_order, $page_limit, $offset, $itemname, $price);
    
                $result = $queryData['data'];
                $total_records = $queryData['count'];
    
                $columns = ['id', 'item_name','Description', 'price'];
                $table = '<div class="table-wrap">
                <table class="table ">
                    <thead class="table-secondary">
                        <tr>
                            <th scope="col" class="text-center">Sr.No</th>';
      
                foreach ($columns as $column) {
                    $new_sort_order = $sort_column == $column && $sort_order == 'ASC' ? 'DESC' : 'ASC';
                    $sort_icons = $sort_column == $column && $sort_order == 'ASC' ?
                        '<i class="fa fa-sort-alpha-asc" aria-hidden="true"></i>' :
                        '<i class="fa fa-sort-alpha-desc" aria-hidden="true"></i>';
    
                        $table .= '<th scope="col" class="text-center">
                            <a class="column_sort text-black" href="#" data-column="' . $column . '" data-order="' . $new_sort_order . '" style="align-items: center; gap: 5px;">
                                <span>' . ucfirst($column) . '</span>
                                ' . $sort_icons . '
                            </a>
                        </th>';
                    
                }
                $table .= '<th scope="col" class="text-center">Item Image</th>';
                $table .= '<th scope="col" class="text-center">Action</th></tr></thead>';
    
               
                if (!empty($result)) {
    
                    $s_no = $offset + 1;
                    foreach ($result as $row) {
                        $table .= '<tr>';
                        $table .= '<td class="text-end">' . $s_no++ . '</td>';
                        $table .= '<td class="text-end">' . $row['id'] . '</td>';
    
                        $table .= '<td><a class="edit" style="cursor: pointer; text-decoration: none; font-weight:bold;" data-editid="' . $row['id'] . '">' . $row['item_name'] . '</a></td>';
                        $table .= '<td  style = "width : auto ;">' . (!empty($row['description']) ? $row['description'] : '---No Description---') . '</td>';
                        $table .= '<td class="text-end pl-1"> ₹ ' . $row['price'] . '</td>';
                        $table .= '<td class="table-img text-center">' .
                            '<img src="' . base_url('public/uploads/images/' . (!empty($row['image']) ? $row['image'] : 'noimg.jpg')) . '" alt="Profile Picture" class="tableimage">' .
                            '</td>';
                        $table .= '<td class="text-center">
                        <button class="btn  btn-sm edit" data-editid="' . $row['id'] . '">
                            <i class="fa fa-pencil" aria-hidden="true"></i>
                        </button>
                        <button class="btn  btn-sm delete" data-deleteid="' . $row['id'] . '">
                            <i class="fa fa-trash" aria-hidden="true"></i>
                        </button>
                    </td>';
                        $table .= '</tr>';
                    }
                } else {
                    $table .= '<tr><td colspan="9" class="text-center font-weight-bold" style="background-color:rgb(253, 169, 169); color: red;">No Record Found</td></tr>';
                }
    
                $table .= '</tbody></table></div>';
                $pagination = pagination($page_no, $total_records, $page_limit);
    
                return $this->response->setJSON([
                    'data' => $table,
                    'pagination' => $pagination,
                    'total_records' => $total_records,
                    'total_pages' => ceil($total_records / $page_limit)
                ]);
    
            } catch (\Exception $e) {
                log_message('error', 'Error in fetch method: ' . $e->getMessage());
                echo json_encode(['error' => true, 'message' => 'An unexpected error occurred while fetching user data. Please try again later.']);
            }
        }
    

}

