<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use CodeIgniter\HTTP\ResponseInterface;
use App\Libraries\formvalidation;



class ClientmasterController extends BaseController
{
    public function index()
    {
        return view('Clientmaster/clientmaster');
    }
    public function addupdate()
    {


        $data = $this->request->getPost();
        $table = $data['table'] ?? 'clientmaster';
        $formValidation = new Formvalidation();
        $data = $this->request->getPost();
        $result = $formValidation->validate($data, $table);

        if ($result !== true) {
            return $this->response->setJSON(
                [
                    'status' => false,
                    'message' => $result
                ]
            );
        } else {

            helper('checkUniqe');
            $isUnique = checkExistence('clientmaster', 'mobile_number', $data['mobile_number']);
            if ($isUnique) {
                return $this->response->setJSON([
                    'status' => false,
                    'message' => "Mobile number already exists!"
                ]);
            }

            $userModel = new \App\Models\Clientmaster();
            $result = $userModel->addUpdate($data);
            return $this->response->setJSON($result);
        }
    }
    public function delete()
    {
        $id = $this->request->getPost('id');
        $userModel = new \App\Models\Clientmaster();
        $result = $userModel->deleteuser($id);
        return $this->response->setJSON($result);

    }

    public function edit()
    {
        $id = $this->request->getPost('id');
        $userModel = new \App\Models\Clientmaster();
        $result = $userModel->getuserData($id);
        return $this->response->setJSON($result);
    }
    public function checkDuplicate()
    {
        helper('checkUniqe');

        $data = $this->request->getPost();
        $response = ['status' => false];
        $table = 'clientmaster';

        if (!empty($data['email'])) {
            $emailExists = checkExistence($table, 'email', trim($data['email']));
            if ($emailExists) {
                $response['email'] = "Email already exists!";
                $response['status'] = true;
            }
        }

        return $this->response->setJSON($response);
    }


    public function view()
    {
        helper('pagination');
        try {

            $page_limit = $this->request->getPost('page_limit') ?? 5;
            $page_no = $this->request->getPost('page') ?? 1;
            $sort_column = $this->request->getPost('column') ?? 'status';
            $sort_order = $this->request->getPost('order') ?? 'DESC';
            $offset = (int)($page_no - 1) * (int)$page_limit;

            $clientname = !empty($this->request->getPost('searchclientname')) ? trim($this->request->getPost('searchclientname')) : "";
            $email = !empty($this->request->getPost('searchemail')) ? trim($this->request->getPost('searchemail')) : "";
            $mobilenumber = !empty($this->request->getPost('searchphone')) ? trim($this->request->getPost('searchphone')) : "";

            $userModel = new \App\Models\Clientmaster();
            $queryData = $userModel->fetch($sort_column, $sort_order, $page_limit, $offset, $clientname, $email, $mobilenumber);
            // print_r($queryData);
            $result = $queryData['data'];
            $total_records = $queryData['count'];

            $columns = ['id', 'first_name', 'email', 'mobile_number', 'Address'];

            $table = '<div class="table-wrap">
            <table class="table ">
                <thead class="table-secondary">
                    <tr>
                        <th scope="col" class="text-center">Sr.No</th>';

            foreach ($columns as $column) {
                $new_sort_order = $sort_column == $column && $sort_order == 'ASC' ? 'DESC' : 'ASC';
                $sort_icons = $sort_column == $column && $sort_order == 'ASC' ?
                    '<i class="fa fa-sort-alpha-asc" aria-hidden="true"></i>' :
                    '<i class="fa fa-sort-alpha-desc" aria-hidden="true"></i>';

                if ($column == 'first_name') {
                    $table .= '<th scope="col" class="text-center">
                            <a class="column_sort text-black" href="#" data-column="' . $column . '" data-order="' . $new_sort_order . '" style="align-items: center; gap: 5px; ">
                                <span>' . 'Client_Name' . '</span>
                                ' . $sort_icons . '
                            </a>
                        </th>';
                } else {
                    $table .= '<th scope="col" class="text-center">
                            <a class="column_sort text-black" href="#" data-column="' . $column . '" data-order="' . $new_sort_order . '" style="align-items: center; gap: 5px;">
                                <span>' . ucfirst($column) . '</span>
                                ' . $sort_icons . '
                            </a>
                        </th>';
                }

            }
            $table .= '<th scope="col" class="text-center">Action</th></tr></thead>';


            if (!empty($result)) {

                $s_no = $offset + 1;
                foreach ($result as $row) {
                    $table .= '<tr>';
                    $table .= '<td class="text-end">' . $s_no++ . '</td>';
                    $table .= '<td class="text-end">' . $row['id'] . '</td>';

                    $table .= '<td><a class="edit" style="cursor: pointer; text-decoration: none; font-weight:bold;" data-editid="' . $row['id'] . '">' . $row['first_name'] . ' ' . $row['last_name'] . '</a></td>';
                    $table .= '<td  style = "width : auto ;">' . $row['email'] . '</td>';
                    $table .= '<td class="text-end">' . $row['mobile_number'] . '</td>';
                    $table .= '<td>' . $row['address'] . '</td>';
                    $table .= '<td class="text-center">
                    <button class="btn  btn-sm edit" data-editid="' . $row['id'] . '">
                        <i class="fa fa-pencil" aria-hidden="true"></i>
                    </button>
                    <button class="btn  btn-sm delete" data-deleteid="' . $row['id'] . '">
                        <i class="fa fa-trash" aria-hidden="true"></i>
                    </button>
                </td>';
                    $table .= '</tr>';
                }
            } else {
                $table .= '<tr><td colspan="9" class="text-center font-weight-bold" style="background-color:rgb(253, 169, 169); color: red;">No Record Found</td></tr>';
            }

            $table .= '</tbody></table></div>';
            $pagination = pagination($page_no, $total_records, $page_limit);

            return $this->response->setJSON([
                'data' => $table,
                'pagination' => $pagination,
                'total_records' => $total_records,
                'total_pages' => ceil($total_records / $page_limit)
            ]);

        } catch (\Exception $e) {
            log_message('error', 'Error in fetch method: ' . $e->getMessage());
            echo json_encode(['error' => true, 'message' => 'An unexpected error occurred while fetching user data. Please try again later.']);
        }
    }
    public function getAddress()
    {
        $type = $this->request->getPost('type');

        if ($type == 'state') {

            $clientModel = new \App\Models\Clientmaster();
            $states = $clientModel->getStates();

            foreach ($states as $state) {
                echo "<option class='dynamic_state' value='{$state['state_id']}'  data-state='{$state['state_name']}'>{$state['state_name']}</option>";
            }
        } elseif ($type == 'city') {
            $state_id = $this->request->getPost('state');
            $clientModel = new \App\Models\Clientmaster();
            $cities = $clientModel->getCities($state_id);

            foreach ($cities as $city) {
                echo "<option class='dynamic_city' value='{$city['district_id']}' data-district='{$city['district_name']}' >{$city['district_name']}</option>";
            }
        }elseif ($type == 'searchcity') {
            $clientModel = new \App\Models\Clientmaster();
            $cities = $clientModel->getCitiessearch();
            foreach ($cities as $city) {
                echo "<option class='dynamic_city' value='{$city['district_id']}' data-district='{$city['district_name']}' >{$city['district_name']}</option>";
            }
        }
    }



}
