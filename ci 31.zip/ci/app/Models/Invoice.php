<?php

namespace App\Models;

use CodeIgniter\Model;

class Invoice extends Model
{
    protected $table            = 'invoice';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;
    protected $returnType       = 'array';
    protected $useSoftDeletes   = false;
    protected $protectFields    = true;
    protected $allowedFields    = [
        'invoice_id',
        'item_id',
        'quantity',
        'price',
        'total_price'
    ];

   
      public function insertInvoiceItems($items)
    {
         $this->insertBatch($items);
    }
}
