<?php

namespace App\Models;

use CodeIgniter\Model;
use CodeIgniter\Database\Exceptions\DatabaseException;


class Itemmaster extends Model
{
    protected $table            = 'itemmaster';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;
    protected $returnType       = 'array';
    protected $useSoftDeletes   = false;
    protected $protectFields    = true;
    protected $allowedFields    = [
        "id", "item_name", "description", "price", "created_date", "image"
    ];


    public function addUpdate(array $data)
    {

        $reqType = $data['req_type'];
        unset($data['req_type']);

        if ($reqType === 'add') {
            return $this->addUser($data);
        } elseif ($reqType === 'update') {
            return $this->updateUser($data);
        }
        return ['status' => false, 'message' => 'Invalid request type'];
    }

 
    private function addUser(array $data)
    {
        unset($data['id']);

        try {
            $this->insert($data);
            return [
                'status' => true,
                'message' => 'Data Inserted Successfully',
                'table_name' => $this->table,
                'id' => $this->db->insertID()
            ];
        } catch (DatabaseException $e) {
            return [
                'status' => false,
                'message' => 'Database error: ' . $e->getMessage(),
                'table_name' => $this->table
            ];
        }
    }

    private function updateUser(array $data)
    {
        // print_r($data);
        $id = $data['id'];
        try {
            $updated = $this->update($id, $data);
            // echo $this->getLastQuery();
            if ($updated) {
                return [
                    'status' => true,
                    'message' => 'Data Updated Successfully',
                    'table_name' => $this->table
                ];
            } else {
                return [
                    'status' => false,
                    'message' => 'No changes were made to the data.',
                    'table_name' => $this->table
                ];
            }
        } catch (DatabaseException $e) {
            return [
                'status' => false,
                'message' => 'Database error: ' . $e->getMessage(),
                'table_name' => $this->table
            ];
        }
    }

    public function deleteuser($id)
    {
        try {
            $this->delete($id);
            return [
                'status' => true,
                'message' => 'Data Deleted Successfully',
                'table_name' => $this->table
            ];
        } catch (DatabaseException $e) {
            return [
                'status' => false,
                'message' => 'Database error: ' . $e->getMessage(),
                'table_name' => $this->table
            ];
        }
    }


    public function getuserData($id)
    {
        try {
            $result = $this->where('id', $id)->first();
            return [
                'status' => true,
                'data' => $result,
                'table_name' => $this->table
            ];
        } catch (DatabaseException $e) {
            return [
                'status' => false,
                'message' => 'Database error: ' . $e->getMessage(),
                'table_name' => $this->table
            ];
        }
    }

    
    public function fetch($sort_column1, $sort_order, $page_limit, $offset, $itemname = '', $price = '',)
    {
        try {

            $builder = $this->db->table($this->table);  

           
            if (!empty($itemname)) {
                $builder->like('item_name', $itemname); 
            }
            if (!empty($price)) {
                $builder->where('price', $price);
            }

            if (!empty($sort_column1) && !empty($sort_order)) {
                $builder->orderBy($sort_column1, $sort_order); 
            }

            $builder->limit($page_limit, $offset);

            $data = $builder->get()->getResultArray();
            $countBuilder = clone $builder;  
            $total_count = $countBuilder->countAllResults();
            return [
                'count' => $total_count,  
                'data' => $data          
            ];

        } catch (DatabaseException $e) {
            return [
                'status' => false,
                'message' => 'Database error: ' . $e->getMessage(),
                'table_name' => $this->table
            ];
        } catch (\Exception $e) {
            return [
                'status' => false,
                'message' => 'Error: ' . $e->getMessage(),
                'table_name' => $this->table
            ];
        }
    }
 
   
}
