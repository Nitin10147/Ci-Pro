<div id="layoutSidenav_nav">
    <nav class="sb-sidenav accordion " id="sidenavAccordion">
        <div class="sb-sidenav-menu d-flex flex-column">

            <ul class="sidebar-menu">
                <li class="sidebar-menu-item">
                    <a href=" <?= base_url('dashboard') ?>" class="sidebar-menu-item-link">
                        <div class="sb-nav-link-icon "><i class="fa-solid fa-house"></i></div>
                        <span class="sidebar-menu-item-link-text">Dashboard</span>
                    </a>
                </li>

                <li class="sidebar-menu-item">
                    <a href="<?= base_url('usermaster') ?>" class="sidebar-menu-item-link">
                        <div class="sb-nav-link-icon"><i class="fa-solid fa-users"></i></div>
                        <span class="sidebar-menu-item-link-text">Usermaster</span>
                    </a>
                </li>

                <li class="sidebar-menu-item">
                    <a href="<?= base_url('clientmaster') ?>" class="sidebar-menu-item-link">
                        <div class="sb-nav-link-icon"><i class="fas fa-chart-area"></i></div>
                        <span class="sidebar-menu-item-link-text">Clientmaster</span>
                    </a>
                </li>

                <li class="sidebar-menu-item">
                    <a href="<?= base_url('itemmaster') ?>" class="sidebar-menu-item-link">
                        <div class="sb-nav-link-icon"><i class="fa-solid fa-dice-d6"></i></div>
                        <span class="sidebar-menu-item-link-text">Itemmaster</span>
                    </a>
                </li>

                <li class="sidebar-menu-item">
                    <a href="<?= base_url('invoicemaster') ?>" class="sidebar-menu-item-link">
                        <div class="sb-nav-link-icon"><i class="fa-solid fa-file-invoice"></i></div>
                        <span class="sidebar-menu-item-link-text">Invoicemaster</span>
                    </a>
                </li>


                <a class=" mt-auto  text-center logoutAll" href="#" id="logout">
                    <div class="sb-nav-link-icon"><i class="fas fa-sign-out-alt"></i> Logout</div>
                </a>
            </ul>


        </div>
    </nav>
</div>

<script>
$(document).ready(function() {
    $('.sidebar-menu-item-link').on('click', function() {
        $('.sidebar-menu-item').removeClass('active');
        $(this).closest('.sidebar-menu-item').addClass('active');
        localStorage.setItem('activeMenu', $(this).attr('href'));
    });

    const activeMenu = localStorage.getItem('activeMenu');
    if (activeMenu) {
        let found = false;
        $('.sidebar-menu-item-link').each(function() {
            if ($(this).attr('href') === activeMenu) {
                $(this).closest('.sidebar-menu-item').addClass('active');
                found = true;
            }
        });
        if (!found) {
            $('.sidebar-menu-item:first-child').addClass('active');
        }
    } else {
        $('.sidebar-menu-item:first-child').addClass('active');
    }

    $('.logoutAll').on('click', function() {
        localStorage.removeItem('activeMenu');
        $.ajax({
            url: '<?= base_url('logout') ?>',
            type: 'POST',
            success: function(response) {
                window.location.href = '<?= base_url('/login') ?>';
            },
            error: function(response) {
                $('#loginError').text('Something went wrong. Please try again.');
            }
        });
    });
});
</script>

<style>
/* start: Sidebar */

.sidebar {
    position: fixed;
    top: 0;
    left: 0;
    background-color: white;
    width: 256px;
    height: 100%;
    display: flex;
    flex-direction: column;
    transition: width 0.15s ease;
}

.sidebar-collapsed .sidebar {
    width: 56px;
}

.sidebar-menu {
    min-height: 85vh;
    list-style-type: none;
    display: flex;
    flex-direction: column;
    margin-top: 15px;
    padding: 0;
    overflow-y: hidden;
}

.sidebar-menu-item {
    padding: 6px;
    border-radius: 50px;
    padding-left: 0px;
    padding-bottom: 10px;
}

.sidebar-menu-item.active {
    background-color: var(--neutral-100);
    position: relative;
}

.sidebar-menu-item.active::before,
.sidebar-menu-item.active::after {
    content: "";
    position: absolute;
    width: 32px;
    height: 32px;
    border-radius: 50%;
    pointer-events: none;
    box-shadow: 16px 16px 0 var(--neutral-100);
}

.sidebar-menu-item.active::before {
    top: -32px;
    right: 0;
}

.sidebar-menu-item.active::after {
    bottom: -32px;
    right: 0;
}

.sidebar-menu-item-link {
    display: flex;
    align-items: center;
    height: 36px;
    background-color: var(--white);
    border-radius: 50px;
    text-decoration: none;
    padding: 0 12px;
    color: var(--neutral-800);
    transition: background-color 0.3s, color 0.3s;
}

.sidebar-menu-item-link:hover {
    color: var(--black);
}

.sidebar-menu-item.active .sidebar-menu-item-link {
    color: white !important;
    background-color: #4C43CD;
    box-shadow: 2px 19px 31px rgba(0, 0, 0, 0.2);
    margin-right: 5px;
    border-radius: 0 20px 20px 0;

    background: #5E5DF0;
    box-shadow: #5E5DF0 0 10px 20px -10px;
    color: #FFFFFF;
    cursor: pointer;
    font-family: Inter, Helvetica, "Segoe UI", sans-serif;
    font-size: 16px;
    font-weight: 700;
    line-height: 24px;



}

.sidebar-menu-item-link-icon {
    font-size: var(--text-lg);
    margin-right: 12px;
}

.sb-nav-link-icon {
    font-size: var(--text-lg);
    flex-shrink: 0;
    margin-right: 15px;
}

.sidebar-menu-item-link-text {
    font-size: 17px;
    font-weight: bold;
    min-width: 0;
    white-space: nowrap;
    overflow: hidden;
    font-family: Inter, Helvetica, "Segoe UI", sans-serif;

}

.sidebar-menu-item-link-text {
    font-weight: 500;
    line-height: 24px;

}


.sidebar-brand {
    height: 48px;
    display: flex;
    align-items: center;
    padding: 0 18px;
    flex-shrink: 0;
    overflow: hidden;
}

.sidebar-brand-link {
    text-decoration: none;
    display: flex;
    align-items: center;
    color: var(--primary-600);
}

.sidebar-brand-link-text {
    font-weight: 300;
    font-size: var(--text-lg);
    transition: opacity 0.15s;
}

.sidebar-collapsed .sidebar-brand-link-text {
    opacity: 0;
}

.sidebar-menu-wrapper {
    overflow-y: hidden;
    height: 100%;
    padding: 16px 0;
    margin-top: 16px;
    display: flex;
    flex-direction: column;
}


#logout {
    background: #5E5DF0;
    border-radius: 999px;
    box-shadow: #5E5DF0 0 10px 20px -10px;
    color: #FFFFFF;
    cursor: pointer;
    font-family: Inter, Helvetica, "Segoe UI", sans-serif;
    font-size: 16px;
    font-weight: 700;
    line-height: 24px;
    padding: 8px 56px;
    text-decoration: none;
    width: fit-content;
    border: none;
    user-select: none;
    -webkit-user-select: none;
    touch-action: manipulation;
    margin-left: 10px;
}
</style>