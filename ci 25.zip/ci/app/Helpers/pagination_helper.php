<?php

function pagination($page_no, $total_data, $page_limit)
{
    try {
        $total_page = ($total_data > 0 && $page_limit > 0) ? ceil($total_data / $page_limit) : 1;
        $previous_page = max(1, $page_no - 1);
        $next_page = min($total_page, $page_no + 1);

        $pagination = '<ul class="paginationDiv">';
        $pagination .= '<li class="pagination_link first-page ' . ($page_no == 1 ? 'disabled' : '') . '" id="1"><<</li>';
        $pagination .= '<li class="pagination_link previous-page ' . ($page_no == 1 ? 'disabled' : '') . '" id="' . $previous_page . '"><</li>';

        for ($i = 1; $i <= $total_page; $i++) {
            if ($i == $page_no) {
                $pagination .= '<li class="pagination_link active-pagination" id="' . $i . '">' . $i . '</li>';
            } elseif ($i >= ($page_no - 2) && $i <= ($page_no + 2)) {
                $pagination .= '<li class="pagination_link" id="' . $i . '">' . $i . '</li>';
            }
        }

        $pagination .= '<li class="pagination_link next-page ' . ($page_no == $total_page ? 'disabled' : '') . '" id="' . $next_page . '">></li>';
        $pagination .= '<li class="pagination_link last-page ' . ($page_no == $total_page ? 'disabled' : '') . '" id="' . $total_page . '">>></li>';
        $pagination .= '</ul>';

        return [
            'pagination' => $pagination,
            'total_page' => $total_page,
        ];
    } catch (Exception $e) {
        return [
            'pagination' => '',
            'total_page' => 0,
        ];
    }
}

?>